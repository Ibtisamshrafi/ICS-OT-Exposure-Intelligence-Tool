"""
setup.py - تثبيت الأداة كـ CLI command قابل للتنفيذ مباشرة من Terminal
بعد تشغيل: pip install -e .
يمكن استخدام الأمر: ics-osint مباشرة من أي مكان
"""

from setuptools import setup, find_packages

# قراءة ملف requirements.txt لاستخدامه في install_requires
with open("requirements.txt", "r", encoding="utf-8") as f:
    # تجاهل الأسطر الفارغة والتعليقات
    requirements = [
        line.strip()
        for line in f
        if line.strip() and not line.startswith("#")
    ]

# قراءة ملف README للوصف الطويل
try:
    with open("README.md", "r", encoding="utf-8") as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = "ICS/OT OSINT Tool using Shodan API"

setup(
    name="ics-osint",
    version="1.0.0",
    author="ICS OSINT Tool",
    description="أداة OSINT لجمع معلومات عن أنظمة ICS/OT باستخدام Shodan API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=requirements,
    entry_points={
        # هذا يجعل الأمر 'ics-osint' متاحاً في Terminal بعد التثبيت
        "console_scripts": [
            "ics-osint=ics_osint.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Topic :: Security",
        "Topic :: Internet",
    ],
)
