# ICS/OT OSINT Tool

<div dir="rtl">

أداة سطر أوامر (CLI) لجمع معلومات استخباراتية مفتوحة المصدر (OSINT) عن أنظمة التحكم الصناعي (ICS) وتقنيات التشغيل (OT) المكشوفة على الإنترنت باستخدام Shodan API.

</div>

## ⚠️ تنويه قانوني

**هذه الأداة للاستخدام الأخلاقي والقانوني فقط.**

- يجب استخدامها فقط على الأنظمة التي تملك إذناً صريحاً للفحص
- المطورون غير مسؤولين عن أي استخدام غير قانوني أو غير أخلاقي
- استخدام هذه الأداة على أنظمة دون إذن قد يكون مخالفاً للقانون

---

## ✨ المميزات

<div dir="rtl">

- 🔍 **بحث متقدم**: استعلامات مخصصة أو قوالب ICS/OT جاهزة (Modbus, DNP3, S7, BACnet...)
- 🌍 **فلترة ذكية**: فلترة مسبقة ولاحقة حسب الدولة، البورت، الشركة
- 📊 **تقارير تفصيلية**: إحصائيات، توزيع جغرافي، أكثر البورتات والشركات
- 💾 **تصدير متعدد**: JSON (مع metadata) و CSV (متوافق مع Excel)
- 🎨 **واجهة جميلة**: جداول ملونة، شريط تقدم، رسائل واضحة
- 🔐 **تخزين آمن**: مفتاح API يُحفظ في `~/.ics_osint/` بصلاحيات محدودة
- ⚡ **معالجة أخطاء شاملة**: Rate Limit, Timeout, Connection errors
- 🧪 **مُختبَر بالكامل**: 192 اختبار تغطي جميع الوحدات

</div>

---

## 📦 التثبيت

### المتطلبات

- Python 3.8 أو أحدث
- مفتاح Shodan API ([احصل عليه مجاناً](https://account.shodan.io/register))

### خطوات التثبيت

```bash
# 1. استنساخ المشروع
git clone https://github.com/yourusername/ics-osint-tool.git
cd ics-osint-tool

# 2. إنشاء بيئة افتراضية (موصى به)
python -m venv venv
source venv/bin/activate  # على Linux/macOS
# أو
venv\Scripts\activate     # على Windows

# 3. تثبيت المكتبات
pip install -r requirements.txt

# 4. تثبيت الأداة
pip install -e .

# 5. التحقق من التثبيت
ics-osint --version
```

---

## 🚀 البدء السريع

### 1. حفظ مفتاح Shodan API

```bash
ics-osint config --set-key YOUR_SHODAN_API_KEY
```

### 2. بحث بسيط باستخدام قالب جاهز

```bash
ics-osint search --template modbus
```

### 3. بحث مع تصدير النتائج

```bash
ics-osint search --template dnp3 --pages 3 --export-json --export-csv
```

### 4. بحث مخصص مع فلترة

```bash
ics-osint search --query "port:502" --country US --require-org --report
```

---

## 📖 دليل الاستخدام

### أوامر الإعدادات

```bash
# حفظ مفتاح API (يتحقق من صلاحيته أولاً)
ics-osint config --set-key YOUR_API_KEY

# عرض الإعدادات الحالية
ics-osint config --show

# التحقق من صلاحية المفتاح وعرض معلومات الحساب
ics-osint config --verify

# حذف المفتاح المحفوظ
ics-osint config --delete-key
```

### أمر البحث الرئيسي

#### استخدام القوالب الجاهزة

```bash
# عرض جميع القوالب المتاحة
ics-osint templates

# بحث باستخدام قالب
ics-osint search --template modbus
ics-osint search --template dnp3
ics-osint search --template s7
```

#### استعلامات مخصصة

```bash
# استعلام بسيط
ics-osint search --query "port:502"

# استعلام مع فلترة مسبقة
ics-osint search --query "port:502" --country US
ics-osint search --query "scada" --port 20000

# استعلام معقد
ics-osint search --query "port:502 product:modbus country:US"
```

#### خيارات الجلب

```bash
# جلب صفحات متعددة (كل صفحة = 100 نتيجة)
ics-osint search --template modbus --pages 5

# تحديد حد أقصى للنتائج
ics-osint search --template modbus --pages 10 --max-results 250
```

#### الفلترة اللاحقة

```bash
# فلترة بالدولة بعد الجلب
ics-osint search --template modbus --filter-country SA

# فلترة بالبورت بعد الجلب
ics-osint search --query "scada" --filter-port 502

# فلترة باسم الشركة (بحث نصي جزئي)
ics-osint search --template modbus --filter-org siemens

# استبعاد النتائج بدون اسم شركة
ics-osint search --template modbus --require-org
```

#### التصدير

```bash
# تصدير JSON فقط
ics-osint search --template modbus --export-json

# تصدير CSV فقط
ics-osint search --template modbus --export-csv

# تصدير كلا الصيغتين
ics-osint search --template modbus --export-json --export-csv

# تحديد اسم الملف
ics-osint search --template modbus --export-json --output results/modbus_scan
# ينتج: results/modbus_scan.json
```

#### التقارير والإحصائيات

```bash
# عرض إحصائيات عامة
ics-osint search --template modbus --show-stats

# عرض تقرير تفصيلي (دول، بورتات، شركات)
ics-osint search --template modbus --report

# تحديد عدد الصفوف المعروضة في الجدول
ics-osint search --template modbus --max-display 100
```

### عدد النتائج (مجاني)

```bash
# عرض عدد النتائج بدون جلب البيانات (لا يستهلك Query Credits)
ics-osint count --template modbus
ics-osint count --query "port:502" --country US
```

---

## 🎯 أمثلة عملية

### مثال 1: مسح Modbus في الولايات المتحدة

```bash
ics-osint search \
  --template modbus \
  --country US \
  --pages 5 \
  --require-org \
  --report \
  --export-json \
  --export-csv \
  --output results/us_modbus
```

### مثال 2: بحث عن أنظمة SCADA مع فلترة بشركة معينة

```bash
ics-osint search \
  --template scada \
  --pages 3 \
  --filter-org "siemens" \
  --show-stats \
  --export-json
```

### مثال 3: استعلام مخصص متقدم

```bash
ics-osint search \
  --query "port:502 product:modbus country:DE" \
  --pages 2 \
  --report \
  --export-csv \
  --output results/germany_modbus
```

### مثال 4: التحقق من عدد النتائج قبل البحث

```bash
# أولاً: تحقق من العدد (مجاني)
ics-osint count --template modbus --country SA

# ثانياً: إذا كان العدد مناسباً، نفّذ البحث
ics-osint search --template modbus --country SA --pages 5 --export-json
```

---

## 📁 هيكل المشروع

```
ics_osint/
├── __init__.py
├── cli.py              # المدخل الرئيسي (Click commands)
├── cli_helpers.py      # منطق الأعمال (Business Logic)
│
├── config/             # إدارة الإعدادات
│   ├── manager.py      # تخزين مفتاح API
│   └── constants.py    # الثوابت والقوالب
│
├── api/                # التواصل مع Shodan
│   ├── client.py       # ShodanClient الرئيسي
│   ├── exceptions.py   # استثناءات مخصصة
│   └── retry.py        # منطق إعادة المحاولة
│
├── processing/         # معالجة البيانات
│   ├── extractor.py    # استخراج الحقول
│   ├── filters.py      # الفلترة اللاحقة
│   └── aggregator.py   # الإحصائيات والتجميع
│
├── export/             # التصدير
│   ├── json_exporter.py
│   ├── csv_exporter.py
│   ├── filename.py
│   └── exporter.py     # واجهة موحّدة
│
└── display/            # العرض في Terminal
    ├── console.py      # Console مركزي
    ├── messages.py     # رسائل ملونة
    ├── tables.py       # جداول Rich
    └── progress.py     # شريط التقدم
```

---

## 🧪 الاختبارات

```bash
# تشغيل جميع الاختبارات
pytest tests/ -v

# تشغيل اختبارات وحدة معينة
pytest tests/test_api.py -v
pytest tests/test_processing.py -v
pytest tests/test_export.py -v

# تشغيل مع تغطية الكود
pytest tests/ --cov=ics_osint --cov-report=html
```

**النتيجة الحالية**: 192/192 اختبار نجح ✅

---

## 🔧 الإعدادات المتقدمة

### ملف الإعدادات

يُحفظ مفتاح API في:
- **Linux/macOS**: `~/.ics_osint/config.json`
- **Windows**: `C:\Users\USERNAME\.ics_osint\config.json`

الصلاحيات على Linux/macOS: `600` (قراءة/كتابة للمالك فقط)

### متغيرات البيئة

يمكن تمرير المفتاح عبر متغير بيئة (للأتمتة):

```bash
export SHODAN_API_KEY="your_key_here"
ics-osint search --template modbus
```

---

## 📊 قوالب ICS/OT المتاحة

| المفتاح | البروتوكول | البورت | الوصف |
|---------|------------|--------|-------|
| `modbus` | Modbus | 502 | PLCs والأنظمة الصناعية |
| `dnp3` | DNP3 | 20000 | أنظمة SCADA للطاقة والمياه |
| `s7` | Siemens S7 | 102 | PLCs الصناعية من Siemens |
| `bacnet` | BACnet | 47808 | أنظمة إدارة المباني (HVAC) |
| `iec104` | IEC 60870-5-104 | 2404 | أنظمة التحكم في الطاقة |
| `ethernetip` | EtherNet/IP | 44818 | Allen-Bradley/Rockwell |
| `scada` | SCADA | — | بحث عام عن أنظمة SCADA |
| `hmi` | HMI | — | واجهات HMI المكشوفة |
| `profinet` | PROFINET | 34964 | أنظمة Siemens الصناعية |
| `fox` | Niagara Fox | 1911 | أنظمة إدارة المباني |

---

## 🤝 المساهمة

المساهمات مرحب بها! يُرجى:

1. Fork المشروع
2. إنشاء branch للميزة الجديدة (`git checkout -b feature/amazing-feature`)
3. Commit التغييرات (`git commit -m 'Add amazing feature'`)
4. Push للـ branch (`git push origin feature/amazing-feature`)
5. فتح Pull Request

---

## 📝 الترخيص

هذا المشروع مرخص تحت [MIT License](LICENSE).

---

## 🙏 شكر وتقدير

- [Shodan](https://www.shodan.io/) — محرك البحث للأجهزة المتصلة بالإنترنت
- [Click](https://click.palletsprojects.com/) — مكتبة بناء CLI
- [Rich](https://rich.readthedocs.io/) — مكتبة العرض الجميل في Terminal

---

## 📧 التواصل

للأسئلة أو الاقتراحات، يُرجى فتح [Issue](https://github.com/yourusername/ics-osint-tool/issues).

---

<div dir="rtl">

**تذكير**: هذه الأداة للاستخدام الأخلاقي والقانوني فقط. استخدمها بمسؤولية.

</div>
