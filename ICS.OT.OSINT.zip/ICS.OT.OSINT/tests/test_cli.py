"""
tests/test_cli.py
=================
اختبارات واجهة سطر الأوامر (CLI).

المنهجية:
- نستخدم Click's CliRunner لاختبار الأوامر بدون terminal حقيقي
- نُزيّف (mock) ShodanClient لتجنب استدعاءات API حقيقية
- نُزيّف حفظ/قراءة المفتاح لتجنب التأثير على ملفات المستخدم

شغّل: python -m pytest tests/test_cli.py -v
"""

import pytest
from unittest.mock import patch, MagicMock
from click.testing import CliRunner

from ics_osint.cli import main
from ics_osint.api.exceptions import (
    InvalidAPIKeyError, RateLimitError, NoCreditsError,
    NoResultsError,
)
from ics_osint.api import exceptions as api_exc
from ics_osint.processing.extractor import DeviceRecord


# ---------------------------------------------------------------
# بيانات وهمية مشتركة
# ---------------------------------------------------------------

FAKE_API_KEY = "testkey1234567890abcdef"

FAKE_ACCOUNT_INFO = {
    "plan": "dev",
    "query_credits": 100,
    "scan_credits": 100,
    "unlocked": True,
}

FAKE_RAW_RESULTS = [
    {
        "ip_str": "1.2.3.4",
        "location": {"country_code": "US", "country_name": "United States", "city": "New York"},
        "org": "Example Corp",
        "ports": [502, 80],
    },
    {
        "ip_str": "5.6.7.8",
        "location": {"country_code": "DE", "country_name": "Germany", "city": "Berlin"},
        "org": "German Industrial",
        "ports": [502],
    },
]

FAKE_SEARCH_RESPONSE = {
    "total": 2,
    "matches": FAKE_RAW_RESULTS,
}


@pytest.fixture
def runner():
    """Click CliRunner لاختبار الأوامر"""
    return CliRunner(mix_stderr=False)


# ---------------------------------------------------------------
# اختبارات الأمر الرئيسي
# ---------------------------------------------------------------

class TestMainCommand:

    def test_version_flag(self, runner):
        """--version يعرض رقم الإصدار"""
        result = runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "1.0.0" in result.output

    def test_help_flag(self, runner):
        """--help يعرض المساعدة"""
        result = runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "search" in result.output
        assert "config" in result.output
        assert "templates" in result.output

    def test_no_args_shows_help(self, runner):
        """بدون أوامر يعرض المساعدة"""
        result = runner.invoke(main, [])
        assert result.exit_code == 0


# ---------------------------------------------------------------
# اختبارات أمر config
# ---------------------------------------------------------------

class TestConfigCommand:

    def test_config_help(self, runner):
        """config --help يعرض الخيارات"""
        result = runner.invoke(main, ["config", "--help"])
        assert result.exit_code == 0
        assert "--set-key" in result.output
        assert "--verify"  in result.output
        assert "--show"    in result.output

    def test_set_key_success(self, runner):
        """--set-key يحفظ المفتاح بعد التحقق منه"""
        with patch("ics_osint.cli_helpers.ShodanClient") as mock_client_class, \
             patch("ics_osint.cli_helpers.save_api_key", return_value=True):

            mock_client = MagicMock()
            mock_client.validate_key.return_value = FAKE_ACCOUNT_INFO
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, ["config", "--set-key", FAKE_API_KEY])

        assert result.exit_code == 0
        assert "نجاح" in result.output or "✓" in result.output

    def test_set_key_invalid(self, runner):
        """--set-key يعرض خطأ عند مفتاح غير صالح"""
        # mix_stderr=True لدمج stdout+stderr في output واحد
        mixed_runner = CliRunner(mix_stderr=True)
        with patch("ics_osint.cli_helpers.ShodanClient") as mock_client_class:
            mock_client = MagicMock()
            mock_client.validate_key.side_effect = InvalidAPIKeyError("مفتاح غير صالح")
            mock_client_class.return_value = mock_client

            result = mixed_runner.invoke(main, ["config", "--set-key", "bad_key"])

        assert result.exit_code == 1
        # الخطأ يُكتب على stderr — نتحقق من exit_code فقط
        assert result.exit_code != 0

    def test_set_empty_key_fails(self, runner):
        """--set-key بمفتاح فارغ يفشل — المفتاح الفارغ يُرفض في cmd_set_key"""
        mixed_runner = CliRunner(mix_stderr=True)
        with patch("ics_osint.cli_helpers.ShodanClient") as mock_client_class:
            mock_client = MagicMock()
            mock_client_class.return_value = mock_client

            # مفتاح مسافات فقط — يجب أن يُرفض
            result = mixed_runner.invoke(main, ["config", "--set-key", "   "])

        assert result.exit_code == 1

    def test_show_config(self, runner):
        """--show يعرض معلومات الإعدادات"""
        with patch("ics_osint.cli_helpers.get_config_info", return_value={
            "config_file_path": "/home/user/.ics_osint/config.json",
            "config_file_exists": True,
            "api_key_saved": True,
            "api_key_preview": "abcdefgh********",
            "platform": "Linux",
        }):
            result = runner.invoke(main, ["config", "--show"])

        assert result.exit_code == 0
        assert ".ics_osint" in result.output

    def test_verify_key_no_key_saved(self, runner):
        """--verify يعرض خطأ إذا لم يكن المفتاح محفوظاً"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=None):
            result = runner.invoke(main, ["config", "--verify"])

        assert result.exit_code == 1

    def test_verify_key_success(self, runner):
        """--verify يعرض معلومات الحساب عند مفتاح صالح"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY), \
             patch("ics_osint.cli_helpers.ShodanClient") as mock_client_class:

            mock_client = MagicMock()
            mock_client.validate_key.return_value = FAKE_ACCOUNT_INFO
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, ["config", "--verify"])

        assert result.exit_code == 0
        assert "صالح" in result.output or "✓" in result.output

    def test_delete_key_when_saved(self, runner):
        """--delete-key يحذف المفتاح المحفوظ"""
        with patch("ics_osint.cli_helpers.is_api_key_saved", return_value=True), \
             patch("ics_osint.cli_helpers.delete_api_key", return_value=True):

            result = runner.invoke(main, ["config", "--delete-key"])

        assert result.exit_code == 0
        assert "✓" in result.output

    def test_delete_key_when_not_saved(self, runner):
        """--delete-key يعرض تحذيراً إذا لم يكن المفتاح موجوداً"""
        with patch("ics_osint.cli_helpers.is_api_key_saved", return_value=False):
            result = runner.invoke(main, ["config", "--delete-key"])

        assert result.exit_code == 0
        assert "⚠" in result.output or "لا يوجد" in result.output


# ---------------------------------------------------------------
# اختبارات أمر templates
# ---------------------------------------------------------------

class TestTemplatesCommand:

    def test_templates_shows_all(self, runner):
        """templates يعرض جميع القوالب"""
        result = runner.invoke(main, ["templates"])
        assert result.exit_code == 0
        assert "modbus"  in result.output
        assert "dnp3"    in result.output
        assert "bacnet"  in result.output
        assert "port:502" in result.output

    def test_templates_shows_usage_hint(self, runner):
        """templates يعرض تلميح الاستخدام"""
        result = runner.invoke(main, ["templates"])
        assert result.exit_code == 0
        assert "--template" in result.output


# ---------------------------------------------------------------
# اختبارات أمر count
# ---------------------------------------------------------------

class TestCountCommand:

    def test_count_help(self, runner):
        """count --help يعرض الخيارات"""
        result = runner.invoke(main, ["count", "--help"])
        assert result.exit_code == 0
        assert "--query"    in result.output
        assert "--template" in result.output

    def test_count_no_query_fails(self, runner):
        """count بدون --query أو --template يفشل"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY):
            result = runner.invoke(main, ["count"])
        assert result.exit_code == 1

    def test_count_no_api_key_fails(self, runner):
        """count بدون مفتاح API يفشل"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=None):
            result = runner.invoke(main, ["count", "--template", "modbus"])
        assert result.exit_code == 1

    def test_count_with_template(self, runner):
        """count --template يعرض العدد"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY), \
             patch("ics_osint.cli_helpers.ShodanClient") as mock_client_class:

            mock_client = MagicMock()
            mock_client.count.return_value = 12345
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, ["count", "--template", "modbus"])

        assert result.exit_code == 0
        assert "12" in result.output  # 12,345

    def test_count_with_query(self, runner):
        """count --query يعرض العدد"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY), \
             patch("ics_osint.cli_helpers.ShodanClient") as mock_client_class:

            mock_client = MagicMock()
            mock_client.count.return_value = 500
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, ["count", "--query", "port:502"])

        assert result.exit_code == 0
        assert "500" in result.output


# ---------------------------------------------------------------
# اختبارات أمر search
# ---------------------------------------------------------------

class TestSearchCommand:

    def test_search_help(self, runner):
        """search --help يعرض جميع الخيارات"""
        result = runner.invoke(main, ["search", "--help"])
        assert result.exit_code == 0
        for opt in ["--query", "--template", "--country", "--port",
                    "--pages", "--export-json", "--export-csv",
                    "--filter-org", "--report"]:
            assert opt in result.output

    def test_search_no_query_no_template_fails(self, runner):
        """search بدون --query أو --template يفشل"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY):
            result = runner.invoke(main, ["search"])
        assert result.exit_code == 1

    def test_search_no_api_key_fails(self, runner):
        """search بدون مفتاح API يفشل"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=None):
            result = runner.invoke(main, ["search", "--template", "modbus"])
        assert result.exit_code == 1

    def test_search_with_template_success(self, runner):
        """search --template ينجح ويعرض النتائج"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY), \
             patch("ics_osint.cli_helpers.ShodanClient") as mock_client_class:

            mock_client = MagicMock()
            mock_client.search.return_value = FAKE_RAW_RESULTS
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, ["search", "--template", "modbus"])

        assert result.exit_code == 0
        assert "1.2.3.4" in result.output
        assert "5.6.7.8" in result.output

    def test_search_with_custom_query(self, runner):
        """search --query ينجح"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY), \
             patch("ics_osint.cli_helpers.ShodanClient") as mock_client_class:

            mock_client = MagicMock()
            mock_client.search.return_value = FAKE_RAW_RESULTS
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, ["search", "--query", "port:502"])

        assert result.exit_code == 0

    def test_search_no_results(self, runner):
        """search يتعامل مع عدم وجود نتائج"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY), \
             patch("ics_osint.cli_helpers.ShodanClient") as mock_client_class:

            mock_client = MagicMock()
            mock_client.search.side_effect = NoResultsError("لا توجد نتائج")
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, ["search", "--template", "modbus"])

        assert result.exit_code == 0  # ليس خطأً — فقط لا توجد نتائج
        assert "⚠" in result.output or "لا توجد" in result.output

    def test_search_invalid_api_key(self, runner):
        """search يعرض خطأ عند مفتاح غير صالح"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY), \
             patch("ics_osint.cli_helpers.ShodanClient") as mock_client_class:

            mock_client = MagicMock()
            mock_client.search.side_effect = InvalidAPIKeyError("مفتاح غير صالح")
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, ["search", "--template", "modbus"])

        assert result.exit_code == 1

    def test_search_rate_limit(self, runner):
        """search يعرض خطأ Rate Limit"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY), \
             patch("ics_osint.cli_helpers.ShodanClient") as mock_client_class:

            mock_client = MagicMock()
            mock_client.search.side_effect = RateLimitError("Rate limit", retry_after=60)
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, ["search", "--template", "modbus"])

        assert result.exit_code == 1
        assert "60" in result.output  # retry_after

    def test_search_connection_error(self, runner):
        """search يعرض خطأ الاتصال"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY), \
             patch("ics_osint.cli_helpers.ShodanClient") as mock_client_class:

            mock_client = MagicMock()
            mock_client.search.side_effect = api_exc.ConnectionError("فشل الاتصال")
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, ["search", "--template", "modbus"])

        assert result.exit_code == 1

    def test_search_with_country_filter(self, runner):
        """--country يُضاف للاستعلام"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY), \
             patch("ics_osint.cli_helpers.ShodanClient") as mock_client_class:

            mock_client = MagicMock()
            mock_client.search.return_value = FAKE_RAW_RESULTS
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, [
                "search", "--template", "modbus", "--country", "US"
            ])

        assert result.exit_code == 0
        # نتحقق أن الاستعلام يحتوي على country:US
        call_args = mock_client.search.call_args
        assert "country:US" in call_args[1].get("query", call_args[0][0] if call_args[0] else "")

    def test_search_with_export_json(self, runner, tmp_path):
        """--export-json يُصدّر ملف JSON"""
        output_path = str(tmp_path / "test_output")

        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY), \
             patch("ics_osint.cli_helpers.ShodanClient") as mock_client_class:

            mock_client = MagicMock()
            mock_client.search.return_value = FAKE_RAW_RESULTS
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, [
                "search", "--template", "modbus",
                "--export-json", "--output", output_path,
            ])

        assert result.exit_code == 0
        assert (tmp_path / "test_output.json").exists()

    def test_search_with_export_csv(self, runner, tmp_path):
        """--export-csv يُصدّر ملف CSV"""
        output_path = str(tmp_path / "test_output")

        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY), \
             patch("ics_osint.cli_helpers.ShodanClient") as mock_client_class:

            mock_client = MagicMock()
            mock_client.search.return_value = FAKE_RAW_RESULTS
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, [
                "search", "--template", "modbus",
                "--export-csv", "--output", output_path,
            ])

        assert result.exit_code == 0
        assert (tmp_path / "test_output.csv").exists()

    def test_search_with_both_exports(self, runner, tmp_path):
        """--export-json --export-csv يُصدّر كلا الملفين"""
        output_path = str(tmp_path / "test_output")

        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY), \
             patch("ics_osint.cli_helpers.ShodanClient") as mock_client_class:

            mock_client = MagicMock()
            mock_client.search.return_value = FAKE_RAW_RESULTS
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, [
                "search", "--template", "modbus",
                "--export-json", "--export-csv", "--output", output_path,
            ])

        assert result.exit_code == 0
        assert (tmp_path / "test_output.json").exists()
        assert (tmp_path / "test_output.csv").exists()

    def test_search_with_show_stats(self, runner):
        """--show-stats يعرض الإحصائيات"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY), \
             patch("ics_osint.cli_helpers.ShodanClient") as mock_client_class:

            mock_client = MagicMock()
            mock_client.search.return_value = FAKE_RAW_RESULTS
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, [
                "search", "--template", "modbus", "--show-stats"
            ])

        assert result.exit_code == 0
        assert "إجمالي الأجهزة" in result.output

    def test_search_with_report(self, runner):
        """--report يعرض التقرير التفصيلي"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY), \
             patch("ics_osint.cli_helpers.ShodanClient") as mock_client_class:

            mock_client = MagicMock()
            mock_client.search.return_value = FAKE_RAW_RESULTS
            mock_client_class.return_value = mock_client

            result = runner.invoke(main, [
                "search", "--template", "modbus", "--report"
            ])

        assert result.exit_code == 0
        # التقرير يجب أن يحتوي على قسم الدول أو البورتات
        assert "US" in result.output or "502" in result.output

    def test_search_pages_range_validation(self, runner):
        """--pages خارج النطاق يُرفض"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY):
            result = runner.invoke(main, [
                "search", "--template", "modbus", "--pages", "999"
            ])
        assert result.exit_code != 0

    def test_search_invalid_template_rejected(self, runner):
        """قالب غير موجود يُرفض"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY):
            result = runner.invoke(main, [
                "search", "--template", "nonexistent_template"
            ])
        assert result.exit_code != 0


# ---------------------------------------------------------------
# اختبارات build_query
# ---------------------------------------------------------------

class TestBuildQuery:

    def test_custom_query_returned_as_is(self):
        from ics_osint.cli_helpers import build_query
        result = build_query("port:502", None, None, None)
        assert result == "port:502"

    def test_template_resolves_to_query(self):
        from ics_osint.cli_helpers import build_query
        result = build_query(None, "modbus", None, None)
        assert result == "port:502"

    def test_country_appended_to_query(self):
        from ics_osint.cli_helpers import build_query
        result = build_query("port:502", None, "US", None)
        assert "port:502" in result
        assert "country:US" in result

    def test_port_appended_to_query(self):
        from ics_osint.cli_helpers import build_query
        result = build_query("scada", None, None, 502)
        assert "scada" in result
        assert "port:502" in result

    def test_country_uppercased(self):
        from ics_osint.cli_helpers import build_query
        result = build_query("port:502", None, "us", None)
        assert "country:US" in result

    def test_invalid_template_returns_none(self):
        from ics_osint.cli_helpers import build_query
        result = build_query(None, "nonexistent", None, None)
        assert result is None

    def test_no_query_no_template_returns_none(self):
        from ics_osint.cli_helpers import build_query
        result = build_query(None, None, None, None)
        assert result is None

    def test_query_takes_priority_over_template(self):
        """--query له أولوية على --template"""
        from ics_osint.cli_helpers import build_query
        result = build_query("port:20000", "modbus", None, None)
        # يجب أن يستخدم الاستعلام المخصص وليس قالب modbus
        assert "port:20000" in result
        assert "port:502" not in result
