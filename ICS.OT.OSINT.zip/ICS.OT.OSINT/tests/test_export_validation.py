"""
tests/test_export_validation.py
================================
فحص ملفات JSON و CSV المُصدَّرة للتأكد من:
1. صحة الترميز (Encoding) — خاصة الأحرف العربية والخاصة
2. صحة هيكل JSON (metadata + results)
3. صحة CSV (رؤوس الأعمدة، عدد الأعمدة، BOM)
4. سلامة البيانات (لا فقدان، لا تشويه)
5. قابلية إعادة التحميل (Roundtrip)

شغّل: python -m pytest tests/test_export_validation.py -v
"""

import pytest
import json
import csv
import os
from pathlib import Path
from datetime import datetime

from ics_osint.processing.extractor import DeviceRecord
from ics_osint.export.json_exporter import export_to_json, load_from_json
from ics_osint.export.csv_exporter import export_to_csv, load_from_csv
from ics_osint.export.exporter import export_results
from ics_osint.config.constants import CSV_HEADERS


# ---------------------------------------------------------------
# بيانات اختبار متنوعة (تغطي حالات الحافة)
# ---------------------------------------------------------------

STANDARD_DEVICES = [
    DeviceRecord("1.2.3.4",    "US", "United States", "New York",  "Siemens AG",          [80, 443, 502]),
    DeviceRecord("5.6.7.8",    "DE", "Germany",        "Berlin",   "Deutsche Telekom",     [502]),
    DeviceRecord("9.10.11.12", "SA", "Saudi Arabia",   "Riyadh",   "Saudi Electricity Co", [20000, 502]),
    DeviceRecord("10.0.0.1",   "CN", "China",          "Shanghai", "China Telecom",        [102, 80]),
    DeviceRecord("172.16.0.1", "JP", "Japan",          "Tokyo",    "NTT Communications",   [47808]),
]

EDGE_CASE_DEVICES = [
    # أحرف عربية في اسم الشركة
    DeviceRecord("192.168.1.1", "SA", "Saudi Arabia", "الرياض",
                 "شركة الكهرباء السعودية", [502, 20000]),
    # أحرف خاصة في اسم الشركة
    DeviceRecord("10.20.30.40", "US", "United States", "New York",
                 'Corp "Special" & <Chars>', [80]),
    # بورتات كثيرة
    DeviceRecord("203.0.113.1", "DE", "Germany", "Munich",
                 "Industrial Corp GmbH", list(range(80, 90))),
    # بدون بورتات
    DeviceRecord("198.51.100.1", "FR", "France", "Paris",
                 "French Telecom", []),
    # قيم N/A
    DeviceRecord("100.64.0.1", "N/A", "N/A", "N/A", "N/A", [502]),
]


# ---------------------------------------------------------------
# اختبارات ترميز JSON
# ---------------------------------------------------------------

class TestJSONEncoding:
    """التحقق من صحة ترميز ملفات JSON"""

    def test_json_file_is_valid_utf8(self, tmp_path):
        """الملف يُكتب بترميز UTF-8 صحيح"""
        path = tmp_path / "test.json"
        export_to_json(STANDARD_DEVICES, path)

        # قراءة الملف كـ bytes والتحقق من UTF-8
        raw_bytes = path.read_bytes()
        decoded = raw_bytes.decode("utf-8")  # يجب ألا يُرفع استثناء
        assert len(decoded) > 0

    def test_json_preserves_arabic_characters(self, tmp_path):
        """الأحرف العربية تُحفظ بشكل صحيح"""
        path = tmp_path / "arabic.json"
        export_to_json(EDGE_CASE_DEVICES, path)

        content = path.read_text(encoding="utf-8")
        assert "شركة الكهرباء السعودية" in content
        assert "الرياض" in content

    def test_json_no_ascii_escaping(self, tmp_path):
        """الأحرف غير ASCII لا تُحوَّل لـ \\uXXXX"""
        path = tmp_path / "no_escape.json"
        export_to_json(EDGE_CASE_DEVICES, path)

        content = path.read_text(encoding="utf-8")
        # ensure_ascii=False يجب أن يُبقي الأحرف العربية كما هي
        assert "\\u" not in content or "شركة" in content

    def test_json_handles_special_characters(self, tmp_path):
        """الأحرف الخاصة (& < > ") تُعالَج بشكل صحيح"""
        path = tmp_path / "special.json"
        export_to_json(EDGE_CASE_DEVICES, path)

        # يجب أن يكون JSON صالحاً
        with open(path, encoding="utf-8") as f:
            data = json.load(f)  # يُرفع استثناء إذا كان JSON تالفاً

        assert data is not None

    def test_json_pretty_format(self, tmp_path):
        """pretty=True يُنتج JSON مُنسَّقاً بمسافات بادئة"""
        path = tmp_path / "pretty.json"
        export_to_json(STANDARD_DEVICES, path, pretty=True)

        content = path.read_text(encoding="utf-8")
        # JSON المُنسَّق يحتوي على أسطر جديدة ومسافات
        assert "\n" in content
        assert "  " in content

    def test_json_compact_format(self, tmp_path):
        """pretty=False يُنتج JSON مضغوطاً"""
        path_pretty  = tmp_path / "pretty.json"
        path_compact = tmp_path / "compact.json"

        export_to_json(STANDARD_DEVICES, path_pretty,  pretty=True)
        export_to_json(STANDARD_DEVICES, path_compact, pretty=False)

        # الملف المضغوط يجب أن يكون أصغر
        assert path_compact.stat().st_size < path_pretty.stat().st_size


# ---------------------------------------------------------------
# اختبارات هيكل JSON
# ---------------------------------------------------------------

class TestJSONStructure:
    """التحقق من صحة هيكل ملفات JSON"""

    def test_json_has_metadata_section(self, tmp_path):
        """الملف يحتوي على قسم metadata"""
        path = tmp_path / "test.json"
        export_to_json(STANDARD_DEVICES, path, query="port:502")

        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        assert "metadata" in data
        assert isinstance(data["metadata"], dict)

    def test_json_metadata_has_required_fields(self, tmp_path):
        """metadata يحتوي على الحقول المطلوبة"""
        path = tmp_path / "test.json"
        export_to_json(STANDARD_DEVICES, path, query="port:502 country:US")

        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        meta = data["metadata"]
        assert "query"         in meta
        assert "total_results" in meta
        assert "exported_at"   in meta
        assert "tool_version"  in meta

    def test_json_metadata_query_matches(self, tmp_path):
        """metadata.query يطابق الاستعلام المُمرَّر"""
        path = tmp_path / "test.json"
        query = "port:502 country:SA"
        export_to_json(STANDARD_DEVICES, path, query=query)

        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        assert data["metadata"]["query"] == query

    def test_json_metadata_total_results_correct(self, tmp_path):
        """metadata.total_results يطابق عدد السجلات"""
        path = tmp_path / "test.json"
        export_to_json(STANDARD_DEVICES, path)

        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        assert data["metadata"]["total_results"] == len(STANDARD_DEVICES)
        assert len(data["results"]) == len(STANDARD_DEVICES)

    def test_json_exported_at_is_valid_datetime(self, tmp_path):
        """metadata.exported_at تاريخ صالح"""
        path = tmp_path / "test.json"
        export_to_json(STANDARD_DEVICES, path)

        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        exported_at = data["metadata"]["exported_at"]
        # يجب أن يكون ISO format صالح
        parsed = datetime.fromisoformat(exported_at)
        assert parsed is not None

    def test_json_results_have_all_fields(self, tmp_path):
        """كل سجل في results يحتوي على جميع الحقول"""
        path = tmp_path / "test.json"
        export_to_json(STANDARD_DEVICES, path)

        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        required_fields = ["ip", "country_code", "country_name", "city", "org", "ports"]
        for record in data["results"]:
            for field in required_fields:
                assert field in record, f"الحقل '{field}' مفقود في السجل: {record}"

    def test_json_ports_are_integers(self, tmp_path):
        """البورتات في JSON أعداد صحيحة وليست strings"""
        path = tmp_path / "test.json"
        export_to_json(STANDARD_DEVICES, path)

        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        for record in data["results"]:
            assert isinstance(record["ports"], list)
            for port in record["ports"]:
                assert isinstance(port, int), f"البورت {port} ليس int"

    def test_json_no_data_loss(self, tmp_path):
        """لا يوجد فقدان في البيانات بعد التصدير"""
        path = tmp_path / "test.json"
        export_to_json(STANDARD_DEVICES, path)

        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        exported_ips = {r["ip"] for r in data["results"]}
        original_ips = {d.ip for d in STANDARD_DEVICES}
        assert exported_ips == original_ips

    def test_json_empty_devices_valid_structure(self, tmp_path):
        """قائمة فارغة تُنتج JSON صالحاً"""
        path = tmp_path / "empty.json"
        export_to_json([], path)

        with open(path, encoding="utf-8") as f:
            data = json.load(f)

        assert "results" in data
        assert data["results"] == []
        assert data["metadata"]["total_results"] == 0


# ---------------------------------------------------------------
# اختبارات ترميز CSV
# ---------------------------------------------------------------

class TestCSVEncoding:
    """التحقق من صحة ترميز ملفات CSV"""

    def test_csv_has_utf8_bom(self, tmp_path):
        """الملف يبدأ بـ UTF-8 BOM (EF BB BF) لدعم Excel"""
        path = tmp_path / "test.csv"
        export_to_csv(STANDARD_DEVICES, path)

        raw_bytes = path.read_bytes()
        assert raw_bytes[:3] == b'\xef\xbb\xbf', \
            "الملف يجب أن يبدأ بـ UTF-8 BOM"

    def test_csv_preserves_arabic_characters(self, tmp_path):
        """الأحرف العربية تُحفظ بشكل صحيح"""
        path = tmp_path / "arabic.csv"
        export_to_csv(EDGE_CASE_DEVICES, path)

        content = path.read_text(encoding="utf-8-sig")
        assert "شركة الكهرباء السعودية" in content
        assert "الرياض" in content

    def test_csv_readable_by_excel_encoding(self, tmp_path):
        """الملف قابل للقراءة بترميز Excel (utf-8-sig)"""
        path = tmp_path / "excel.csv"
        export_to_csv(STANDARD_DEVICES, path)

        # محاكاة قراءة Excel
        with open(path, encoding="utf-8-sig", newline="") as f:
            reader = csv.reader(f)
            rows = list(reader)

        assert len(rows) > 0
        assert rows[0] == CSV_HEADERS  # سطر الرؤوس صحيح


# ---------------------------------------------------------------
# اختبارات هيكل CSV
# ---------------------------------------------------------------

class TestCSVStructure:
    """التحقق من صحة هيكل ملفات CSV"""

    def test_csv_has_correct_headers(self, tmp_path):
        """سطر الرؤوس يطابق CSV_HEADERS"""
        path = tmp_path / "test.csv"
        export_to_csv(STANDARD_DEVICES, path)

        with open(path, encoding="utf-8-sig", newline="") as f:
            reader = csv.reader(f)
            header = next(reader)

        assert header == CSV_HEADERS

    def test_csv_correct_column_count(self, tmp_path):
        """كل سطر يحتوي على العدد الصحيح من الأعمدة"""
        path = tmp_path / "test.csv"
        export_to_csv(STANDARD_DEVICES, path)

        with open(path, encoding="utf-8-sig", newline="") as f:
            reader = csv.reader(f)
            next(reader)  # تخطي الرؤوس
            for row in reader:
                assert len(row) == len(CSV_HEADERS), \
                    f"عدد الأعمدة خاطئ: {len(row)} بدلاً من {len(CSV_HEADERS)}"

    def test_csv_correct_row_count(self, tmp_path):
        """عدد الصفوف يطابق عدد الأجهزة"""
        path = tmp_path / "test.csv"
        export_to_csv(STANDARD_DEVICES, path)

        with open(path, encoding="utf-8-sig", newline="") as f:
            reader = csv.reader(f)
            rows = list(reader)

        # صف الرؤوس + صفوف البيانات
        assert len(rows) == len(STANDARD_DEVICES) + 1

    def test_csv_ip_column_correct(self, tmp_path):
        """عمود IP Address يحتوي على عناوين IP الصحيحة"""
        path = tmp_path / "test.csv"
        export_to_csv(STANDARD_DEVICES, path)

        with open(path, encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            rows = list(reader)

        exported_ips = {row["IP Address"] for row in rows}
        original_ips = {d.ip for d in STANDARD_DEVICES}
        assert exported_ips == original_ips

    def test_csv_ports_as_pipe_separated_string(self, tmp_path):
        """البورتات تُصدَّر كنص مفصول بـ |"""
        device = DeviceRecord("1.2.3.4", "US", "United States", "NY", "Corp", [80, 443, 502])
        path = tmp_path / "ports.csv"
        export_to_csv([device], path)

        with open(path, encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            row = next(reader)

        ports_str = row["Open Ports"]
        assert "|" in ports_str
        assert "80" in ports_str
        assert "443" in ports_str
        assert "502" in ports_str

    def test_csv_empty_ports_handled(self, tmp_path):
        """جهاز بدون بورتات لا يُسبّب crash"""
        device = DeviceRecord("1.2.3.4", "US", "United States", "NY", "Corp", [])
        path = tmp_path / "no_ports.csv"
        export_to_csv([device], path)

        with open(path, encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            row = next(reader)

        # عمود البورتات يجب أن يكون فارغاً أو يحتوي على قيمة افتراضية
        assert "Open Ports" in row

    def test_csv_no_data_loss(self, tmp_path):
        """لا يوجد فقدان في البيانات بعد التصدير"""
        path = tmp_path / "test.csv"
        export_to_csv(STANDARD_DEVICES, path)

        with open(path, encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            rows = list(reader)

        exported_ips = {row["IP Address"] for row in rows}
        original_ips = {d.ip for d in STANDARD_DEVICES}
        assert exported_ips == original_ips

    def test_csv_empty_devices_has_only_header(self, tmp_path):
        """قائمة فارغة تُنتج ملفاً بسطر الرؤوس فقط"""
        path = tmp_path / "empty.csv"
        export_to_csv([], path)

        with open(path, encoding="utf-8-sig", newline="") as f:
            reader = csv.reader(f)
            rows = list(reader)

        assert len(rows) == 1
        assert rows[0] == CSV_HEADERS


# ---------------------------------------------------------------
# اختبارات Roundtrip (تصدير ثم إعادة تحميل)
# ---------------------------------------------------------------

class TestRoundtrip:
    """التحقق من أن التصدير ثم التحميل يُرجع نفس البيانات"""

    def test_json_roundtrip_preserves_all_data(self, tmp_path):
        """JSON: تصدير → تحميل → نفس البيانات"""
        path = tmp_path / "roundtrip.json"
        query = "port:502 country:US"

        export_to_json(STANDARD_DEVICES, path, query=query)
        loaded_devices, metadata = load_from_json(path)

        # التحقق من metadata
        assert metadata["query"] == query
        assert metadata["total_results"] == len(STANDARD_DEVICES)

        # التحقق من البيانات
        assert len(loaded_devices) == len(STANDARD_DEVICES)

        original_ips = {d.ip for d in STANDARD_DEVICES}
        loaded_ips   = {d.ip for d in loaded_devices}
        assert original_ips == loaded_ips

        # التحقق من الحقول
        original_map = {d.ip: d for d in STANDARD_DEVICES}
        for loaded in loaded_devices:
            original = original_map[loaded.ip]
            assert loaded.country_code == original.country_code
            assert loaded.org          == original.org
            assert set(loaded.ports)   == set(original.ports)

    def test_csv_roundtrip_preserves_all_data(self, tmp_path):
        """CSV: تصدير → تحميل → نفس البيانات"""
        path = tmp_path / "roundtrip.csv"

        export_to_csv(STANDARD_DEVICES, path)
        loaded_devices = load_from_csv(path)

        assert len(loaded_devices) == len(STANDARD_DEVICES)

        original_ips = {d.ip for d in STANDARD_DEVICES}
        loaded_ips   = {d.ip for d in loaded_devices}
        assert original_ips == loaded_ips

    def test_json_roundtrip_arabic_data(self, tmp_path):
        """JSON Roundtrip يحافظ على الأحرف العربية"""
        arabic_device = DeviceRecord(
            "1.2.3.4", "SA", "المملكة العربية السعودية",
            "الرياض", "شركة الكهرباء السعودية", [502]
        )
        path = tmp_path / "arabic_roundtrip.json"

        export_to_json([arabic_device], path)
        loaded_devices, _ = load_from_json(path)

        assert len(loaded_devices) == 1
        assert loaded_devices[0].org == "شركة الكهرباء السعودية"
        assert loaded_devices[0].city == "الرياض"

    def test_csv_roundtrip_arabic_data(self, tmp_path):
        """CSV Roundtrip يحافظ على الأحرف العربية"""
        arabic_device = DeviceRecord(
            "1.2.3.4", "SA", "Saudi Arabia",
            "الرياض", "شركة سعودية", [502]
        )
        path = tmp_path / "arabic_roundtrip.csv"

        export_to_csv([arabic_device], path)
        loaded_devices = load_from_csv(path)

        assert len(loaded_devices) == 1
        assert loaded_devices[0].city == "الرياض"
        assert loaded_devices[0].org  == "شركة سعودية"

    def test_json_roundtrip_many_ports(self, tmp_path):
        """JSON Roundtrip يحافظ على قائمة بورتات كبيرة"""
        many_ports = list(range(80, 100))
        device = DeviceRecord("1.2.3.4", "US", "United States", "NY", "Corp", many_ports)
        path = tmp_path / "many_ports.json"

        export_to_json([device], path)
        loaded_devices, _ = load_from_json(path)

        assert set(loaded_devices[0].ports) == set(many_ports)


# ---------------------------------------------------------------
# اختبارات export_results (الواجهة الموحّدة)
# ---------------------------------------------------------------

class TestExportResultsValidation:
    """التحقق من صحة الواجهة الموحّدة للتصدير"""

    def test_both_formats_produce_valid_files(self, tmp_path):
        """تصدير JSON و CSV معاً ينتج ملفين صالحين"""
        output_path = str(tmp_path / "both_formats")

        result = export_results(
            devices=STANDARD_DEVICES,
            formats=["json", "csv"],
            output_path=output_path,
            query="port:502",
        )

        assert result.success
        assert result.json_path.exists()
        assert result.csv_path.exists()

        # التحقق من JSON
        with open(result.json_path, encoding="utf-8") as f:
            json_data = json.load(f)
        assert len(json_data["results"]) == len(STANDARD_DEVICES)

        # التحقق من CSV
        with open(result.csv_path, encoding="utf-8-sig") as f:
            csv_rows = list(csv.DictReader(f))
        assert len(csv_rows) == len(STANDARD_DEVICES)

    def test_auto_generated_filename_is_valid(self, tmp_path):
        """اسم الملف المُولَّد تلقائياً صالح"""
        import os
        original_dir = os.getcwd()
        try:
            os.chdir(tmp_path)
            result = export_results(
                devices=STANDARD_DEVICES,
                formats=["json"],
                output_path="",
                query="port:502",
            )
            # نتحقق من الملف بينما لا نزال في tmp_path
            assert result.json_path is not None
            assert result.json_path.exists()
            assert "shodan" in result.json_path.name
        finally:
            os.chdir(original_dir)

    def test_export_with_edge_case_data(self, tmp_path):
        """تصدير البيانات الحافة (أحرف خاصة، بورتات فارغة)"""
        output_path = str(tmp_path / "edge_cases")

        result = export_results(
            devices=EDGE_CASE_DEVICES,
            formats=["json", "csv"],
            output_path=output_path,
        )

        assert result.success

        # التحقق من أن الملفات صالحة
        with open(result.json_path, encoding="utf-8") as f:
            json_data = json.load(f)
        assert len(json_data["results"]) == len(EDGE_CASE_DEVICES)

        with open(result.csv_path, encoding="utf-8-sig") as f:
            csv_rows = list(csv.DictReader(f))
        assert len(csv_rows) == len(EDGE_CASE_DEVICES)
