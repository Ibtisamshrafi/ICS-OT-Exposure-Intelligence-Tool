"""
tests/test_export.py
====================
اختبارات وحدة التصدير — تستخدم مجلدات مؤقتة لا تترك أثراً.

شغّل: python -m pytest tests/test_export.py -v
"""

import json
import csv
import pytest
from pathlib import Path

from ics_osint.processing.extractor import DeviceRecord
from ics_osint.export.json_exporter import export_to_json, load_from_json, JSONExportError
from ics_osint.export.csv_exporter  import export_to_csv, load_from_csv, CSVExportError, _parse_ports_from_csv
from ics_osint.export.filename import (
    generate_filename, resolve_output_path,
    validate_output_path, _sanitize_for_filename,
)
from ics_osint.export.exporter import export_results, ExportResult
from ics_osint.config.constants import CSV_HEADERS


# ---------------------------------------------------------------
# بيانات وهمية مشتركة
# ---------------------------------------------------------------

def make_device(ip="1.2.3.4", country_code="US", country_name="United States",
                city="New York", org="Example Corp", ports=None) -> DeviceRecord:
    return DeviceRecord(
        ip=ip, country_code=country_code, country_name=country_name,
        city=city, org=org, ports=ports or [80, 443, 502],
    )


SAMPLE_DEVICES = [
    make_device("1.2.3.4", "US", "United States", "New York",  "Corp A", [80, 502]),
    make_device("5.6.7.8", "DE", "Germany",        "Berlin",   "Corp B", [502]),
    make_device("9.10.11.12", "SA", "Saudi Arabia", "Riyadh",  "Corp C", [20000, 502]),
]


# ---------------------------------------------------------------
# اختبارات filename.py
# ---------------------------------------------------------------

class TestFilename:

    def test_generate_filename_format(self):
        """اسم الملف يتبع الصيغة الصحيحة"""
        name = generate_filename("json")
        assert name.endswith(".json")
        assert name.startswith("shodan_")

    def test_generate_filename_with_query(self):
        """الاستعلام يُضاف لاسم الملف"""
        name = generate_filename("csv", query="port:502")
        assert "port" in name
        assert name.endswith(".csv")

    def test_generate_filename_custom_prefix(self):
        """البادئة المخصصة تُستخدم"""
        name = generate_filename("json", prefix="ics_scan")
        assert name.startswith("ics_scan_")

    def test_resolve_output_path_adds_extension(self):
        """يُضيف الامتداد إذا كان مفقوداً"""
        path = resolve_output_path("results", "json")
        assert path.suffix == ".json"
        assert path.stem == "results"

    def test_resolve_output_path_fixes_wrong_extension(self):
        """يُصلح الامتداد الخاطئ"""
        path = resolve_output_path("results.txt", "csv")
        assert path.suffix == ".csv"

    def test_resolve_output_path_keeps_correct_extension(self):
        """يحافظ على الامتداد الصحيح"""
        path = resolve_output_path("results.json", "json")
        assert path.suffix == ".json"

    def test_resolve_output_path_auto_generates_when_empty(self):
        """يُولّد اسماً تلقائياً عند المسار الفارغ"""
        path = resolve_output_path("", "json")
        assert path.suffix == ".json"
        assert "shodan" in path.name

    def test_validate_output_path_creates_parent_dir(self, tmp_path):
        """يُنشئ المجلد الأب إذا لم يكن موجوداً"""
        new_dir = tmp_path / "new_folder" / "sub"
        path = new_dir / "results.json"
        valid, msg = validate_output_path(path)
        assert valid is True
        assert new_dir.exists()

    def test_validate_output_path_warns_if_file_exists(self, tmp_path):
        """يُعطي تحذيراً إذا كان الملف موجوداً"""
        existing = tmp_path / "existing.json"
        existing.touch()
        valid, msg = validate_output_path(existing)
        assert valid is True
        assert "تحذير" in msg or "warning" in msg.lower() or existing.name in msg

    def test_sanitize_for_filename_replaces_special_chars(self):
        """يستبدل الأحرف الخاصة بـ underscore"""
        result = _sanitize_for_filename("port:502 country:US")
        assert ":" not in result
        assert " " not in result

    def test_sanitize_removes_repeated_underscores(self):
        """يُزيل underscores المتكررة"""
        result = _sanitize_for_filename("port::502")
        assert "__" not in result


# ---------------------------------------------------------------
# اختبارات json_exporter.py
# ---------------------------------------------------------------

class TestJSONExporter:

    def test_exports_correct_number_of_records(self, tmp_path):
        """يُصدّر العدد الصحيح من السجلات"""
        path = tmp_path / "results.json"
        count = export_to_json(SAMPLE_DEVICES, path)
        assert count == 3

    def test_exported_file_is_valid_json(self, tmp_path):
        """الملف المُصدَّر JSON صالح"""
        path = tmp_path / "results.json"
        export_to_json(SAMPLE_DEVICES, path)
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        assert isinstance(data, dict)

    def test_exported_file_has_metadata(self, tmp_path):
        """الملف يحتوي على قسم metadata"""
        path = tmp_path / "results.json"
        export_to_json(SAMPLE_DEVICES, path, query="port:502")
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        assert "metadata" in data
        assert data["metadata"]["query"] == "port:502"
        assert data["metadata"]["total_results"] == 3

    def test_exported_file_has_results(self, tmp_path):
        """الملف يحتوي على قسم results"""
        path = tmp_path / "results.json"
        export_to_json(SAMPLE_DEVICES, path)
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        assert "results" in data
        assert len(data["results"]) == 3

    def test_exported_record_has_all_fields(self, tmp_path):
        """كل سجل يحتوي على جميع الحقول"""
        path = tmp_path / "results.json"
        export_to_json(SAMPLE_DEVICES, path)
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        record = data["results"][0]
        for field in ["ip", "country_code", "country_name", "city", "org", "ports"]:
            assert field in record, f"الحقل '{field}' مفقود"

    def test_exports_empty_list(self, tmp_path):
        """يُصدّر ملفاً فارغاً بدون crash"""
        path = tmp_path / "empty.json"
        count = export_to_json([], path)
        assert count == 0
        assert path.exists()

    def test_without_metadata(self, tmp_path):
        """يُصدّر بدون metadata عند الطلب"""
        path = tmp_path / "no_meta.json"
        export_to_json(SAMPLE_DEVICES, path, include_metadata=False)
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        assert "metadata" not in data

    def test_preserves_arabic_characters(self, tmp_path):
        """يحافظ على الأحرف العربية في الملف"""
        device = make_device(org="شركة سعودية للطاقة")
        path = tmp_path / "arabic.json"
        export_to_json([device], path)
        content = path.read_text(encoding="utf-8")
        assert "شركة سعودية للطاقة" in content

    def test_ports_exported_as_list(self, tmp_path):
        """البورتات تُصدَّر كقائمة وليس كنص"""
        path = tmp_path / "results.json"
        export_to_json(SAMPLE_DEVICES, path)
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        ports = data["results"][0]["ports"]
        assert isinstance(ports, list)
        assert all(isinstance(p, int) for p in ports)

    def test_load_from_json_roundtrip(self, tmp_path):
        """تصدير ثم تحميل يُرجع نفس البيانات"""
        path = tmp_path / "roundtrip.json"
        export_to_json(SAMPLE_DEVICES, path, query="port:502")
        loaded_devices, metadata = load_from_json(path)

        assert len(loaded_devices) == len(SAMPLE_DEVICES)
        assert metadata["query"] == "port:502"
        assert loaded_devices[0].ip == SAMPLE_DEVICES[0].ip

    def test_load_from_json_missing_file(self, tmp_path):
        """يُرفع JSONExportError إذا كان الملف غير موجود"""
        with pytest.raises(JSONExportError):
            load_from_json(tmp_path / "nonexistent.json")

    def test_load_from_json_corrupt_file(self, tmp_path):
        """يُرفع JSONExportError إذا كان الملف تالفاً"""
        corrupt = tmp_path / "corrupt.json"
        corrupt.write_text("{ not valid json !!!", encoding="utf-8")
        with pytest.raises(JSONExportError):
            load_from_json(corrupt)


# ---------------------------------------------------------------
# اختبارات csv_exporter.py
# ---------------------------------------------------------------

class TestCSVExporter:

    def test_exports_correct_number_of_records(self, tmp_path):
        """يُصدّر العدد الصحيح من السجلات"""
        path = tmp_path / "results.csv"
        count = export_to_csv(SAMPLE_DEVICES, path)
        assert count == 3

    def test_exported_file_has_header_row(self, tmp_path):
        """الملف يحتوي على سطر رؤوس"""
        path = tmp_path / "results.csv"
        export_to_csv(SAMPLE_DEVICES, path)
        with open(path, encoding="utf-8-sig") as f:
            reader = csv.reader(f)
            header = next(reader)
        assert header == CSV_HEADERS

    def test_exported_file_correct_column_count(self, tmp_path):
        """كل سطر يحتوي على العدد الصحيح من الأعمدة"""
        path = tmp_path / "results.csv"
        export_to_csv(SAMPLE_DEVICES, path)
        with open(path, encoding="utf-8-sig") as f:
            reader = csv.reader(f)
            next(reader)  # تخطي الرؤوس
            for row in reader:
                assert len(row) == len(CSV_HEADERS)

    def test_ports_exported_as_string(self, tmp_path):
        """البورتات تُصدَّر كنص مفصول"""
        path = tmp_path / "results.csv"
        export_to_csv(SAMPLE_DEVICES, path)
        with open(path, encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            first_row = next(reader)
        ports_str = first_row["Open Ports"]
        assert isinstance(ports_str, str)
        assert "|" in ports_str or ports_str.isdigit()

    def test_exports_empty_list(self, tmp_path):
        """يُصدّر ملفاً بسطر رؤوس فقط عند قائمة فارغة"""
        path = tmp_path / "empty.csv"
        count = export_to_csv([], path)
        assert count == 0
        assert path.exists()
        # يجب أن يحتوي على سطر الرؤوس فقط
        with open(path, encoding="utf-8-sig") as f:
            lines = [l for l in f if l.strip()]
        assert len(lines) == 1  # سطر الرؤوس فقط

    def test_without_header(self, tmp_path):
        """يُصدّر بدون سطر رؤوس عند الطلب"""
        path = tmp_path / "no_header.csv"
        export_to_csv(SAMPLE_DEVICES, path, include_header=False)
        with open(path, encoding="utf-8-sig") as f:
            reader = csv.reader(f)
            first_row = next(reader)
        # أول سطر يجب أن يكون بيانات وليس رؤوساً
        assert first_row[0] not in CSV_HEADERS

    def test_semicolon_delimiter(self, tmp_path):
        """يدعم الفاصلة المنقوطة"""
        path = tmp_path / "semicolon.csv"
        export_to_csv(SAMPLE_DEVICES, path, delimiter=";")
        content = path.read_text(encoding="utf-8-sig")
        assert ";" in content

    def test_utf8_bom_encoding(self, tmp_path):
        """الملف يُكتب بـ UTF-8 BOM لدعم Excel"""
        path = tmp_path / "results.csv"
        export_to_csv(SAMPLE_DEVICES, path)
        # UTF-8 BOM يبدأ بـ bytes: EF BB BF
        raw_bytes = path.read_bytes()
        assert raw_bytes[:3] == b'\xef\xbb\xbf'

    def test_preserves_arabic_characters(self, tmp_path):
        """يحافظ على الأحرف العربية"""
        device = make_device(org="شركة سعودية")
        path = tmp_path / "arabic.csv"
        export_to_csv([device], path)
        content = path.read_text(encoding="utf-8-sig")
        assert "شركة سعودية" in content

    def test_load_from_csv_roundtrip(self, tmp_path):
        """تصدير ثم تحميل يُرجع نفس البيانات"""
        path = tmp_path / "roundtrip.csv"
        export_to_csv(SAMPLE_DEVICES, path)
        loaded = load_from_csv(path)

        assert len(loaded) == len(SAMPLE_DEVICES)
        ips = {d.ip for d in loaded}
        for device in SAMPLE_DEVICES:
            assert device.ip in ips

    def test_load_from_csv_missing_file(self, tmp_path):
        """يُرفع CSVExportError إذا كان الملف غير موجود"""
        with pytest.raises(CSVExportError):
            load_from_csv(tmp_path / "nonexistent.csv")


# ---------------------------------------------------------------
# اختبارات _parse_ports_from_csv
# ---------------------------------------------------------------

class TestParsePortsFromCSV:

    def test_parses_pipe_separated(self):
        assert _parse_ports_from_csv("80 | 443 | 502") == [80, 443, 502]

    def test_parses_comma_separated(self):
        assert _parse_ports_from_csv("80,443,502") == [80, 443, 502]

    def test_parses_single_port(self):
        assert _parse_ports_from_csv("502") == [502]

    def test_empty_string_returns_empty(self):
        assert _parse_ports_from_csv("") == []

    def test_ignores_invalid_values(self):
        assert _parse_ports_from_csv("80 | abc | 443") == [80, 443]

    def test_removes_duplicates(self):
        assert _parse_ports_from_csv("80 | 80 | 443") == [80, 443]


# ---------------------------------------------------------------
# اختبارات exporter.py (الواجهة الموحّدة)
# ---------------------------------------------------------------

class TestExportResults:

    def test_exports_json_only(self, tmp_path):
        """يُصدّر JSON فقط"""
        result = export_results(
            devices=SAMPLE_DEVICES,
            formats=["json"],
            output_path=str(tmp_path / "results"),
            query="port:502",
        )
        assert result.success
        assert result.json_path is not None
        assert result.csv_path is None
        assert result.json_path.exists()

    def test_exports_csv_only(self, tmp_path):
        """يُصدّر CSV فقط"""
        result = export_results(
            devices=SAMPLE_DEVICES,
            formats=["csv"],
            output_path=str(tmp_path / "results"),
        )
        assert result.success
        assert result.csv_path is not None
        assert result.json_path is None
        assert result.csv_path.exists()

    def test_exports_both_formats(self, tmp_path):
        """يُصدّر JSON و CSV معاً"""
        result = export_results(
            devices=SAMPLE_DEVICES,
            formats=["json", "csv"],
            output_path=str(tmp_path / "results"),
            query="port:502",
        )
        assert result.success
        assert result.json_path is not None
        assert result.csv_path is not None
        assert result.json_path.exists()
        assert result.csv_path.exists()

    def test_records_count_correct(self, tmp_path):
        """عدد السجلات صحيح في النتيجة"""
        result = export_results(
            devices=SAMPLE_DEVICES,
            formats=["json"],
            output_path=str(tmp_path / "results"),
        )
        assert result.records_count == len(SAMPLE_DEVICES)

    def test_auto_generates_filename_when_no_path(self, tmp_path):
        """يُولّد اسم ملف تلقائياً عند عدم تحديد مسار"""
        import os
        original_dir = os.getcwd()
        try:
            os.chdir(tmp_path)
            result = export_results(
                devices=SAMPLE_DEVICES,
                formats=["json"],
                output_path="",
            )
            assert result.json_path is not None
        finally:
            os.chdir(original_dir)

    def test_summary_contains_paths(self, tmp_path):
        """الملخص يحتوي على مسارات الملفات"""
        result = export_results(
            devices=SAMPLE_DEVICES,
            formats=["json", "csv"],
            output_path=str(tmp_path / "results"),
        )
        summary = result.summary()
        assert "JSON" in summary
        assert "CSV" in summary

    def test_exported_paths_returns_list(self, tmp_path):
        """exported_paths يُرجع قائمة المسارات"""
        result = export_results(
            devices=SAMPLE_DEVICES,
            formats=["json", "csv"],
            output_path=str(tmp_path / "results"),
        )
        paths = result.exported_paths()
        assert len(paths) == 2

    def test_case_insensitive_format_names(self, tmp_path):
        """أسماء الصيغ غير حساسة لحالة الأحرف"""
        result = export_results(
            devices=SAMPLE_DEVICES,
            formats=["JSON", "CSV"],
            output_path=str(tmp_path / "results"),
        )
        assert result.json_path is not None
        assert result.csv_path is not None

    def test_export_result_success_property(self, tmp_path):
        """خاصية success تعمل بشكل صحيح"""
        result = export_results(
            devices=SAMPLE_DEVICES,
            formats=["json"],
            output_path=str(tmp_path / "results"),
        )
        assert result.success is True

    def test_json_file_content_matches_devices(self, tmp_path):
        """محتوى ملف JSON يتطابق مع البيانات المُصدَّرة"""
        result = export_results(
            devices=SAMPLE_DEVICES,
            formats=["json"],
            output_path=str(tmp_path / "results"),
            query="port:502",
        )
        with open(result.json_path, encoding="utf-8") as f:
            data = json.load(f)

        assert data["metadata"]["total_results"] == len(SAMPLE_DEVICES)
        exported_ips = {r["ip"] for r in data["results"]}
        original_ips = {d.ip for d in SAMPLE_DEVICES}
        assert exported_ips == original_ips
