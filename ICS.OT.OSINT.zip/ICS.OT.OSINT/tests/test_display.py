"""
tests/test_display.py
=====================
اختبارات وحدة العرض.

المنهجية:
- نُمرّر Console وهمي يكتب في StringIO بدلاً من Terminal
- نتحقق من أن المخرجات تحتوي على البيانات الصحيحة
- لا نختبر الألوان (Rich markup) — نختبر المحتوى فقط

شغّل: python -m pytest tests/test_display.py -v
"""

import pytest
from io import StringIO
from unittest.mock import patch, MagicMock
from rich.console import Console

from ics_osint.processing.extractor import DeviceRecord
from ics_osint.display.tables import (
    print_devices_table,
    print_stats_table,
    print_countries_table,
    print_ports_table,
    print_orgs_table,
    print_account_table,
    print_templates_table,
    _format_ports,
    _make_bar,
    _truncate,
)
from ics_osint.display.messages import (
    print_success, print_error, print_warning,
    print_info, print_dim,
)
from ics_osint.display.progress import SearchProgress


# ---------------------------------------------------------------
# Fixture: Console وهمي يكتب في StringIO
# ---------------------------------------------------------------

@pytest.fixture
def fake_console():
    """يُنشئ Console يكتب في StringIO بدلاً من Terminal"""
    buffer = StringIO()
    con = Console(file=buffer, highlight=False, markup=False, width=120)
    return con, buffer


@pytest.fixture
def sample_devices():
    return [
        DeviceRecord("1.2.3.4",   "US", "United States", "New York", "Corp A",   [80, 502]),
        DeviceRecord("5.6.7.8",   "DE", "Germany",        "Berlin",  "Corp B",   [502]),
        DeviceRecord("9.10.11.12","SA", "Saudi Arabia",   "Riyadh",  "Corp C",   [20000, 502]),
        DeviceRecord("10.0.0.1",  "CN", "China",          "Beijing", "N/A",      [102]),
    ]


@pytest.fixture
def sample_stats():
    return {
        "total_devices":     4,
        "unique_ips":        4,
        "unique_countries":  4,
        "unique_orgs":       3,
        "unique_ports":      4,
        "devices_with_org":  3,
        "devices_with_city": 4,
    }


# ---------------------------------------------------------------
# اختبارات _format_ports (دالة مساعدة)
# ---------------------------------------------------------------

class TestFormatPorts:

    def test_empty_ports_returns_dash(self):
        result = _format_ports([])
        assert "—" in result

    def test_single_port(self):
        result = _format_ports([502])
        assert "502" in result

    def test_multiple_ports_sorted(self):
        result = _format_ports([443, 80, 502])
        # يجب أن تظهر البورتات مُرتّبة
        pos_80  = result.find("80")
        pos_443 = result.find("443")
        pos_502 = result.find("502")
        assert pos_80 < pos_443 < pos_502

    def test_truncates_long_port_list(self):
        """يُضيف "+" عند وجود بورتات أكثر من max_ports"""
        ports = [80, 443, 502, 8080, 8443, 9090, 9999]
        result = _format_ports(ports, max_ports=6)
        assert "+" in result

    def test_no_truncation_when_within_limit(self):
        ports = [80, 443, 502]
        result = _format_ports(ports, max_ports=6)
        assert "+" not in result


# ---------------------------------------------------------------
# اختبارات _make_bar (دالة مساعدة)
# ---------------------------------------------------------------

class TestMakeBar:

    def test_full_bar_when_value_equals_max(self):
        bar = _make_bar(10, 10, width=10)
        assert bar == "██████████"

    def test_empty_bar_when_value_is_zero(self):
        bar = _make_bar(0, 10, width=10)
        assert bar == "░░░░░░░░░░"

    def test_half_bar(self):
        bar = _make_bar(5, 10, width=10)
        assert bar == "█████░░░░░"

    def test_zero_max_returns_empty(self):
        bar = _make_bar(5, 0, width=10)
        assert bar == ""

    def test_correct_total_length(self):
        bar = _make_bar(3, 10, width=15)
        # نُزيل Rich markup قبل حساب الطول
        clean = bar.replace("[", "").replace("]", "")
        assert len(bar) == 15


# ---------------------------------------------------------------
# اختبارات _truncate (دالة مساعدة)
# ---------------------------------------------------------------

class TestTruncate:

    def test_short_text_unchanged(self):
        assert _truncate("Hello", 10) == "Hello"

    def test_exact_length_unchanged(self):
        assert _truncate("Hello", 5) == "Hello"

    def test_long_text_truncated(self):
        result = _truncate("Hello World", 8)
        assert len(result) == 8
        assert result.endswith("…")

    def test_custom_suffix(self):
        result = _truncate("Hello World", 8, suffix="...")
        assert result.endswith("...")


# ---------------------------------------------------------------
# اختبارات print_devices_table
# ---------------------------------------------------------------

class TestPrintDevicesTable:

    def test_prints_ip_addresses(self, sample_devices):
        """يطبع عناوين IP في الجدول"""
        buffer = StringIO()
        test_console = Console(file=buffer, highlight=False, markup=False, width=150)

        with patch("ics_osint.display.tables.console", test_console):
            print_devices_table(sample_devices)

        output = buffer.getvalue()
        assert "1.2.3.4"    in output
        assert "5.6.7.8"    in output
        assert "9.10.11.12" in output

    def test_prints_country_codes(self, sample_devices):
        """يطبع رموز الدول"""
        buffer = StringIO()
        test_console = Console(file=buffer, highlight=False, markup=False, width=150)

        with patch("ics_osint.display.tables.console", test_console):
            print_devices_table(sample_devices)

        output = buffer.getvalue()
        assert "US" in output
        assert "DE" in output
        assert "SA" in output

    def test_prints_organizations(self, sample_devices):
        """يطبع أسماء الشركات"""
        buffer = StringIO()
        test_console = Console(file=buffer, highlight=False, markup=False, width=150)

        with patch("ics_osint.display.tables.console", test_console):
            print_devices_table(sample_devices)

        output = buffer.getvalue()
        assert "Corp A" in output
        assert "Corp B" in output

    def test_empty_devices_shows_no_results(self):
        """قائمة فارغة تعرض رسالة 'لا توجد نتائج'"""
        buffer = StringIO()
        test_console = Console(file=buffer, highlight=False, markup=False, width=150)

        with patch("ics_osint.display.tables.console", test_console):
            print_devices_table([])

        output = buffer.getvalue()
        assert "لا توجد نتائج" in output

    def test_max_rows_limits_display(self, sample_devices):
        """max_rows يُحدّد عدد الصفوف المعروضة"""
        buffer = StringIO()
        test_console = Console(file=buffer, highlight=False, markup=False, width=150)

        with patch("ics_osint.display.tables.console", test_console):
            print_devices_table(sample_devices, max_rows=2)

        output = buffer.getvalue()
        # الجهاز الثالث لا يجب أن يظهر
        assert "9.10.11.12" not in output
        # يجب أن يظهر تنبيه بالصفوف المخفية
        assert "نتيجة أخرى" in output or "غير معروضة" in output

    def test_custom_title_displayed(self, sample_devices):
        """العنوان المخصص يظهر في الجدول"""
        buffer = StringIO()
        test_console = Console(file=buffer, highlight=False, markup=False, width=150)

        with patch("ics_osint.display.tables.console", test_console):
            print_devices_table(sample_devices, title="نتائج Modbus")

        output = buffer.getvalue()
        assert "نتائج Modbus" in output


# ---------------------------------------------------------------
# اختبارات print_stats_table
# ---------------------------------------------------------------

class TestPrintStatsTable:

    def test_prints_total_devices(self, sample_stats):
        buffer = StringIO()
        test_console = Console(file=buffer, highlight=False, markup=False, width=120)

        with patch("ics_osint.display.tables.console", test_console):
            print_stats_table(sample_stats)

        output = buffer.getvalue()
        assert "4" in output  # total_devices = 4

    def test_prints_all_stat_labels(self, sample_stats):
        buffer = StringIO()
        test_console = Console(file=buffer, highlight=False, markup=False, width=120)

        with patch("ics_osint.display.tables.console", test_console):
            print_stats_table(sample_stats)

        output = buffer.getvalue()
        assert "إجمالي الأجهزة" in output
        assert "عدد الدول"       in output


# ---------------------------------------------------------------
# اختبارات print_countries_table
# ---------------------------------------------------------------

class TestPrintCountriesTable:

    def test_prints_country_data(self):
        country_data = [
            {"country_code": "US", "country_name": "United States", "count": 45, "percentage": 45.0},
            {"country_code": "DE", "country_name": "Germany",        "count": 23, "percentage": 23.0},
        ]
        buffer = StringIO()
        test_console = Console(file=buffer, highlight=False, markup=False, width=120)

        with patch("ics_osint.display.tables.console", test_console):
            print_countries_table(country_data)

        output = buffer.getvalue()
        assert "United States" in output
        assert "Germany"       in output
        assert "45"            in output

    def test_empty_data_prints_nothing(self):
        """قائمة فارغة لا تطبع شيئاً"""
        buffer = StringIO()
        test_console = Console(file=buffer, highlight=False, markup=False, width=120)

        with patch("ics_osint.display.tables.console", test_console):
            print_countries_table([])

        assert buffer.getvalue() == ""


# ---------------------------------------------------------------
# اختبارات print_ports_table
# ---------------------------------------------------------------

class TestPrintPortsTable:

    def test_prints_port_numbers(self):
        port_data = [(502, 67), (20000, 23), (102, 12)]
        buffer = StringIO()
        test_console = Console(file=buffer, highlight=False, markup=False, width=120)

        with patch("ics_osint.display.tables.console", test_console):
            print_ports_table(port_data)

        output = buffer.getvalue()
        assert "502"   in output
        assert "20000" in output

    def test_shows_ics_protocol_names(self):
        """يعرض أسماء بروتوكولات ICS المعروفة"""
        port_data = [(502, 50), (20000, 30)]
        buffer = StringIO()
        test_console = Console(file=buffer, highlight=False, markup=False, width=120)

        with patch("ics_osint.display.tables.console", test_console):
            print_ports_table(port_data)

        output = buffer.getvalue()
        assert "Modbus" in output
        assert "DNP3"   in output

    def test_empty_data_prints_nothing(self):
        buffer = StringIO()
        test_console = Console(file=buffer, highlight=False, markup=False, width=120)

        with patch("ics_osint.display.tables.console", test_console):
            print_ports_table([])

        assert buffer.getvalue() == ""


# ---------------------------------------------------------------
# اختبارات print_orgs_table
# ---------------------------------------------------------------

class TestPrintOrgsTable:

    def test_prints_org_names(self):
        org_data = [("Siemens AG", 12), ("Rockwell", 8), ("ABB Ltd", 5)]
        buffer = StringIO()
        test_console = Console(file=buffer, highlight=False, markup=False, width=120)

        with patch("ics_osint.display.tables.console", test_console):
            print_orgs_table(org_data)

        output = buffer.getvalue()
        assert "Siemens AG" in output
        assert "Rockwell"   in output

    def test_prints_counts(self):
        org_data = [("Corp A", 42)]
        buffer = StringIO()
        test_console = Console(file=buffer, highlight=False, markup=False, width=120)

        with patch("ics_osint.display.tables.console", test_console):
            print_orgs_table(org_data)

        output = buffer.getvalue()
        assert "42" in output


# ---------------------------------------------------------------
# اختبارات print_account_table
# ---------------------------------------------------------------

class TestPrintAccountTable:

    def test_prints_plan_and_credits(self):
        account_info = {
            "plan": "dev",
            "query_credits": 100,
            "scan_credits": 100,
            "unlocked": True,
        }
        buffer = StringIO()
        test_console = Console(file=buffer, highlight=False, markup=False, width=120)

        with patch("ics_osint.display.tables.console", test_console):
            print_account_table(account_info)

        output = buffer.getvalue()
        assert "dev" in output
        assert "100" in output


# ---------------------------------------------------------------
# اختبارات print_templates_table
# ---------------------------------------------------------------

class TestPrintTemplatesTable:

    def test_prints_all_templates(self):
        from ics_osint.config.constants import ICS_QUERY_TEMPLATES
        buffer = StringIO()
        test_console = Console(file=buffer, highlight=False, markup=False, width=160)

        with patch("ics_osint.display.tables.console", test_console):
            print_templates_table(ICS_QUERY_TEMPLATES)

        output = buffer.getvalue()
        assert "modbus"  in output
        assert "dnp3"    in output
        assert "bacnet"  in output
        assert "port:502" in output


# ---------------------------------------------------------------
# اختبارات رسائل messages.py
# ---------------------------------------------------------------

class TestMessages:

    def _capture(self, func, *args, **kwargs) -> str:
        """يُشغّل دالة طباعة ويلتقط مخرجاتها"""
        buffer = StringIO()
        test_console = Console(file=buffer, highlight=False, markup=False, width=120)

        with patch("ics_osint.display.messages.console", test_console), \
             patch("ics_osint.display.messages.err_console", test_console):
            func(*args, **kwargs)

        return buffer.getvalue()

    def test_print_success_contains_checkmark(self):
        output = self._capture(print_success, "تم بنجاح")
        assert "✓" in output
        assert "تم بنجاح" in output

    def test_print_error_contains_x(self):
        output = self._capture(print_error, "حدث خطأ", to_stderr=False)
        assert "✗" in output
        assert "حدث خطأ" in output

    def test_print_warning_contains_symbol(self):
        output = self._capture(print_warning, "تحذير مهم")
        assert "⚠" in output
        assert "تحذير مهم" in output

    def test_print_info_contains_symbol(self):
        output = self._capture(print_info, "معلومة")
        assert "ℹ" in output
        assert "معلومة" in output

    def test_print_dim_contains_text(self):
        output = self._capture(print_dim, "نص خافت")
        assert "نص خافت" in output


# ---------------------------------------------------------------
# اختبارات SearchProgress
# ---------------------------------------------------------------

class TestSearchProgress:

    def test_context_manager_starts_and_stops(self):
        """يعمل كـ context manager بدون أخطاء"""
        with patch("ics_osint.display.progress.console"):
            sp = SearchProgress(max_pages=3)
            # نُعطّل Progress الفعلي لتجنب طباعة في الاختبارات
            sp._progress = MagicMock()
            sp._progress.add_task.return_value = 0

            with sp as progress:
                progress.update(1, total_pages=3, results_count=50)
                progress.update(2, total_pages=3, results_count=100)

            # يجب أن يُستدعى stop
            sp._progress.stop.assert_called_once()

    def test_callback_calls_update(self):
        """callback يستدعي update بالمعاملات الصحيحة"""
        with patch("ics_osint.display.progress.console"):
            sp = SearchProgress(max_pages=3)
            sp._progress = MagicMock()
            sp._progress.add_task.return_value = 0
            sp._task_id = 0

            sp.callback(2, 3, 150)

            assert sp._results_count == 150

    def test_update_tracks_results_count(self):
        """update يتتبع عدد النتائج"""
        with patch("ics_osint.display.progress.console"):
            sp = SearchProgress(max_pages=5)
            sp._progress = MagicMock()
            sp._progress.add_task.return_value = 0
            sp._task_id = 0

            sp.update(1, 5, 100)
            assert sp._results_count == 100

            sp.update(2, 5, 200)
            assert sp._results_count == 200

    def test_no_crash_when_task_id_is_none(self):
        """لا يحدث crash إذا استُدعي update قبل start"""
        with patch("ics_osint.display.progress.console"):
            sp = SearchProgress(max_pages=3)
            sp._progress = MagicMock()
            # _task_id = None (لم يُستدعَ start بعد)
            sp.update(1, 3, 50)  # يجب ألا يُرفع استثناء
