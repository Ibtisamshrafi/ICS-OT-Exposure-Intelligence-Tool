"""
tests/test_processing.py
========================
اختبارات وحدة معالجة البيانات — تعمل بدون Shodan API.

شغّل: python -m pytest tests/test_processing.py -v
"""

import pytest
from ics_osint.processing.extractor import DeviceRecord, extract_device, extract_devices, _parse_ports
from ics_osint.processing.filters import (
    deduplicate, filter_by_country, filter_by_countries,
    filter_by_port, filter_by_ports, filter_by_org,
    filter_has_org, filter_has_city, apply_filters, get_filter_stats,
)
from ics_osint.processing.aggregator import (
    get_summary_stats, group_by_country, group_by_port,
    group_by_org, generate_report,
)


# ---------------------------------------------------------------
# بيانات وهمية مشتركة
# ---------------------------------------------------------------

RAW_VALID = {
    "ip_str": "1.2.3.4",
    "location": {
        "country_code": "US",
        "country_name": "United States",
        "city": "New York",
    },
    "org": "Example Corp",
    "ports": [80, 443, 502],
}

RAW_MINIMAL = {
    "ip_str": "5.6.7.8",
    # بدون location أو org
}

RAW_NO_IP = {
    "location": {"country_code": "DE"},
    "org": "German Corp",
    "ports": [502],
}

RAW_SINGLE_PORT = {
    "ip_str": "9.10.11.12",
    "location": {"country_code": "SA", "country_name": "Saudi Arabia", "city": "Riyadh"},
    "org": "Saudi Telecom",
    "port": 502,   # مفرد وليس قائمة
}

RAW_NULL_LOCATION = {
    "ip_str": "10.0.0.1",
    "location": None,
    "org": None,
    "ports": [20000],
}


def make_device(ip="1.1.1.1", country_code="US", country_name="United States",
                city="New York", org="Corp A", ports=None) -> DeviceRecord:
    """مساعد لإنشاء DeviceRecord بسرعة في الاختبارات"""
    return DeviceRecord(
        ip=ip,
        country_code=country_code,
        country_name=country_name,
        city=city,
        org=org,
        ports=ports or [502],
    )


# ---------------------------------------------------------------
# اختبارات DeviceRecord
# ---------------------------------------------------------------

class TestDeviceRecord:

    def test_to_dict_returns_all_fields(self):
        """to_dict يُرجع جميع الحقول"""
        d = make_device()
        result = d.to_dict()
        assert "ip" in result
        assert "country_code" in result
        assert "country_name" in result
        assert "city" in result
        assert "org" in result
        assert "ports" in result

    def test_ports_as_string_sorted(self):
        """ports_as_string يُرجع البورتات مُرتّبة"""
        d = make_device(ports=[443, 80, 502])
        assert d.ports_as_string() == "80, 443, 502"

    def test_ports_as_string_custom_separator(self):
        """ports_as_string يدعم separator مخصص"""
        d = make_device(ports=[80, 443])
        assert d.ports_as_string("|") == "80|443"

    def test_equality_based_on_ip(self):
        """جهازان بنفس الـ IP يُعتبران متساويين"""
        d1 = make_device(ip="1.1.1.1", org="Corp A")
        d2 = make_device(ip="1.1.1.1", org="Corp B")
        assert d1 == d2

    def test_inequality_different_ip(self):
        """جهازان بـ IP مختلف يُعتبران مختلفين"""
        d1 = make_device(ip="1.1.1.1")
        d2 = make_device(ip="2.2.2.2")
        assert d1 != d2

    def test_hashable_for_set(self):
        """DeviceRecord قابل للاستخدام في set"""
        d1 = make_device(ip="1.1.1.1")
        d2 = make_device(ip="1.1.1.1")
        d3 = make_device(ip="2.2.2.2")
        s = {d1, d2, d3}
        assert len(s) == 2  # d1 و d2 نفس الـ IP


# ---------------------------------------------------------------
# اختبارات extract_device
# ---------------------------------------------------------------

class TestExtractDevice:

    def test_extracts_all_fields_correctly(self):
        """يستخرج جميع الحقول بشكل صحيح"""
        result = extract_device(RAW_VALID)
        assert result is not None
        assert result.ip == "1.2.3.4"
        assert result.country_code == "US"
        assert result.country_name == "United States"
        assert result.city == "New York"
        assert result.org == "Example Corp"
        assert 502 in result.ports

    def test_returns_none_when_no_ip(self):
        """يُرجع None إذا كان ip_str مفقوداً"""
        result = extract_device(RAW_NO_IP)
        assert result is None

    def test_returns_none_for_non_dict(self):
        """يُرجع None إذا كان المدخل ليس dict"""
        assert extract_device(None) is None
        assert extract_device("string") is None
        assert extract_device(123) is None

    def test_handles_minimal_data(self):
        """يتعامل مع بيانات ناقصة بدون crash"""
        result = extract_device(RAW_MINIMAL)
        assert result is not None
        assert result.ip == "5.6.7.8"
        assert result.country_code == "N/A"
        assert result.org == "N/A"
        assert result.ports == []

    def test_handles_null_location(self):
        """يتعامل مع location = None"""
        result = extract_device(RAW_NULL_LOCATION)
        assert result is not None
        assert result.country_code == "N/A"
        assert result.org == "N/A"
        assert 20000 in result.ports

    def test_handles_single_port(self):
        """يتعامل مع port مفرد (وليس قائمة)"""
        result = extract_device(RAW_SINGLE_PORT)
        assert result is not None
        assert result.ports == [502]

    def test_uses_isp_when_org_missing(self):
        """يستخدم isp إذا كان org مفقوداً"""
        raw = {
            "ip_str": "1.1.1.1",
            "isp": "Fallback ISP",
            "ports": [],
        }
        result = extract_device(raw)
        assert result.org == "Fallback ISP"

    def test_strips_whitespace_from_fields(self):
        """يُزيل المسافات الزائدة من الحقول"""
        raw = {
            "ip_str": "  1.2.3.4  ",
            "location": {"country_code": " US ", "country_name": " United States "},
            "org": "  Corp  ",
            "ports": [502],
        }
        result = extract_device(raw)
        assert result.ip == "1.2.3.4"
        assert result.country_code == "US"
        assert result.org == "Corp"


# ---------------------------------------------------------------
# اختبارات extract_devices
# ---------------------------------------------------------------

class TestExtractDevices:

    def test_extracts_multiple_records(self):
        """يستخرج قائمة من السجلات"""
        raw_list = [RAW_VALID, RAW_MINIMAL]
        results = extract_devices(raw_list)
        assert len(results) == 2

    def test_skips_invalid_records(self):
        """يتجاهل السجلات التالفة"""
        raw_list = [RAW_VALID, RAW_NO_IP, {"invalid": "data"}]
        results = extract_devices(raw_list)
        assert len(results) == 1
        assert results[0].ip == "1.2.3.4"

    def test_returns_empty_for_empty_input(self):
        """يُرجع قائمة فارغة للمدخل الفارغ"""
        assert extract_devices([]) == []
        assert extract_devices(None) == []


# ---------------------------------------------------------------
# اختبارات _parse_ports
# ---------------------------------------------------------------

class TestParsePorts:

    def test_parses_valid_ports(self):
        assert _parse_ports([80, 443, 502]) == [80, 443, 502]

    def test_removes_duplicates(self):
        assert _parse_ports([80, 80, 443]) == [80, 443]

    def test_sorts_ascending(self):
        assert _parse_ports([502, 80, 443]) == [80, 443, 502]

    def test_ignores_invalid_values(self):
        assert _parse_ports([80, None, "abc", -1, 0, 65536]) == [80]

    def test_handles_string_numbers(self):
        """يتعامل مع أرقام كـ strings"""
        assert _parse_ports(["80", "443"]) == [80, 443]

    def test_empty_list(self):
        assert _parse_ports([]) == []


# ---------------------------------------------------------------
# اختبارات deduplicate
# ---------------------------------------------------------------

class TestDeduplicate:

    def test_removes_duplicate_ips(self):
        """يُزيل السجلات المكررة بناءً على IP"""
        devices = [
            make_device(ip="1.1.1.1"),
            make_device(ip="2.2.2.2"),
            make_device(ip="1.1.1.1"),  # مكرر
        ]
        result = deduplicate(devices)
        assert len(result) == 2

    def test_preserves_order(self):
        """يحافظ على ترتيب الظهور الأول"""
        devices = [
            make_device(ip="3.3.3.3"),
            make_device(ip="1.1.1.1"),
            make_device(ip="2.2.2.2"),
            make_device(ip="1.1.1.1"),
        ]
        result = deduplicate(devices)
        assert [d.ip for d in result] == ["3.3.3.3", "1.1.1.1", "2.2.2.2"]

    def test_no_duplicates_unchanged(self):
        """قائمة بدون تكرار تبقى كما هي"""
        devices = [make_device(ip=f"1.1.1.{i}") for i in range(5)]
        result = deduplicate(devices)
        assert len(result) == 5


# ---------------------------------------------------------------
# اختبارات filter_by_country
# ---------------------------------------------------------------

class TestFilterByCountry:

    def test_filters_correctly(self):
        devices = [
            make_device(ip="1.1.1.1", country_code="US"),
            make_device(ip="2.2.2.2", country_code="DE"),
            make_device(ip="3.3.3.3", country_code="US"),
        ]
        result = filter_by_country(devices, "US")
        assert len(result) == 2
        assert all(d.country_code == "US" for d in result)

    def test_case_insensitive(self):
        """غير حساس لحالة الأحرف"""
        devices = [make_device(country_code="US")]
        assert len(filter_by_country(devices, "us")) == 1
        assert len(filter_by_country(devices, "Us")) == 1

    def test_empty_country_returns_all(self):
        """country_code فارغ يُرجع كل الأجهزة"""
        devices = [make_device(), make_device(ip="2.2.2.2")]
        assert len(filter_by_country(devices, "")) == 2

    def test_no_match_returns_empty(self):
        devices = [make_device(country_code="US")]
        assert filter_by_country(devices, "SA") == []


# ---------------------------------------------------------------
# اختبارات filter_by_port
# ---------------------------------------------------------------

class TestFilterByPort:

    def test_filters_by_single_port(self):
        devices = [
            make_device(ip="1.1.1.1", ports=[80, 502]),
            make_device(ip="2.2.2.2", ports=[80, 443]),
            make_device(ip="3.3.3.3", ports=[502]),
        ]
        result = filter_by_port(devices, 502)
        assert len(result) == 2
        assert all(502 in d.ports for d in result)

    def test_none_port_returns_all(self):
        devices = [make_device(), make_device(ip="2.2.2.2")]
        assert len(filter_by_port(devices, None)) == 2

    def test_no_match_returns_empty(self):
        devices = [make_device(ports=[80, 443])]
        assert filter_by_port(devices, 502) == []


# ---------------------------------------------------------------
# اختبارات filter_by_org
# ---------------------------------------------------------------

class TestFilterByOrg:

    def test_filters_by_keyword(self):
        devices = [
            make_device(ip="1.1.1.1", org="Siemens AG"),
            make_device(ip="2.2.2.2", org="Rockwell Automation"),
            make_device(ip="3.3.3.3", org="Siemens Industrial"),
        ]
        result = filter_by_org(devices, "siemens")
        assert len(result) == 2

    def test_case_insensitive_by_default(self):
        devices = [make_device(org="SIEMENS AG")]
        assert len(filter_by_org(devices, "siemens")) == 1

    def test_case_sensitive_mode(self):
        devices = [make_device(org="SIEMENS AG")]
        assert len(filter_by_org(devices, "siemens", case_sensitive=True)) == 0
        assert len(filter_by_org(devices, "SIEMENS", case_sensitive=True)) == 1

    def test_empty_keyword_returns_all(self):
        devices = [make_device(), make_device(ip="2.2.2.2")]
        assert len(filter_by_org(devices, "")) == 2


# ---------------------------------------------------------------
# اختبارات filter_has_org و filter_has_city
# ---------------------------------------------------------------

class TestFilterHasFields:

    def test_filter_has_org_excludes_na(self):
        devices = [
            make_device(ip="1.1.1.1", org="Real Corp"),
            make_device(ip="2.2.2.2", org="N/A"),
            make_device(ip="3.3.3.3", org=""),
        ]
        result = filter_has_org(devices)
        assert len(result) == 1
        assert result[0].ip == "1.1.1.1"

    def test_filter_has_city_excludes_na(self):
        devices = [
            make_device(ip="1.1.1.1", city="New York"),
            make_device(ip="2.2.2.2", city="N/A"),
        ]
        result = filter_has_city(devices)
        assert len(result) == 1


# ---------------------------------------------------------------
# اختبارات apply_filters (Pipeline)
# ---------------------------------------------------------------

class TestApplyFilters:

    def test_applies_multiple_filters(self):
        """يُطبّق عدة فلاتر معاً"""
        devices = [
            make_device(ip="1.1.1.1", country_code="US", ports=[502], org="Corp A"),
            make_device(ip="2.2.2.2", country_code="DE", ports=[502], org="Corp B"),
            make_device(ip="3.3.3.3", country_code="US", ports=[80],  org="Corp C"),
            make_device(ip="1.1.1.1", country_code="US", ports=[502], org="Corp A"),  # مكرر
        ]
        result = apply_filters(
            devices,
            country_code="US",
            port=502,
            remove_duplicates=True,
        )
        # US + port 502 + بدون تكرار = 1 جهاز فقط
        assert len(result) == 1
        assert result[0].ip == "1.1.1.1"

    def test_no_filters_returns_deduplicated(self):
        """بدون فلاتر يُرجع القائمة بعد إزالة التكرار فقط"""
        devices = [
            make_device(ip="1.1.1.1"),
            make_device(ip="1.1.1.1"),
            make_device(ip="2.2.2.2"),
        ]
        result = apply_filters(devices)
        assert len(result) == 2

    def test_require_org_filter(self):
        """require_org يستبعد الأجهزة بدون شركة"""
        devices = [
            make_device(ip="1.1.1.1", org="Real Corp"),
            make_device(ip="2.2.2.2", org="N/A"),
        ]
        result = apply_filters(devices, require_org=True)
        assert len(result) == 1

    def test_country_codes_list(self):
        """فلترة بقائمة دول"""
        devices = [
            make_device(ip="1.1.1.1", country_code="US"),
            make_device(ip="2.2.2.2", country_code="DE"),
            make_device(ip="3.3.3.3", country_code="SA"),
        ]
        result = apply_filters(devices, country_codes=["US", "SA"])
        assert len(result) == 2


# ---------------------------------------------------------------
# اختبارات get_filter_stats
# ---------------------------------------------------------------

class TestFilterStats:

    def test_calculates_stats_correctly(self):
        original = [make_device(ip=f"1.1.1.{i}") for i in range(10)]
        filtered = original[:4]
        stats = get_filter_stats(original, filtered)

        assert stats["original_count"] == 10
        assert stats["filtered_count"] == 4
        assert stats["removed_count"]  == 6
        assert stats["retention_pct"]  == 40.0

    def test_handles_empty_original(self):
        stats = get_filter_stats([], [])
        assert stats["retention_pct"] == 0


# ---------------------------------------------------------------
# اختبارات aggregator
# ---------------------------------------------------------------

class TestAggregator:

    @pytest.fixture
    def sample_devices(self):
        return [
            make_device(ip="1.1.1.1", country_code="US", org="Corp A", ports=[502, 80]),
            make_device(ip="2.2.2.2", country_code="US", org="Corp B", ports=[502]),
            make_device(ip="3.3.3.3", country_code="DE", org="Corp C", ports=[20000]),
            make_device(ip="4.4.4.4", country_code="SA", org="N/A",   ports=[502, 443]),
        ]

    def test_summary_stats(self, sample_devices):
        stats = get_summary_stats(sample_devices)
        assert stats["total_devices"]    == 4
        assert stats["unique_countries"] == 3
        assert stats["devices_with_org"] == 3  # Corp A, B, C (N/A مستبعد)

    def test_group_by_country(self, sample_devices):
        result = group_by_country(sample_devices)
        # US يجب أن يكون الأول (2 أجهزة)
        assert result[0][0] == "US"
        assert result[0][1] == 2

    def test_group_by_port(self, sample_devices):
        result = group_by_port(sample_devices)
        # 502 يظهر في 3 أجهزة
        port_dict = dict(result)
        assert port_dict[502] == 3

    def test_group_by_org(self, sample_devices):
        result = group_by_org(sample_devices)
        # كل شركة تظهر مرة واحدة (N/A مستبعد)
        assert len(result) == 3

    def test_generate_report_structure(self, sample_devices):
        report = generate_report(sample_devices)
        assert "summary"       in report
        assert "top_countries" in report
        assert "top_ports"     in report
        assert "top_orgs"      in report
        assert "top_cities"    in report

    def test_empty_devices_summary(self):
        stats = get_summary_stats([])
        assert stats["total_devices"] == 0

    def test_top_n_limits_results(self, sample_devices):
        result = group_by_country(sample_devices, top_n=1)
        assert len(result) == 1
