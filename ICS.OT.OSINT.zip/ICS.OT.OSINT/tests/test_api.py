"""
tests/test_api.py
=================
اختبارات وحدة Shodan API — تعمل بدون مفتاح حقيقي عبر Mock.

شغّل: python -m pytest tests/test_api.py -v
"""

import pytest
from unittest.mock import MagicMock, patch, call
import time

import shodan

from ics_osint.api.client import ShodanClient
from ics_osint.api.exceptions import (
    ShodanAPIError,
    InvalidAPIKeyError,
    RateLimitError,
    NoCreditsError,
    NoResultsError,
    InvalidQueryError,
)
from ics_osint.api import exceptions as api_exc
from ics_osint.api.retry import with_retry


# ---------------------------------------------------------------
# بيانات وهمية للاختبارات
# ---------------------------------------------------------------

FAKE_API_KEY = "testkey1234567890abcdef"

FAKE_ACCOUNT_INFO = {
    "plan": "dev",
    "query_credits": 100,
    "scan_credits": 100,
    "unlocked": True,
    "unlocked_left": 1,
    "telnet": False,
}

FAKE_SEARCH_RESULT = {
    "total": 250,
    "matches": [
        {
            "ip_str": "1.2.3.4",
            "location": {"country_code": "US", "country_name": "United States", "city": "New York"},
            "org": "Example Corp",
            "ports": [502, 80],
            "data": "Modbus banner data",
        },
        {
            "ip_str": "5.6.7.8",
            "location": {"country_code": "DE", "country_name": "Germany", "city": "Berlin"},
            "org": "German Industrial GmbH",
            "ports": [502],
            "data": "Modbus device",
        },
    ],
}

FAKE_EMPTY_RESULT = {
    "total": 0,
    "matches": [],
}


# ---------------------------------------------------------------
# Fixture: ShodanClient مع Shodan API مُزيّف
# ---------------------------------------------------------------

@pytest.fixture
def mock_client():
    """يُنشئ ShodanClient مع shodan.Shodan مُزيّف"""
    with patch("ics_osint.api.client.shodan.Shodan") as mock_shodan_class:
        mock_api = MagicMock()
        mock_shodan_class.return_value = mock_api

        client = ShodanClient(FAKE_API_KEY)
        client.api = mock_api  # نُعيّن الـ mock مباشرة للتأكد

        yield client, mock_api


# ---------------------------------------------------------------
# اختبارات الإنشاء (Constructor)
# ---------------------------------------------------------------

class TestShodanClientInit:

    def test_raises_on_empty_key(self):
        """يُرفع InvalidAPIKeyError عند مفتاح فارغ"""
        with pytest.raises(InvalidAPIKeyError):
            ShodanClient("")

    def test_raises_on_whitespace_key(self):
        """يُرفع InvalidAPIKeyError عند مفتاح يحتوي مسافات فقط"""
        with pytest.raises(InvalidAPIKeyError):
            ShodanClient("   ")

    def test_strips_whitespace_from_key(self):
        """يُزيل المسافات من المفتاح عند الإنشاء"""
        with patch("ics_osint.api.client.shodan.Shodan"):
            client = ShodanClient("  mykey123  ")
            assert client.api_key == "mykey123"

    def test_initial_credits_is_none(self):
        """رصيد الـ credits يكون None قبل أي استعلام"""
        with patch("ics_osint.api.client.shodan.Shodan"):
            client = ShodanClient(FAKE_API_KEY)
            assert client.get_remaining_credits() is None


# ---------------------------------------------------------------
# اختبارات validate_key
# ---------------------------------------------------------------

class TestValidateKey:

    def test_valid_key_returns_account_info(self, mock_client):
        """مفتاح صالح يُرجع معلومات الحساب"""
        client, mock_api = mock_client
        mock_api.info.return_value = FAKE_ACCOUNT_INFO

        result = client.validate_key()

        assert result["plan"] == "dev"
        assert result["query_credits"] == 100
        mock_api.info.assert_called_once()

    def test_valid_key_updates_credits(self, mock_client):
        """التحقق من المفتاح يُحدّث رصيد الـ credits"""
        client, mock_api = mock_client
        mock_api.info.return_value = FAKE_ACCOUNT_INFO

        client.validate_key()

        assert client.get_remaining_credits() == 100

    def test_invalid_key_raises_error(self, mock_client):
        """مفتاح غير صالح يُرفع InvalidAPIKeyError"""
        client, mock_api = mock_client
        mock_api.info.side_effect = shodan.APIError("Invalid API key")

        with pytest.raises(InvalidAPIKeyError):
            client.validate_key()

    def test_connection_error_raises_custom_error(self, mock_client):
        """فشل الاتصال يُرفع api_exc.ConnectionError"""
        import requests as req
        client, mock_api = mock_client
        mock_api.info.side_effect = req.exceptions.ConnectionError("Network unreachable")

        with pytest.raises(api_exc.ConnectionError):
            client.validate_key()

    def test_timeout_raises_custom_error(self, mock_client):
        """انتهاء المهلة يُرفع api_exc.TimeoutError"""
        import requests as req
        client, mock_api = mock_client
        mock_api.info.side_effect = req.exceptions.Timeout("Connection timed out")

        with pytest.raises(api_exc.TimeoutError):
            client.validate_key()


# ---------------------------------------------------------------
# اختبارات search_page
# ---------------------------------------------------------------

class TestSearchPage:

    def test_returns_results_on_success(self, mock_client):
        """البحث الناجح يُرجع النتائج"""
        client, mock_api = mock_client
        mock_api.search.return_value = FAKE_SEARCH_RESULT

        result = client.search_page("port:502")

        assert result["total"] == 250
        assert len(result["matches"]) == 2
        mock_api.search.assert_called_once_with("port:502", page=1)

    def test_passes_page_number_correctly(self, mock_client):
        """رقم الصفحة يُمرَّر بشكل صحيح لـ Shodan"""
        client, mock_api = mock_client
        mock_api.search.return_value = FAKE_SEARCH_RESULT

        client.search_page("port:502", page=3)

        mock_api.search.assert_called_once_with("port:502", page=3)

    def test_empty_query_raises_invalid_query(self, mock_client):
        """استعلام فارغ يُرفع InvalidQueryError"""
        client, mock_api = mock_client

        with pytest.raises(InvalidQueryError):
            client.search_page("")

    def test_zero_results_raises_no_results(self, mock_client):
        """صفر نتائج في الصفحة الأولى يُرفع NoResultsError"""
        client, mock_api = mock_client
        mock_api.search.return_value = FAKE_EMPTY_RESULT

        with pytest.raises(NoResultsError):
            client.search_page("port:99999")

    def test_rate_limit_error_mapping(self, mock_client):
        """خطأ Rate Limit يُحوَّل لـ RateLimitError"""
        client, mock_api = mock_client
        mock_api.search.side_effect = shodan.APIError("Rate limit reached")

        with pytest.raises(RateLimitError):
            client.search_page("port:502")

    def test_no_credits_error_mapping(self, mock_client):
        """خطأ نفاد الرصيد يُحوَّل لـ NoCreditsError"""
        client, mock_api = mock_client
        mock_api.search.side_effect = shodan.APIError("query credits exceeded")

        with pytest.raises(NoCreditsError):
            client.search_page("port:502")

    def test_strips_query_whitespace(self, mock_client):
        """يُزيل المسافات من الاستعلام قبل الإرسال"""
        client, mock_api = mock_client
        mock_api.search.return_value = FAKE_SEARCH_RESULT

        client.search_page("  port:502  ")

        mock_api.search.assert_called_once_with("port:502", page=1)


# ---------------------------------------------------------------
# اختبارات search (Pagination)
# ---------------------------------------------------------------

class TestSearchPagination:

    def test_single_page_returns_all_matches(self, mock_client):
        """صفحة واحدة تُرجع جميع النتائج"""
        client, mock_api = mock_client
        mock_api.search.return_value = FAKE_SEARCH_RESULT

        results = client.search("port:502", max_pages=1)

        assert len(results) == 2
        assert mock_api.search.call_count == 1

    def test_multiple_pages_aggregated(self, mock_client):
        """صفحات متعددة تُجمَّع في قائمة واحدة"""
        client, mock_api = mock_client

        # صفحة 1: 100 نتيجة (الحد الأقصى — يعني هناك صفحة تالية)
        page1_matches = [{"ip_str": f"1.1.1.{i}"} for i in range(100)]
        page1 = {"total": 150, "matches": page1_matches}

        # صفحة 2: 50 نتيجة (أقل من الحد — آخر صفحة)
        page2_matches = [{"ip_str": f"2.2.2.{i}"} for i in range(50)]
        page2 = {"total": 150, "matches": page2_matches}

        mock_api.search.side_effect = [page1, page2]

        with patch("ics_osint.api.client.time.sleep"):  # نتجاهل الانتظار في الاختبار
            results = client.search("port:502", max_pages=5)

        assert len(results) == 150
        assert mock_api.search.call_count == 2

    def test_max_results_limits_output(self, mock_client):
        """max_results يُحدّد الحد الأقصى للنتائج المُرجَعة"""
        client, mock_api = mock_client
        mock_api.search.return_value = FAKE_SEARCH_RESULT  # 2 نتائج

        results = client.search("port:502", max_pages=1, max_results=1)

        assert len(results) == 1

    def test_progress_callback_called(self, mock_client):
        """progress_callback يُستدعى بعد كل صفحة"""
        client, mock_api = mock_client
        mock_api.search.return_value = FAKE_SEARCH_RESULT

        callback_calls = []
        def my_callback(current, total, count):
            callback_calls.append((current, total, count))

        client.search("port:502", max_pages=1, progress_callback=my_callback)

        assert len(callback_calls) == 1
        assert callback_calls[0][0] == 1  # current_page = 1

    def test_no_results_on_first_page_raises(self, mock_client):
        """لا نتائج في الصفحة الأولى يُرفع NoResultsError"""
        client, mock_api = mock_client
        mock_api.search.return_value = FAKE_EMPTY_RESULT

        with pytest.raises(NoResultsError):
            client.search("port:99999", max_pages=1)

    def test_max_pages_capped_at_constant(self, mock_client):
        """max_pages لا يتجاوز MAX_PAGES من الثوابت"""
        from ics_osint.config.constants import MAX_PAGES
        client, mock_api = mock_client
        mock_api.search.return_value = FAKE_EMPTY_RESULT

        # نطلب أكثر من MAX_PAGES — يجب أن يُقيَّد
        with pytest.raises(NoResultsError):
            client.search("port:502", max_pages=MAX_PAGES + 100)


# ---------------------------------------------------------------
# اختبارات count
# ---------------------------------------------------------------

class TestCount:

    def test_count_returns_total(self, mock_client):
        """count يُرجع العدد الإجمالي"""
        client, mock_api = mock_client
        mock_api.count.return_value = {"total": 12345}

        result = client.count("port:502")

        assert result == 12345

    def test_empty_query_raises_invalid_query(self, mock_client):
        """استعلام فارغ في count يُرفع InvalidQueryError"""
        client, mock_api = mock_client

        with pytest.raises(InvalidQueryError):
            client.count("")


# ---------------------------------------------------------------
# اختبارات _map_shodan_error
# ---------------------------------------------------------------

class TestErrorMapping:

    def test_maps_invalid_key_error(self, mock_client):
        """رسالة 'Invalid API key' تُحوَّل لـ InvalidAPIKeyError"""
        client, _ = mock_client
        error = shodan.APIError("Invalid API key")
        result = client._map_shodan_error(error)
        assert isinstance(result, InvalidAPIKeyError)

    def test_maps_rate_limit_error(self, mock_client):
        """رسالة 'Rate limit' تُحوَّل لـ RateLimitError"""
        client, _ = mock_client
        error = shodan.APIError("Rate limit reached")
        result = client._map_shodan_error(error)
        assert isinstance(result, RateLimitError)

    def test_maps_no_credits_error(self, mock_client):
        """رسالة 'query credits' تُحوَّل لـ NoCreditsError"""
        client, _ = mock_client
        error = shodan.APIError("query credits exceeded")
        result = client._map_shodan_error(error)
        assert isinstance(result, NoCreditsError)

    def test_maps_unknown_error_to_base(self, mock_client):
        """خطأ غير معروف يُحوَّل لـ ShodanAPIError الأساسي"""
        client, _ = mock_client
        error = shodan.APIError("Some unknown error occurred")
        result = client._map_shodan_error(error)
        assert isinstance(result, ShodanAPIError)
        assert not isinstance(result, (InvalidAPIKeyError, RateLimitError, NoCreditsError))


# ---------------------------------------------------------------
# اختبارات Retry Logic
# ---------------------------------------------------------------

class TestRetryLogic:

    def test_retries_on_connection_error(self):
        """يُعيد المحاولة عند ConnectionError"""
        call_count = 0

        @with_retry(max_retries=2, delay=0.01)
        def flaky_function():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise api_exc.ConnectionError("Network error")
            return "success"

        result = flaky_function()
        assert result == "success"
        assert call_count == 3

    def test_does_not_retry_on_invalid_key(self):
        """لا يُعيد المحاولة عند InvalidAPIKeyError"""
        call_count = 0

        @with_retry(max_retries=3, delay=0.01)
        def always_fails():
            nonlocal call_count
            call_count += 1
            raise InvalidAPIKeyError("Invalid key")

        with pytest.raises(InvalidAPIKeyError):
            always_fails()

        assert call_count == 1  # محاولة واحدة فقط

    def test_does_not_retry_on_no_credits(self):
        """لا يُعيد المحاولة عند NoCreditsError"""
        call_count = 0

        @with_retry(max_retries=3, delay=0.01)
        def no_credits():
            nonlocal call_count
            call_count += 1
            raise NoCreditsError("No credits")

        with pytest.raises(NoCreditsError):
            no_credits()

        assert call_count == 1

    def test_raises_after_max_retries(self):
        """يُرفع الخطأ بعد استنفاد جميع المحاولات"""
        @with_retry(max_retries=2, delay=0.01)
        def always_fails():
            raise api_exc.ConnectionError("Always fails")

        with pytest.raises(api_exc.ConnectionError):
            always_fails()

    def test_rate_limit_waits_retry_after(self):
        """RateLimitError ينتظر retry_after ثواني"""
        call_count = 0
        sleep_calls = []

        @with_retry(max_retries=1, delay=0.01)
        def rate_limited():
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise RateLimitError("Rate limit", retry_after=30)
            return "ok"

        with patch("ics_osint.api.retry.time.sleep") as mock_sleep:
            result = rate_limited()
            assert result == "ok"
            # يجب أن ينتظر 30 ثانية (retry_after)
            mock_sleep.assert_called_once_with(30)
