"""
tests/test_error_scenarios.py
==============================
اختبارات سيناريوهات الأخطاء:
1. انقطاع الإنترنت (ConnectionError / Timeout)
2. مفتاح API خاطئ (InvalidAPIKeyError)
3. نفاد الرصيد (NoCreditsError)
4. Rate Limit
5. بيانات تالفة من الخادم

شغّل: python -m pytest tests/test_error_scenarios.py -v
"""

import pytest
import socket
import requests
from unittest.mock import patch, MagicMock
from click.testing import CliRunner

import shodan

from ics_osint.cli import main
from ics_osint.api.client import ShodanClient
from ics_osint.api.exceptions import (
    InvalidAPIKeyError, RateLimitError, NoCreditsError,
    NoResultsError, InvalidQueryError,
)
from ics_osint.api import exceptions as api_exc
from ics_osint.processing.extractor import extract_devices, extract_device

FAKE_API_KEY = "test_key_1234567890"


@pytest.fixture
def runner():
    return CliRunner(mix_stderr=True)


@pytest.fixture
def mock_api_key():
    with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY):
        yield FAKE_API_KEY


# ---------------------------------------------------------------
# 1. انقطاع الإنترنت
# ---------------------------------------------------------------

class TestInternetDisconnection:
    """اختبارات سلوك الأداة عند انقطاع الإنترنت"""

    def test_search_connection_error_exits_with_1(self, runner, mock_api_key):
        """انقطاع الإنترنت أثناء البحث → exit code 1"""
        with patch("ics_osint.cli_helpers.ShodanClient") as mock_class:
            mock_client = MagicMock()
            mock_client.search.side_effect = api_exc.ConnectionError(
                "تعذّر الاتصال بـ Shodan. تحقق من اتصالك بالإنترنت."
            )
            mock_class.return_value = mock_client

            result = runner.invoke(main, ["search", "--template", "modbus"])

        assert result.exit_code == 1

    def test_search_timeout_exits_with_1(self, runner, mock_api_key):
        """انتهاء مهلة الاتصال → exit code 1"""
        with patch("ics_osint.cli_helpers.ShodanClient") as mock_class:
            mock_client = MagicMock()
            mock_client.search.side_effect = api_exc.TimeoutError(
                "انتهت مهلة الاتصال."
            )
            mock_class.return_value = mock_client

            result = runner.invoke(main, ["search", "--template", "modbus"])

        assert result.exit_code == 1

    def test_validate_key_connection_error(self, runner):
        """انقطاع الإنترنت أثناء التحقق من المفتاح"""
        with patch("ics_osint.cli_helpers.ShodanClient") as mock_class:
            mock_client = MagicMock()
            mock_client.validate_key.side_effect = api_exc.ConnectionError(
                "تعذّر الاتصال"
            )
            mock_class.return_value = mock_client

            result = runner.invoke(main, ["config", "--set-key", FAKE_API_KEY])

        assert result.exit_code == 1

    def test_count_connection_error(self, runner, mock_api_key):
        """انقطاع الإنترنت أثناء count"""
        with patch("ics_osint.cli_helpers.ShodanClient") as mock_class:
            mock_client = MagicMock()
            mock_client.count.side_effect = api_exc.ConnectionError("فشل الاتصال")
            mock_class.return_value = mock_client

            result = runner.invoke(main, ["count", "--template", "modbus"])

        assert result.exit_code == 1

    def test_client_maps_requests_connection_error(self):
        """ShodanClient يُحوّل requests.ConnectionError لـ api_exc.ConnectionError"""
        with patch("ics_osint.api.client.shodan.Shodan") as mock_shodan:
            mock_api = MagicMock()
            mock_api.search.side_effect = requests.exceptions.ConnectionError(
                "Connection refused"
            )
            mock_shodan.return_value = mock_api

            client = ShodanClient(FAKE_API_KEY)
            with pytest.raises(api_exc.ConnectionError):
                client.search_page("port:502")

    def test_client_maps_requests_timeout(self):
        """ShodanClient يُحوّل requests.Timeout لـ api_exc.TimeoutError"""
        with patch("ics_osint.api.client.shodan.Shodan") as mock_shodan:
            mock_api = MagicMock()
            mock_api.search.side_effect = requests.exceptions.Timeout(
                "Read timed out"
            )
            mock_shodan.return_value = mock_api

            client = ShodanClient(FAKE_API_KEY)
            with pytest.raises(api_exc.TimeoutError):
                client.search_page("port:502")

    def test_client_maps_socket_error(self):
        """ShodanClient يُحوّل socket.error لـ api_exc.ConnectionError"""
        with patch("ics_osint.api.client.shodan.Shodan") as mock_shodan:
            mock_api = MagicMock()
            mock_api.search.side_effect = socket.error("Network unreachable")
            mock_shodan.return_value = mock_api

            client = ShodanClient(FAKE_API_KEY)
            with pytest.raises(api_exc.ConnectionError):
                client.search_page("port:502")


# ---------------------------------------------------------------
# 2. مفتاح API خاطئ
# ---------------------------------------------------------------

class TestInvalidAPIKey:
    """اختبارات سلوك الأداة عند مفتاح API خاطئ"""

    def test_search_invalid_key_exits_with_1(self, runner, mock_api_key):
        """مفتاح خاطئ أثناء البحث → exit code 1"""
        with patch("ics_osint.cli_helpers.ShodanClient") as mock_class:
            mock_client = MagicMock()
            mock_client.search.side_effect = InvalidAPIKeyError(
                "مفتاح API غير صالح."
            )
            mock_class.return_value = mock_client

            result = runner.invoke(main, ["search", "--template", "modbus"])

        assert result.exit_code == 1

    def test_set_key_invalid_exits_with_1(self, runner):
        """حفظ مفتاح خاطئ → exit code 1"""
        with patch("ics_osint.cli_helpers.ShodanClient") as mock_class:
            mock_client = MagicMock()
            mock_client.validate_key.side_effect = InvalidAPIKeyError(
                "Invalid API key"
            )
            mock_class.return_value = mock_client

            result = runner.invoke(main, ["config", "--set-key", "wrong_key"])

        assert result.exit_code == 1

    def test_verify_invalid_key_exits_with_1(self, runner):
        """التحقق من مفتاح خاطئ → exit code 1"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value="bad_key"), \
             patch("ics_osint.cli_helpers.ShodanClient") as mock_class:

            mock_client = MagicMock()
            mock_client.validate_key.side_effect = InvalidAPIKeyError("Invalid key")
            mock_class.return_value = mock_client

            result = runner.invoke(main, ["config", "--verify"])

        assert result.exit_code == 1

    def test_client_maps_401_to_invalid_key(self):
        """Shodan 401 → InvalidAPIKeyError"""
        with patch("ics_osint.api.client.shodan.Shodan") as mock_shodan:
            mock_api = MagicMock()
            mock_api.info.side_effect = shodan.APIError("Invalid API key")
            mock_shodan.return_value = mock_api

            client = ShodanClient(FAKE_API_KEY)
            with pytest.raises(InvalidAPIKeyError):
                client.validate_key()

    def test_client_maps_unauthorized_to_invalid_key(self):
        """Shodan 'unauthorized' → InvalidAPIKeyError"""
        with patch("ics_osint.api.client.shodan.Shodan") as mock_shodan:
            mock_api = MagicMock()
            mock_api.search.side_effect = shodan.APIError("Access denied (unauthorized)")
            mock_shodan.return_value = mock_api

            client = ShodanClient(FAKE_API_KEY)
            with pytest.raises(InvalidAPIKeyError):
                client.search_page("port:502")

    def test_no_saved_key_shows_helpful_message(self, runner):
        """بدون مفتاح محفوظ تظهر رسالة مساعدة"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=None):
            result = runner.invoke(main, ["search", "--template", "modbus"])

        assert result.exit_code == 1
        # يجب أن تظهر رسالة تُرشد المستخدم
        assert "config" in result.output or "set-key" in result.output or "API" in result.output


# ---------------------------------------------------------------
# 3. نفاد الرصيد (NoCreditsError)
# ---------------------------------------------------------------

class TestNoCredits:
    """اختبارات سلوك الأداة عند نفاد Query Credits"""

    def test_search_no_credits_exits_with_1(self, runner, mock_api_key):
        """نفاد الرصيد → exit code 1"""
        with patch("ics_osint.cli_helpers.ShodanClient") as mock_class:
            mock_client = MagicMock()
            mock_client.search.side_effect = NoCreditsError(
                "لا يوجد رصيد كافٍ من Query Credits."
            )
            mock_class.return_value = mock_client

            result = runner.invoke(main, ["search", "--template", "modbus"])

        assert result.exit_code == 1

    def test_client_maps_credits_error(self):
        """Shodan 'query credits exceeded' → NoCreditsError"""
        with patch("ics_osint.api.client.shodan.Shodan") as mock_shodan:
            mock_api = MagicMock()
            mock_api.search.side_effect = shodan.APIError(
                "query credits exceeded"
            )
            mock_shodan.return_value = mock_api

            client = ShodanClient(FAKE_API_KEY)
            with pytest.raises(NoCreditsError):
                client.search_page("port:502")


# ---------------------------------------------------------------
# 4. Rate Limit
# ---------------------------------------------------------------

class TestRateLimit:
    """اختبارات سلوك الأداة عند تجاوز Rate Limit"""

    def test_search_rate_limit_exits_with_1(self, runner, mock_api_key):
        """Rate Limit → exit code 1 مع عرض وقت الانتظار"""
        with patch("ics_osint.cli_helpers.ShodanClient") as mock_class:
            mock_client = MagicMock()
            mock_client.search.side_effect = RateLimitError(
                "تجاوزت الحد المسموح به.",
                retry_after=60,
            )
            mock_class.return_value = mock_client

            result = runner.invoke(main, ["search", "--template", "modbus"])

        assert result.exit_code == 1
        # يجب أن يظهر وقت الانتظار
        assert "60" in result.output

    def test_client_maps_rate_limit_error(self):
        """Shodan 'rate limit' → RateLimitError"""
        with patch("ics_osint.api.client.shodan.Shodan") as mock_shodan:
            mock_api = MagicMock()
            mock_api.search.side_effect = shodan.APIError("Rate limit reached")
            mock_shodan.return_value = mock_api

            client = ShodanClient(FAKE_API_KEY)
            with pytest.raises(RateLimitError):
                client.search_page("port:502")

    def test_rate_limit_has_retry_after(self):
        """RateLimitError يحمل retry_after"""
        error = RateLimitError("Rate limit", retry_after=120)
        assert error.retry_after == 120


# ---------------------------------------------------------------
# 5. بيانات تالفة من الخادم
# ---------------------------------------------------------------

class TestCorruptServerData:
    """اختبارات معالجة البيانات التالفة أو غير المتوقعة من Shodan"""

    def test_extract_device_handles_missing_ip(self):
        """نتيجة بدون ip_str تُتجاهل"""
        raw = {"location": {"country_code": "US"}, "org": "Corp", "ports": [502]}
        result = extract_device(raw)
        assert result is None

    def test_extract_device_handles_null_location(self):
        """location = None لا يُسبّب crash"""
        raw = {"ip_str": "1.2.3.4", "location": None, "ports": [502]}
        result = extract_device(raw)
        assert result is not None
        assert result.country_code == "N/A"

    def test_extract_device_handles_empty_dict(self):
        """dict فارغ يُرجع None"""
        result = extract_device({})
        assert result is None

    def test_extract_device_handles_non_dict(self):
        """مدخل غير dict يُرجع None"""
        assert extract_device(None) is None
        assert extract_device("string") is None
        assert extract_device(123) is None
        assert extract_device([]) is None

    def test_extract_devices_skips_corrupt_records(self):
        """يتجاهل السجلات التالفة ويُكمل المعالجة"""
        raw_list = [
            {"ip_str": "1.2.3.4", "ports": [502]},  # صالح
            None,                                      # تالف
            {"no_ip": "data"},                         # بدون IP
            {"ip_str": "5.6.7.8", "ports": [20000]},  # صالح
            "not a dict",                              # تالف
        ]
        results = extract_devices(raw_list)
        assert len(results) == 2
        assert results[0].ip == "1.2.3.4"
        assert results[1].ip == "5.6.7.8"

    def test_extract_device_handles_mixed_port_types(self):
        """بورتات بأنواع مختلطة تُعالَج بأمان"""
        raw = {
            "ip_str": "1.2.3.4",
            "ports": [80, "443", None, "invalid", -1, 0, 65536, 502],
        }
        result = extract_device(raw)
        assert result is not None
        assert 80 in result.ports
        assert 443 in result.ports
        assert 502 in result.ports
        # القيم غير الصحيحة تُستبعد
        assert None not in result.ports
        assert -1 not in result.ports
        assert 0 not in result.ports
        assert 65536 not in result.ports

    def test_extract_device_handles_unicode_org(self):
        """أسماء شركات بأحرف Unicode تُعالَج بشكل صحيح"""
        raw = {
            "ip_str": "1.2.3.4",
            "org": "شركة سعودية للطاقة الكهربائية",
            "location": {"country_code": "SA", "country_name": "Saudi Arabia"},
            "ports": [502],
        }
        result = extract_device(raw)
        assert result is not None
        assert result.org == "شركة سعودية للطاقة الكهربائية"

    def test_search_returns_empty_list_gracefully(self, runner):
        """Shodan يُرجع قائمة فارغة → رسالة 'لا توجد نتائج'"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY), \
             patch("ics_osint.cli_helpers.ShodanClient") as mock_class:

            mock_client = MagicMock()
            mock_client.search.side_effect = NoResultsError("لا توجد نتائج")
            mock_class.return_value = mock_client

            result = runner.invoke(main, ["search", "--template", "modbus"])

        # لا توجد نتائج ليس خطأً — exit code 0
        assert result.exit_code == 0


# ---------------------------------------------------------------
# 6. اختبارات الـ Retry Logic تحت ظروف الشبكة
# ---------------------------------------------------------------

class TestRetryUnderNetworkConditions:
    """اختبارات إعادة المحاولة عند تقلبات الشبكة"""

    def test_retry_succeeds_after_transient_failure(self):
        """ينجح بعد فشل مؤقت في الاتصال"""
        from ics_osint.api.retry import with_retry

        call_count = 0

        @with_retry(max_retries=2, delay=0.001)
        def flaky_api_call():
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise api_exc.ConnectionError("Transient failure")
            return {"total": 100, "matches": []}

        result = flaky_api_call()
        assert result["total"] == 100
        assert call_count == 3

    def test_retry_gives_up_after_max_retries(self):
        """يتوقف بعد استنفاد جميع المحاولات"""
        from ics_osint.api.retry import with_retry

        call_count = 0

        @with_retry(max_retries=2, delay=0.001)
        def always_fails():
            nonlocal call_count
            call_count += 1
            raise api_exc.TimeoutError("Always times out")

        with pytest.raises(api_exc.TimeoutError):
            always_fails()

        assert call_count == 3  # 1 أصلية + 2 إعادة

    def test_no_retry_for_invalid_key(self):
        """لا إعادة محاولة لمفتاح خاطئ"""
        from ics_osint.api.retry import with_retry

        call_count = 0

        @with_retry(max_retries=3, delay=0.001)
        def invalid_key_call():
            nonlocal call_count
            call_count += 1
            raise InvalidAPIKeyError("Invalid key")

        with pytest.raises(InvalidAPIKeyError):
            invalid_key_call()

        assert call_count == 1  # محاولة واحدة فقط

    def test_exponential_backoff_increases_delay(self):
        """وقت الانتظار يتضاعف مع كل محاولة"""
        from ics_osint.api.retry import with_retry
        import time

        sleep_calls = []

        @with_retry(max_retries=3, delay=1.0, backoff_factor=2.0)
        def always_fails():
            raise api_exc.ConnectionError("fail")

        with patch("ics_osint.api.retry.time.sleep") as mock_sleep:
            with pytest.raises(api_exc.ConnectionError):
                always_fails()

            sleep_times = [call[0][0] for call in mock_sleep.call_args_list]

        # كل انتظار يجب أن يكون أطول من السابق
        for i in range(1, len(sleep_times)):
            assert sleep_times[i] >= sleep_times[i - 1]
