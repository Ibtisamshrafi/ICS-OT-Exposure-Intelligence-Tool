"""
tests/test_config.py
====================
اختبارات وحدة الإعدادات — تعمل بدون Shodan API حقيقي.
شغّل: python -m pytest tests/test_config.py -v
"""

import pytest
from pathlib import Path
from unittest.mock import patch
import tempfile
import os

# نستورد الوحدة المراد اختبارها
from ics_osint.config.manager import (
    get_config_dir,
    get_config_file,
    get_api_key,
    save_api_key,
    delete_api_key,
    is_api_key_saved,
    get_config_info,
    load_config,
    save_config,
    CONFIG_DIR_NAME,
    CONFIG_FILE_NAME,
    API_KEY_FIELD,
)
from ics_osint.config.constants import (
    ICS_QUERY_TEMPLATES,
    ERROR_MESSAGES,
    COLORS,
    EXTRACTED_FIELDS,
    CSV_HEADERS,
)


# ---------------------------------------------------------------
# Fixture: نستخدم مجلد مؤقت بدلاً من home directory الحقيقي
# ---------------------------------------------------------------

@pytest.fixture(autouse=True)
def mock_home_dir(tmp_path):
    """
    يُعيد توجيه Path.home() إلى مجلد مؤقت في كل اختبار.
    هذا يمنع الاختبارات من التأثير على ملفات المستخدم الحقيقية.
    """
    with patch("ics_osint.config.manager.Path") as mock_path_class:
        # نجعل Path.home() يُرجع المجلد المؤقت
        mock_path_class.home.return_value = tmp_path
        # نجعل Path() العادي يعمل بشكل طبيعي
        mock_path_class.side_effect = lambda *args: Path(*args)
        mock_path_class.home.return_value = tmp_path
        yield tmp_path


# ---------------------------------------------------------------
# اختبارات get_config_dir و get_config_file
# ---------------------------------------------------------------

class TestConfigPaths:

    def test_config_dir_uses_home(self, mock_home_dir):
        """يتحقق أن مجلد الإعدادات داخل home directory"""
        config_dir = get_config_dir()
        assert CONFIG_DIR_NAME in str(config_dir)

    def test_config_file_name(self):
        """يتحقق أن اسم ملف الإعدادات صحيح"""
        config_file = get_config_file()
        assert config_file.name == CONFIG_FILE_NAME


# ---------------------------------------------------------------
# اختبارات حفظ وقراءة الإعدادات
# ---------------------------------------------------------------

class TestSaveLoadConfig:

    def test_load_config_returns_empty_dict_when_no_file(self, tmp_path):
        """يُرجع dict فارغ إذا لم يكن الملف موجوداً"""
        with patch("ics_osint.config.manager.get_config_file",
                   return_value=tmp_path / "nonexistent.json"):
            result = load_config()
            assert result == {}

    def test_save_and_load_config(self, tmp_path):
        """يحفظ ويقرأ الإعدادات بشكل صحيح"""
        test_file = tmp_path / "test_config.json"
        test_data = {"key": "value", "number": 42}

        with patch("ics_osint.config.manager.get_config_file", return_value=test_file), \
             patch("ics_osint.config.manager.get_config_dir", return_value=tmp_path):
            assert save_config(test_data) is True
            loaded = load_config()
            assert loaded == test_data

    def test_load_config_handles_corrupt_json(self, tmp_path):
        """يُرجع dict فارغ إذا كان الملف تالفاً"""
        corrupt_file = tmp_path / "corrupt.json"
        corrupt_file.write_text("{ this is not valid json !!!", encoding="utf-8")

        with patch("ics_osint.config.manager.get_config_file", return_value=corrupt_file):
            result = load_config()
            assert result == {}


# ---------------------------------------------------------------
# اختبارات إدارة مفتاح API
# ---------------------------------------------------------------

class TestApiKeyManagement:

    def test_get_api_key_returns_none_when_not_saved(self, tmp_path):
        """يُرجع None إذا لم يكن المفتاح محفوظاً"""
        with patch("ics_osint.config.manager.get_config_file",
                   return_value=tmp_path / "config.json"):
            assert get_api_key() is None

    def test_save_and_get_api_key(self, tmp_path):
        """يحفظ المفتاح ويسترجعه بشكل صحيح"""
        config_file = tmp_path / "config.json"
        test_key = "abc123xyz789testkey"

        with patch("ics_osint.config.manager.get_config_file", return_value=config_file), \
             patch("ics_osint.config.manager.get_config_dir", return_value=tmp_path):
            assert save_api_key(test_key) is True
            retrieved = get_api_key()
            assert retrieved == test_key

    def test_save_api_key_strips_whitespace(self, tmp_path):
        """يُزيل المسافات الزائدة من المفتاح عند الحفظ"""
        config_file = tmp_path / "config.json"
        test_key = "  myapikey123  "

        with patch("ics_osint.config.manager.get_config_file", return_value=config_file), \
             patch("ics_osint.config.manager.get_config_dir", return_value=tmp_path):
            save_api_key(test_key)
            retrieved = get_api_key()
            assert retrieved == "myapikey123"

    def test_delete_api_key(self, tmp_path):
        """يحذف المفتاح بشكل صحيح"""
        config_file = tmp_path / "config.json"

        with patch("ics_osint.config.manager.get_config_file", return_value=config_file), \
             patch("ics_osint.config.manager.get_config_dir", return_value=tmp_path):
            save_api_key("some_key_to_delete")
            assert is_api_key_saved() is True  # نتحقق أنه محفوظ
            # لكن is_api_key_saved يستدعي get_config_file أيضاً، نحتاج patch مستمر
            delete_api_key()
            assert get_api_key() is None

    def test_is_api_key_saved_false_when_empty(self, tmp_path):
        """يُرجع False إذا لم يكن المفتاح موجوداً"""
        with patch("ics_osint.config.manager.get_config_file",
                   return_value=tmp_path / "config.json"):
            assert is_api_key_saved() is False

    def test_get_config_info_masks_key(self, tmp_path):
        """يُخفي معظم المفتاح في معلومات الإعدادات"""
        config_file = tmp_path / "config.json"
        test_key = "abcdefgh12345678"  # 16 حرف

        with patch("ics_osint.config.manager.get_config_file", return_value=config_file), \
             patch("ics_osint.config.manager.get_config_dir", return_value=tmp_path):
            save_api_key(test_key)
            info = get_config_info()

            assert info["api_key_saved"] is True
            # أول 8 أحرف ظاهرة، الباقي نجوم
            assert info["api_key_preview"].startswith("abcdefgh")
            assert "*" in info["api_key_preview"]


# ---------------------------------------------------------------
# اختبارات الثوابت
# ---------------------------------------------------------------

class TestConstants:

    def test_ics_templates_not_empty(self):
        """يتحقق أن قوالب ICS/OT موجودة"""
        assert len(ICS_QUERY_TEMPLATES) > 0

    def test_each_template_has_required_fields(self):
        """كل قالب يجب أن يحتوي على label و query و description"""
        for name, template in ICS_QUERY_TEMPLATES.items():
            assert "label" in template,       f"{name}: مفقود 'label'"
            assert "query" in template,       f"{name}: مفقود 'query'"
            assert "description" in template, f"{name}: مفقود 'description'"
            assert template["query"],         f"{name}: 'query' فارغ"

    def test_modbus_template_has_correct_port(self):
        """يتحقق أن قالب Modbus يستخدم البورت الصحيح"""
        assert "502" in ICS_QUERY_TEMPLATES["modbus"]["query"]

    def test_error_messages_not_empty(self):
        """يتحقق أن رسائل الأخطاء موجودة"""
        required_keys = ["invalid_key", "rate_limit", "connection_error", "timeout"]
        for key in required_keys:
            assert key in ERROR_MESSAGES, f"رسالة الخطأ '{key}' مفقودة"

    def test_extracted_fields_contains_essentials(self):
        """يتحقق أن الحقول المستخرجة تحتوي على الأساسيات"""
        for field in ["ip", "country_code", "org", "ports"]:
            assert field in EXTRACTED_FIELDS

    def test_csv_headers_match_extracted_fields_count(self):
        """عدد رؤوس CSV يجب أن يتطابق مع عدد الحقول المستخرجة"""
        assert len(CSV_HEADERS) == len(EXTRACTED_FIELDS)
