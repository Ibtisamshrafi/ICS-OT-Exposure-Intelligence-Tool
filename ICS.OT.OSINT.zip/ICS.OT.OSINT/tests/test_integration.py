"""
tests/test_integration.py
=========================
اختبارات التكامل الشاملة — تحاكي سيناريوهات استخدام حقيقية.

هذه الاختبارات تُشغّل التدفق الكامل من البداية للنهاية:
    CLI → API → Processing → Display → Export

جميع الاختبارات تستخدم Mock لتجنب استدعاءات Shodan حقيقية.

شغّل: python -m pytest tests/test_integration.py -v
"""

import pytest
import json
import csv
from pathlib import Path
from unittest.mock import patch, MagicMock
from click.testing import CliRunner

from ics_osint.cli import main


# ---------------------------------------------------------------
# بيانات وهمية واقعية (تحاكي استجابة Shodan حقيقية)
# ---------------------------------------------------------------

REALISTIC_SHODAN_RESPONSE = [
    {
        "ip_str": "192.168.1.100",
        "port": 502,
        "transport": "tcp",
        "data": "Modbus/TCP Unit ID: 1",
        "location": {
            "country_code": "US",
            "country_name": "United States",
            "city": "New York",
            "latitude": 40.7128,
            "longitude": -74.0060,
        },
        "org": "Siemens Industrial Networks",
        "isp": "AT&T Services",
        "domains": ["siemens-industrial.com"],
        "hostnames": ["plc-ny-01.siemens-industrial.com"],
        "ports": [80, 443, 502],
        "vulns": {},
        "tags": ["ics", "modbus"],
    },
    {
        "ip_str": "10.20.30.40",
        "port": 502,
        "transport": "tcp",
        "data": "Modbus/TCP",
        "location": {
            "country_code": "DE",
            "country_name": "Germany",
            "city": "Berlin",
            "latitude": 52.5200,
            "longitude": 13.4050,
        },
        "org": "Deutsche Telekom AG",
        "isp": "Deutsche Telekom",
        "domains": [],
        "hostnames": [],
        "ports": [502, 8080],
        "vulns": {},
        "tags": ["ics"],
    },
    {
        "ip_str": "172.16.0.50",
        "port": 20000,
        "transport": "tcp",
        "data": "DNP3 Protocol",
        "location": {
            "country_code": "SA",
            "country_name": "Saudi Arabia",
            "city": "Riyadh",
            "latitude": 24.7136,
            "longitude": 46.6753,
        },
        "org": "Saudi Electricity Company",
        "isp": "STC",
        "domains": ["sec.gov.sa"],
        "hostnames": ["scada-ryd-01.sec.gov.sa"],
        "ports": [20000, 443],
        "vulns": {},
        "tags": ["ics", "scada", "dnp3"],
    },
    {
        "ip_str": "203.0.113.25",
        "port": 102,
        "transport": "tcp",
        "data": "Siemens S7",
        "location": {
            "country_code": "CN",
            "country_name": "China",
            "city": "Shanghai",
            "latitude": 31.2304,
            "longitude": 121.4737,
        },
        "org": "China Telecom",
        "isp": "China Telecom",
        "domains": [],
        "hostnames": [],
        "ports": [102, 80],
        "vulns": {},
        "tags": ["ics", "s7"],
    },
    {
        "ip_str": "198.51.100.75",
        "port": 502,
        "transport": "tcp",
        "data": "Modbus/TCP",
        "location": {
            "country_code": "US",
            "country_name": "United States",
            "city": "Los Angeles",
            "latitude": 34.0522,
            "longitude": -118.2437,
        },
        "org": "Rockwell Automation",
        "isp": "Level 3 Communications",
        "domains": ["rockwellautomation.com"],
        "hostnames": ["plc-la-05.rockwellautomation.com"],
        "ports": [502, 44818],  # Modbus + EtherNet/IP
        "vulns": {},
        "tags": ["ics", "modbus", "ethernetip"],
    },
]

FAKE_API_KEY = "test_shodan_key_1234567890abcdef"

FAKE_ACCOUNT_INFO = {
    "plan": "dev",
    "query_credits": 100,
    "scan_credits": 100,
    "unlocked": True,
    "unlocked_left": 1,
    "telnet": False,
}


@pytest.fixture
def runner():
    """Click CliRunner"""
    return CliRunner(mix_stderr=False)


@pytest.fixture
def mock_shodan_client():
    """يُزيّف ShodanClient بالكامل"""
    with patch("ics_osint.cli_helpers.ShodanClient") as mock_class:
        mock_client = MagicMock()
        mock_client.validate_key.return_value = FAKE_ACCOUNT_INFO
        mock_client.search.return_value = REALISTIC_SHODAN_RESPONSE
        mock_client.count.return_value = len(REALISTIC_SHODAN_RESPONSE)
        mock_class.return_value = mock_client
        yield mock_client


@pytest.fixture
def mock_api_key():
    """يُزيّف وجود مفتاح API محفوظ"""
    with patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY):
        yield FAKE_API_KEY


# ---------------------------------------------------------------
# السيناريو 1: بحث Modbus كامل مع تصدير JSON و CSV
# ---------------------------------------------------------------

class TestModbusSearchScenario:
    """
    سيناريو واقعي: مهندس أمن يبحث عن أجهزة Modbus في الولايات المتحدة
    ويُصدّر النتائج لتحليلها لاحقاً.
    """

    def test_full_modbus_search_with_export(
        self, runner, mock_shodan_client, mock_api_key, tmp_path
    ):
        """
        التدفق الكامل:
        1. بحث بقالب modbus
        2. فلترة بالدولة (US)
        3. تصدير JSON و CSV
        4. التحقق من محتوى الملفات
        """
        output_path = str(tmp_path / "modbus_us_scan")

        result = runner.invoke(main, [
            "search",
            "--template", "modbus",
            "--country", "US",
            "--export-json",
            "--export-csv",
            "--output", output_path,
        ])

        # ---- التحقق من نجاح الأمر ----
        assert result.exit_code == 0

        # ---- التحقق من استدعاء Shodan بالاستعلام الصحيح ----
        mock_shodan_client.search.assert_called_once()
        call_args = mock_shodan_client.search.call_args
        query = call_args[1]["query"]
        assert "port:502" in query
        assert "country:US" in query

        # ---- التحقق من وجود الملفات ----
        json_file = tmp_path / "modbus_us_scan.json"
        csv_file = tmp_path / "modbus_us_scan.csv"
        assert json_file.exists()
        assert csv_file.exists()

        # ---- التحقق من محتوى JSON ----
        with open(json_file, encoding="utf-8") as f:
            json_data = json.load(f)

        assert "metadata" in json_data
        assert "results" in json_data
        assert json_data["metadata"]["query"] == "port:502 country:US"
        # --country يُضاف للاستعلام (فلترة مسبقة) لكن Shodan Mock يُرجع كل النتائج
        # الفلترة اللاحقة تتم في apply_filters — نتحقق من وجود نتائج US على الأقل
        us_results = [r for r in json_data["results"] if r["country_code"] == "US"]
        assert len(us_results) >= 1

        # التحقق من الحقول المستخرجة
        first_result = json_data["results"][0]
        for field in ["ip", "country_code", "country_name", "city", "org", "ports"]:
            assert field in first_result

        # ---- التحقق من محتوى CSV ----
        with open(csv_file, encoding="utf-8-sig") as f:
            csv_reader = csv.DictReader(f)
            rows = list(csv_reader)

        # نتحقق من وجود صفوف وأن US موجودة
        assert len(rows) >= 1
        assert "IP Address" in rows[0]
        assert "Country Code" in rows[0]
        us_rows = [r for r in rows if r["Country Code"] == "US"]
        assert len(us_rows) >= 1

        # ---- التحقق من المخرجات ----
        assert "192.168.1.100" in result.output
        assert "198.51.100.75" in result.output
        assert "Siemens" in result.output or "Rockwell" in result.output


# ---------------------------------------------------------------
# السيناريو 2: بحث مع تقرير تفصيلي
# ---------------------------------------------------------------

class TestDetailedReportScenario:
    """
    سيناريو: محلل OSINT يريد تقريراً شاملاً عن أنظمة ICS/OT
    مع إحصائيات وتوزيع جغرافي.
    """

    def test_search_with_full_report(
        self, runner, mock_shodan_client, mock_api_key
    ):
        """
        التدفق:
        1. بحث عام عن port:502
        2. عرض تقرير تفصيلي (--report)
        3. التحقق من وجود جميع أقسام التقرير
        """
        result = runner.invoke(main, [
            "search",
            "--query", "port:502",
            "--pages", "1",
            "--report",
        ])

        assert result.exit_code == 0

        # ---- التحقق من وجود الإحصائيات ----
        assert "إجمالي الأجهزة" in result.output or "total" in result.output.lower()

        # ---- التحقق من وجود التوزيع الجغرافي ----
        # يجب أن يظهر على الأقل دولة واحدة
        countries = ["US", "DE", "SA", "CN"]
        assert any(country in result.output for country in countries)

        # ---- التحقق من وجود البورتات ----
        assert "502" in result.output

        # ---- التحقق من وجود الشركات ----
        orgs = ["Siemens", "Rockwell", "Telekom", "Saudi"]
        assert any(org in result.output for org in orgs)


# ---------------------------------------------------------------
# السيناريو 3: فلترة لاحقة متقدمة
# ---------------------------------------------------------------

class TestAdvancedFilteringScenario:
    """
    سيناريو: باحث يبحث عن أجهزة Siemens فقط مع استبعاد
    النتائج بدون معلومات شركة.
    """

    def test_filter_by_org_and_require_org(
        self, runner, mock_shodan_client, mock_api_key
    ):
        """
        التدفق:
        1. بحث عام
        2. فلترة لاحقة باسم الشركة (--filter-org siemens)
        3. استبعاد بدون شركة (--require-org)
        """
        result = runner.invoke(main, [
            "search",
            "--query", "port:502",
            "--filter-org", "siemens",
            "--require-org",
        ])

        assert result.exit_code == 0

        # يجب أن تظهر Siemens فقط
        assert "Siemens" in result.output
        # يجب ألا تظهر الشركات الأخرى
        assert "Rockwell" not in result.output


# ---------------------------------------------------------------
# السيناريو 4: count (عدد النتائج بدون جلب)
# ---------------------------------------------------------------

class TestCountScenario:
    """
    سيناريو: مستخدم يريد معرفة عدد النتائج قبل استهلاك Query Credits.
    """

    def test_count_before_search(
        self, runner, mock_shodan_client, mock_api_key
    ):
        """
        التدفق:
        1. count --template modbus
        2. التحقق من عرض العدد
        3. التحقق من عدم استدعاء search (فقط count)
        """
        result = runner.invoke(main, [
            "count",
            "--template", "modbus",
        ])

        assert result.exit_code == 0

        # يجب أن يُستدعى count وليس search
        mock_shodan_client.count.assert_called_once()
        mock_shodan_client.search.assert_not_called()

        # يجب أن يظهر العدد في المخرجات
        assert str(len(REALISTIC_SHODAN_RESPONSE)) in result.output


# ---------------------------------------------------------------
# السيناريو 5: معالجة الأخطاء
# ---------------------------------------------------------------

class TestErrorHandlingScenario:
    """
    سيناريو: اختبار معالجة الأخطاء المختلفة.
    """

    def test_no_api_key_error(self, runner):
        """بدون مفتاح API يعرض رسالة واضحة"""
        with patch("ics_osint.cli_helpers.get_api_key", return_value=None):
            result = runner.invoke(main, [
                "search", "--template", "modbus"
            ])

        assert result.exit_code == 1
        # يجب أن تظهر رسالة عن المفتاح المفقود

    def test_invalid_template_error(self, runner, mock_api_key):
        """قالب غير موجود يُرفض"""
        result = runner.invoke(main, [
            "search", "--template", "nonexistent_protocol"
        ])

        assert result.exit_code != 0

    def test_no_query_no_template_error(self, runner, mock_api_key):
        """بدون --query أو --template يعرض خطأ"""
        result = runner.invoke(main, ["search"])

        assert result.exit_code == 1


# ---------------------------------------------------------------
# السيناريو 6: templates (عرض القوالب)
# ---------------------------------------------------------------

class TestTemplatesScenario:
    """
    سيناريو: مستخدم جديد يريد رؤية القوالب المتاحة.
    """

    def test_list_all_templates(self, runner):
        """templates يعرض جميع القوالب بشكل صحيح"""
        result = runner.invoke(main, ["templates"])

        assert result.exit_code == 0

        # يجب أن تظهر جميع القوالب الرئيسية
        expected_templates = [
            "modbus", "dnp3", "s7", "bacnet",
            "iec104", "ethernetip", "scada", "hmi"
        ]
        for template in expected_templates:
            assert template in result.output

        # يجب أن تظهر البورتات
        assert "502" in result.output    # Modbus
        assert "20000" in result.output  # DNP3
        assert "102" in result.output    # S7


# ---------------------------------------------------------------
# السيناريو 7: config (إدارة المفتاح)
# ---------------------------------------------------------------

class TestConfigScenario:
    """
    سيناريو: مستخدم يُعدّ الأداة لأول مرة.
    """

    def test_set_and_verify_key(self, runner):
        """
        التدفق:
        1. حفظ مفتاح API
        2. التحقق من صلاحيته
        """
        with patch("ics_osint.cli_helpers.ShodanClient") as mock_class, \
             patch("ics_osint.cli_helpers.save_api_key", return_value=True):

            mock_client = MagicMock()
            mock_client.validate_key.return_value = FAKE_ACCOUNT_INFO
            mock_class.return_value = mock_client

            # حفظ المفتاح
            result = runner.invoke(main, [
                "config", "--set-key", FAKE_API_KEY
            ])

            assert result.exit_code == 0
            mock_client.validate_key.assert_called_once()

    def test_show_config(self, runner):
        """--show يعرض معلومات الإعدادات"""
        with patch("ics_osint.cli_helpers.get_config_info", return_value={
            "config_file_path": "/home/user/.ics_osint/config.json",
            "config_file_exists": True,
            "api_key_saved": True,
            "api_key_preview": "abcdefgh********",
            "platform": "Linux",
        }):
            result = runner.invoke(main, ["config", "--show"])

        assert result.exit_code == 0
        assert ".ics_osint" in result.output


# ---------------------------------------------------------------
# السيناريو 8: تكامل كامل (End-to-End)
# ---------------------------------------------------------------

class TestEndToEndScenario:
    """
    سيناريو شامل: من الإعداد حتى التصدير.
    """

    def test_complete_workflow(self, runner, tmp_path):
        """
        التدفق الكامل:
        1. حفظ مفتاح API
        2. عرض القوالب
        3. count للتحقق من العدد
        4. search مع تصدير
        5. التحقق من الملفات
        """
        output_path = str(tmp_path / "complete_test")

        with patch("ics_osint.cli_helpers.ShodanClient") as mock_class, \
             patch("ics_osint.cli_helpers.save_api_key", return_value=True), \
             patch("ics_osint.cli_helpers.get_api_key", return_value=FAKE_API_KEY):

            mock_client = MagicMock()
            mock_client.validate_key.return_value = FAKE_ACCOUNT_INFO
            mock_client.count.return_value = 5
            mock_client.search.return_value = REALISTIC_SHODAN_RESPONSE
            mock_class.return_value = mock_client

            # 1. حفظ المفتاح
            result1 = runner.invoke(main, ["config", "--set-key", FAKE_API_KEY])
            assert result1.exit_code == 0

            # 2. عرض القوالب
            result2 = runner.invoke(main, ["templates"])
            assert result2.exit_code == 0
            assert "modbus" in result2.output

            # 3. count
            result3 = runner.invoke(main, ["count", "--template", "modbus"])
            assert result3.exit_code == 0
            assert "5" in result3.output

            # 4. search مع تصدير
            result4 = runner.invoke(main, [
                "search",
                "--template", "modbus",
                "--export-json",
                "--output", output_path,
            ])
            assert result4.exit_code == 0

            # 5. التحقق من الملف
            json_file = tmp_path / "complete_test.json"
            assert json_file.exists()

            with open(json_file, encoding="utf-8") as f:
                data = json.load(f)
            assert len(data["results"]) == 5
