"""
export/csv_exporter.py
======================
تصدير البيانات إلى ملف CSV قابل للفتح في Excel.

اعتبارات مهمة لـ CSV:
1. الترميز: نستخدم UTF-8-BOM (utf-8-sig) لأن Excel يحتاجه
   لعرض الأحرف العربية والخاصة بشكل صحيح.
2. البورتات: قائمة int → نص مفصول بـ " | " (مثل: "80 | 443 | 502")
   لأن CSV لا يدعم القوائم المتداخلة.
3. الفاصل: نستخدم الفاصلة (,) كافتراضي، مع دعم الفاصلة المنقوطة (;)
   لأن بعض إصدارات Excel الأوروبية تستخدمها.

هيكل ملف CSV:
IP Address,Country Code,Country Name,City,Organization,Open Ports
1.2.3.4,US,United States,New York,Example Corp,80 | 443 | 502
5.6.7.8,DE,Germany,Berlin,German Corp,502
"""

import csv
from pathlib import Path
from typing import Literal

from ics_osint.processing.extractor import DeviceRecord
from ics_osint.config.constants import CSV_HEADERS, ERROR_MESSAGES

# فاصل البورتات داخل خلية CSV
PORTS_SEPARATOR = " | "

# نوع الفاصل
CSVDelimiter = Literal[",", ";", "\t"]


class CSVExportError(Exception):
    """يُرفع عند فشل تصدير CSV"""
    pass


def export_to_csv(
    devices: list[DeviceRecord],
    output_path: Path,
    delimiter: CSVDelimiter = ",",
    include_header: bool = True,
) -> int:
    """
    يُصدّر قائمة DeviceRecord إلى ملف CSV.

    Args:
        devices       : قائمة الأجهزة المراد تصديرها
        output_path   : مسار ملف الإخراج (Path object)
        delimiter     : فاصل الأعمدة ("," أو ";" أو "\t")
        include_header: هل يُضاف سطر رؤوس الأعمدة؟ (افتراضي: True)

    Returns:
        عدد السجلات التي تم تصديرها (لا يشمل سطر الرؤوس)

    Raises:
        CSVExportError: إذا فشلت عملية الكتابة

    مثال:
        count = export_to_csv(devices, Path("results.csv"))
        print(f"تم تصدير {count} سجل")
    """
    try:
        # utf-8-sig = UTF-8 مع BOM — ضروري لـ Excel
        with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(
                f,
                delimiter=delimiter,
                quoting=csv.QUOTE_MINIMAL,
            )

            # كتابة سطر الرؤوس
            if include_header:
                writer.writerow(CSV_HEADERS)

            # كتابة البيانات
            count = 0
            for device in devices:
                row = _device_to_csv_row(device)
                writer.writerow(row)
                count += 1

        return count

    except PermissionError as e:
        raise CSVExportError(
            f"{ERROR_MESSAGES['export_failed']}\nالتفاصيل: {e}"
        ) from e
    except OSError as e:
        raise CSVExportError(
            f"{ERROR_MESSAGES['export_failed']}\nالتفاصيل: {e}"
        ) from e


def _device_to_csv_row(device: DeviceRecord) -> list[str]:
    """
    يُحوّل DeviceRecord إلى سطر CSV (قائمة strings).

    ترتيب الأعمدة يجب أن يتطابق مع CSV_HEADERS:
    [IP Address, Country Code, Country Name, City, Organization, Open Ports]

    Args:
        device: سجل الجهاز

    Returns:
        قائمة strings جاهزة للكتابة في CSV
    """
    return [
        device.ip,
        device.country_code,
        device.country_name,
        device.city,
        device.org,
        device.ports_as_string(separator=PORTS_SEPARATOR),
    ]


def load_from_csv(input_path: Path) -> list[DeviceRecord]:
    """
    يقرأ ملف CSV مُصدَّر مسبقاً ويُرجع قائمة DeviceRecord.

    يتعامل مع:
    - ملفات بـ BOM (utf-8-sig) وبدونه (utf-8)
    - سطر رؤوس اختياري
    - بورتات مفصولة بـ " | "

    Args:
        input_path: مسار ملف CSV

    Returns:
        قائمة DeviceRecord

    Raises:
        CSVExportError: إذا كان الملف غير موجود أو تالف
    """
    if not input_path.exists():
        raise CSVExportError(f"الملف غير موجود: {input_path}")

    devices = []

    try:
        # نجرب utf-8-sig أولاً (يتعامل مع BOM تلقائياً)
        with open(input_path, "r", newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)

            for row in reader:
                try:
                    # تحويل البورتات من نص → قائمة int
                    ports_str = row.get("Open Ports", "")
                    ports = _parse_ports_from_csv(ports_str)

                    device = DeviceRecord(
                        ip=row.get("IP Address", "").strip(),
                        country_code=row.get("Country Code", "N/A").strip(),
                        country_name=row.get("Country Name", "N/A").strip(),
                        city=row.get("City", "N/A").strip(),
                        org=row.get("Organization", "N/A").strip(),
                        ports=ports,
                    )

                    if device.ip:
                        devices.append(device)

                except (ValueError, KeyError):
                    continue

    except OSError as e:
        raise CSVExportError(f"خطأ في قراءة الملف: {e}") from e

    return devices


def _parse_ports_from_csv(ports_str: str) -> list[int]:
    """
    يُحوّل نص البورتات من CSV إلى قائمة int.

    يدعم الفواصل: " | " و "," و " " و ";"

    Args:
        ports_str: نص البورتات (مثل: "80 | 443 | 502")

    Returns:
        قائمة int (قد تكون فارغة)
    """
    if not ports_str or not ports_str.strip():
        return []

    # نُحوّل جميع الفواصل المحتملة لـ "|" ثم نقسّم
    normalized = ports_str.replace(",", "|").replace(";", "|").replace(" ", "|")
    parts = normalized.split("|")

    ports = []
    for part in parts:
        part = part.strip()
        if part:
            try:
                port = int(part)
                if 1 <= port <= 65535:
                    ports.append(port)
            except ValueError:
                continue

    return sorted(set(ports))
