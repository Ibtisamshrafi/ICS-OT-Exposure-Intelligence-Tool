"""
export/json_exporter.py
=======================
تصدير البيانات إلى ملف JSON.

هيكل ملف JSON المُصدَّر:
{
    "metadata": {
        "query":        "port:502",
        "total_results": 45,
        "exported_at":  "2024-05-06T14:30:22",
        "tool_version": "1.0.0"
    },
    "results": [
        {
            "ip":           "1.2.3.4",
            "country_code": "US",
            "country_name": "United States",
            "city":         "New York",
            "org":          "Example Corp",
            "ports":        [80, 443, 502]
        },
        ...
    ]
}

لماذا نُضيف metadata؟
- يُسهّل معرفة مصدر الملف لاحقاً
- يُوثّق الاستعلام الذي أنتج هذه النتائج
- يُفيد عند مشاركة الملف مع الفريق
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Optional

from ics_osint.processing.extractor import DeviceRecord
from ics_osint.config.constants import ERROR_MESSAGES
from ics_osint import __version__


class JSONExportError(Exception):
    """يُرفع عند فشل تصدير JSON"""
    pass


def export_to_json(
    devices: list[DeviceRecord],
    output_path: Path,
    query: str = "",
    pretty: bool = True,
    include_metadata: bool = True,
) -> int:
    """
    يُصدّر قائمة DeviceRecord إلى ملف JSON.

    Args:
        devices         : قائمة الأجهزة المراد تصديرها
        output_path     : مسار ملف الإخراج (Path object)
        query           : الاستعلام الأصلي (للـ metadata)
        pretty          : هل يُنسَّق الـ JSON بمسافات بادئة؟ (افتراضي: True)
        include_metadata: هل يُضاف قسم metadata؟ (افتراضي: True)

    Returns:
        عدد السجلات التي تم تصديرها

    Raises:
        JSONExportError: إذا فشلت عملية الكتابة

    مثال:
        count = export_to_json(devices, Path("results.json"), query="port:502")
        print(f"تم تصدير {count} سجل")
    """
    if not devices:
        # نُصدّر ملفاً فارغاً بدلاً من رفع خطأ
        data = _build_export_data([], query, include_metadata)
        _write_json(data, output_path, pretty)
        return 0

    # تحويل DeviceRecord → dict
    records = [d.to_dict() for d in devices]

    # بناء هيكل الملف الكامل
    data = _build_export_data(records, query, include_metadata)

    # الكتابة للملف
    _write_json(data, output_path, pretty)

    return len(records)


def _build_export_data(
    records: list[dict],
    query: str,
    include_metadata: bool,
) -> dict:
    """
    يبني هيكل بيانات JSON الكامل مع metadata اختيارية.

    Args:
        records         : قائمة dicts جاهزة للتصدير
        query           : الاستعلام الأصلي
        include_metadata: هل يُضاف قسم metadata؟

    Returns:
        dict جاهز للكتابة كـ JSON
    """
    if include_metadata:
        return {
            "metadata": {
                "query":         query,
                "total_results": len(records),
                "exported_at":   datetime.now().isoformat(timespec="seconds"),
                "tool":          "ICS/OT OSINT Tool",
                "tool_version":  __version__,
            },
            "results": records,
        }

    # بدون metadata — نُرجع القائمة مباشرة
    return {"results": records}


def _write_json(data: dict, output_path: Path, pretty: bool) -> None:
    """
    يكتب dict إلى ملف JSON مع معالجة الأخطاء.

    Args:
        data       : البيانات المراد كتابتها
        output_path: مسار الملف
        pretty     : هل يُنسَّق بمسافات بادئة؟

    Raises:
        JSONExportError: عند فشل الكتابة
    """
    indent = 2 if pretty else None

    try:
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(
                data,
                f,
                indent=indent,
                ensure_ascii=False,   # يحافظ على الأحرف العربية والخاصة
                default=str,          # يُحوّل أي نوع غير قابل للتسلسل لـ string
            )
    except PermissionError as e:
        raise JSONExportError(
            f"{ERROR_MESSAGES['export_failed']}\nالتفاصيل: {e}"
        ) from e
    except OSError as e:
        raise JSONExportError(
            f"{ERROR_MESSAGES['export_failed']}\nالتفاصيل: {e}"
        ) from e


def load_from_json(input_path: Path) -> tuple[list[DeviceRecord], dict]:
    """
    يقرأ ملف JSON مُصدَّر مسبقاً ويُرجع قائمة DeviceRecord.

    مفيد لإعادة تحميل نتائج سابقة دون الحاجة لاستعلام Shodan جديد.

    Args:
        input_path: مسار ملف JSON

    Returns:
        (devices, metadata) — قائمة الأجهزة + metadata الملف

    Raises:
        JSONExportError: إذا كان الملف غير موجود أو تالف
    """
    if not input_path.exists():
        raise JSONExportError(f"الملف غير موجود: {input_path}")

    try:
        with open(input_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        raise JSONExportError(f"ملف JSON تالف: {e}") from e
    except OSError as e:
        raise JSONExportError(f"خطأ في قراءة الملف: {e}") from e

    # استخراج metadata والنتائج
    metadata = data.get("metadata", {})
    raw_results = data.get("results", [])

    # تحويل dicts → DeviceRecord
    devices = []
    for r in raw_results:
        try:
            device = DeviceRecord(
                ip=r.get("ip", ""),
                country_code=r.get("country_code", "N/A"),
                country_name=r.get("country_name", "N/A"),
                city=r.get("city", "N/A"),
                org=r.get("org", "N/A"),
                ports=r.get("ports", []),
            )
            if device.ip:  # نتجاهل السجلات بدون IP
                devices.append(device)
        except (TypeError, KeyError):
            continue

    return devices, metadata
