"""
export/filename.py
==================
توليد أسماء ملفات التصدير.

يدعم:
1. اسم مخصص من المستخدم  → يُضاف الامتداد إذا كان مفقوداً
2. توليد تلقائي بالتاريخ  → shodan_20240506_143022.json
3. التحقق من صلاحية المسار قبل الكتابة
"""

import re
from datetime import datetime
from pathlib import Path
from typing import Literal

from ics_osint.config.constants import FILENAME_TIMESTAMP_FORMAT

# الامتدادات المدعومة
ExportFormat = Literal["json", "csv"]


def generate_filename(
    fmt: ExportFormat,
    query: str = "",
    prefix: str = "shodan",
) -> str:
    """
    يُولّد اسم ملف تلقائياً بناءً على التاريخ والوقت الحالي.

    الصيغة: {prefix}_{timestamp}.{fmt}
    مثال  : shodan_20240506_143022.json

    إذا تم تمرير query يُضاف مقطع منه للاسم:
    مثال  : shodan_port502_20240506_143022.csv

    Args:
        fmt   : صيغة الملف ("json" أو "csv")
        query : نص الاستعلام (اختياري — يُضاف مقطع منه للاسم)
        prefix: بادئة الاسم (افتراضي: "shodan")

    Returns:
        اسم الملف كـ string (بدون مسار)
    """
    timestamp = datetime.now().strftime(FILENAME_TIMESTAMP_FORMAT)

    if query:
        # نُنظّف الاستعلام ونأخذ أول 20 حرف فقط
        clean_query = _sanitize_for_filename(query)[:20].strip("_")
        return f"{prefix}_{clean_query}_{timestamp}.{fmt}"

    return f"{prefix}_{timestamp}.{fmt}"


def resolve_output_path(
    user_path: str,
    fmt: ExportFormat,
    query: str = "",
) -> Path:
    """
    يُحوّل مسار المستخدم (أو None) إلى Path كامل وصالح.

    السلوك:
    - إذا أعطى المستخدم اسماً بدون امتداد → يُضاف الامتداد تلقائياً
    - إذا أعطى المستخدم اسماً بامتداد مختلف → يُستبدل بالامتداد الصحيح
    - إذا لم يُعطِ اسماً → يُولَّد اسم تلقائي في المجلد الحالي

    Args:
        user_path: المسار الذي أدخله المستخدم (قد يكون فارغاً)
        fmt      : صيغة الملف المطلوبة
        query    : نص الاستعلام (لتوليد اسم ذكي إذا لم يُعطَ مسار)

    Returns:
        Path كامل وصالح للكتابة

    Examples:
        resolve_output_path("results", "json")
        → Path("results.json")

        resolve_output_path("output/data.csv", "csv")
        → Path("output/data.csv")

        resolve_output_path("", "json", query="port:502")
        → Path("shodan_port502_20240506_143022.json")
    """
    if user_path and user_path.strip():
        path = Path(user_path.strip())

        # إذا كان الامتداد مختلفاً أو مفقوداً — نُصلحه
        if path.suffix.lower() != f".{fmt}":
            path = path.with_suffix(f".{fmt}")

        return path

    # لا يوجد مسار — نُولّد اسماً تلقائياً في المجلد الحالي
    auto_name = generate_filename(fmt=fmt, query=query)
    return Path(auto_name)


def validate_output_path(path: Path) -> tuple[bool, str]:
    """
    يتحقق من أن المسار صالح للكتابة.

    يفحص:
    - هل المجلد الأب موجود؟ (إذا لم يكن موجوداً نُنشئه)
    - هل لدينا صلاحية الكتابة في المجلد؟
    - هل الملف موجود مسبقاً؟ (تحذير فقط — لا نمنع الكتابة)

    Args:
        path: المسار المراد التحقق منه

    Returns:
        (True, "")           إذا كان المسار صالحاً
        (False, "رسالة خطأ") إذا كان هناك مشكلة
    """
    try:
        parent = path.parent

        # إنشاء المجلد الأب إذا لم يكن موجوداً
        if not parent.exists():
            parent.mkdir(parents=True, exist_ok=True)

        # التحقق من صلاحية الكتابة عبر محاولة إنشاء ملف مؤقت
        test_file = parent / f".write_test_{datetime.now().timestamp()}"
        try:
            test_file.touch()
            test_file.unlink()
        except (PermissionError, OSError):
            return False, f"لا توجد صلاحية كتابة في المجلد: {parent}"

        # تحذير إذا كان الملف موجوداً (لكن لا نمنع الكتابة)
        if path.exists():
            return True, f"تحذير: الملف موجود مسبقاً وسيتم استبداله: {path}"

        return True, ""

    except OSError as e:
        return False, f"خطأ في المسار: {e}"


def _sanitize_for_filename(text: str) -> str:
    """
    يُنظّف نص الاستعلام ليكون صالحاً كجزء من اسم ملف.

    يستبدل الأحرف غير المسموح بها في أسماء الملفات بـ underscore.
    الأحرف المسموح بها: حروف، أرقام، hyphen، underscore.

    Args:
        text: النص المراد تنظيفه

    Returns:
        نص نظيف صالح لاسم الملف
    """
    # استبدال الأحرف غير المسموح بها
    clean = re.sub(r'[^\w\-]', '_', text)
    # إزالة underscores المتكررة
    clean = re.sub(r'_+', '_', clean)
    return clean.strip("_")
