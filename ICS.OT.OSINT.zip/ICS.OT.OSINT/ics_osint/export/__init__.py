"""
export package
==============
يُصدّر الواجهة الموحّدة للتصدير.

الاستخدام الموصى به:
    from ics_osint.export import export_results, ExportResult

للاستخدام المباشر:
    from ics_osint.export import export_to_json, export_to_csv
"""

from .exporter import export_results, ExportResult
from .json_exporter import export_to_json, load_from_json, JSONExportError
from .csv_exporter import export_to_csv, load_from_csv, CSVExportError
from .filename import generate_filename, resolve_output_path, validate_output_path

__all__ = [
    # واجهة موحّدة
    "export_results",
    "ExportResult",
    # JSON
    "export_to_json",
    "load_from_json",
    "JSONExportError",
    # CSV
    "export_to_csv",
    "load_from_csv",
    "CSVExportError",
    # filename
    "generate_filename",
    "resolve_output_path",
    "validate_output_path",
]
