"""
export/exporter.py
==================
واجهة موحّدة للتصدير — نقطة الدخول الرئيسية لوحدة التصدير.

بدلاً من استدعاء json_exporter أو csv_exporter مباشرة،
يستخدم الكود العلوي (CLI) هذه الواجهة فقط.

الاستخدام:
    from ics_osint.export import export_results, ExportResult

    result = export_results(
        devices=devices,
        formats=["json", "csv"],
        output_path="my_results",
        query="port:502",
    )
    print(result.summary())
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from ics_osint.processing.extractor import DeviceRecord
from ics_osint.export.json_exporter import export_to_json, JSONExportError
from ics_osint.export.csv_exporter import export_to_csv, CSVExportError
from ics_osint.export.filename import resolve_output_path, validate_output_path
from ics_osint.config.constants import ERROR_MESSAGES


# ---------------------------------------------------------------
# نتيجة عملية التصدير
# ---------------------------------------------------------------

@dataclass
class ExportResult:
    """
    يحمل نتيجة عملية تصدير واحدة أو أكثر.

    Attributes:
        json_path    : مسار ملف JSON المُصدَّر (None إذا لم يُطلب)
        csv_path     : مسار ملف CSV المُصدَّر (None إذا لم يُطلب)
        records_count: عدد السجلات المُصدَّرة
        errors       : قائمة رسائل الأخطاء (فارغة إذا نجح كل شيء)
        warnings     : قائمة التحذيرات (مثل: ملف موجود مسبقاً)
    """
    json_path:     Optional[Path] = None
    csv_path:      Optional[Path] = None
    records_count: int            = 0
    errors:        list[str]      = field(default_factory=list)
    warnings:      list[str]      = field(default_factory=list)

    @property
    def success(self) -> bool:
        """True إذا نجح تصدير واحد على الأقل"""
        return (self.json_path is not None or self.csv_path is not None) \
               and len(self.errors) == 0

    @property
    def partial_success(self) -> bool:
        """True إذا نجح بعض التصدير وفشل بعضه"""
        has_success = self.json_path is not None or self.csv_path is not None
        return has_success and len(self.errors) > 0

    def summary(self) -> str:
        """يُرجع ملخصاً نصياً لنتيجة التصدير"""
        lines = []

        if self.json_path:
            lines.append(f"✓ JSON: {self.json_path} ({self.records_count} سجل)")
        if self.csv_path:
            lines.append(f"✓ CSV : {self.csv_path} ({self.records_count} سجل)")
        for warning in self.warnings:
            lines.append(f"⚠ {warning}")
        for error in self.errors:
            lines.append(f"✗ {error}")

        return "\n".join(lines) if lines else "لم يتم تصدير أي ملف"

    def exported_paths(self) -> list[Path]:
        """يُرجع قائمة المسارات التي تم التصدير إليها"""
        paths = []
        if self.json_path:
            paths.append(self.json_path)
        if self.csv_path:
            paths.append(self.csv_path)
        return paths


# ---------------------------------------------------------------
# الدالة الرئيسية للتصدير
# ---------------------------------------------------------------

def export_results(
    devices: list[DeviceRecord],
    formats: list[str],
    output_path: str = "",
    query: str = "",
    pretty_json: bool = True,
    csv_delimiter: str = ",",
) -> ExportResult:
    """
    يُصدّر النتائج بالصيغ المطلوبة.

    هذه هي الدالة الوحيدة التي يحتاج الكود العلوي (CLI) لاستدعائها.

    Args:
        devices      : قائمة DeviceRecord المراد تصديرها
        formats      : قائمة الصيغ المطلوبة (["json"], ["csv"], أو ["json","csv"])
        output_path  : المسار الأساسي (بدون امتداد) — يُولَّد تلقائياً إذا كان فارغاً
        query        : الاستعلام الأصلي (للـ metadata في JSON)
        pretty_json  : هل يُنسَّق JSON بمسافات بادئة؟
        csv_delimiter: فاصل أعمدة CSV ("," أو ";")

    Returns:
        ExportResult يحتوي على مسارات الملفات المُصدَّرة وأي أخطاء

    مثال:
        result = export_results(
            devices=devices,
            formats=["json", "csv"],
            output_path="results/modbus_scan",
            query="port:502",
        )
        if result.success:
            print(result.summary())
    """
    result = ExportResult(records_count=len(devices))

    # تطبيع أسماء الصيغ
    normalized_formats = [f.lower().strip() for f in formats]

    # ---- تصدير JSON ----
    if "json" in normalized_formats:
        json_path = resolve_output_path(output_path, "json", query)
        valid, msg = validate_output_path(json_path)

        if not valid:
            result.errors.append(f"JSON: {msg}")
        else:
            if msg:  # تحذير (ملف موجود مسبقاً)
                result.warnings.append(msg)
            try:
                export_to_json(
                    devices=devices,
                    output_path=json_path,
                    query=query,
                    pretty=pretty_json,
                )
                result.json_path = json_path
            except JSONExportError as e:
                result.errors.append(f"JSON: {e}")

    # ---- تصدير CSV ----
    if "csv" in normalized_formats:
        csv_path = resolve_output_path(output_path, "csv", query)
        valid, msg = validate_output_path(csv_path)

        if not valid:
            result.errors.append(f"CSV: {msg}")
        else:
            if msg:
                result.warnings.append(msg)
            try:
                export_to_csv(
                    devices=devices,
                    output_path=csv_path,
                    delimiter=csv_delimiter,
                )
                result.csv_path = csv_path
            except CSVExportError as e:
                result.errors.append(f"CSV: {e}")

    return result
