"""
cli.py
======
المدخل الرئيسي للأداة — تعريفات أوامر Click.

هيكل الأوامر:
    ics-osint                    ← المجموعة الرئيسية
    ├── config                   ← إدارة الإعدادات
    │   ├── --set-key KEY        ← حفظ مفتاح API
    │   ├── --delete-key         ← حذف المفتاح
    │   ├── --show               ← عرض الإعدادات
    │   └── --verify             ← التحقق من صلاحية المفتاح
    │
    ├── search                   ← البحث الرئيسي
    │   ├── --query TEXT         ← استعلام مخصص
    │   ├── --template NAME      ← قالب ICS/OT جاهز
    │   ├── --country CC         ← فلترة مسبقة بالدولة
    │   ├── --port INT           ← فلترة مسبقة بالبورت
    │   ├── --pages INT          ← عدد الصفحات
    │   ├── --max-results INT    ← حد أقصى للنتائج
    │   ├── --filter-country CC  ← فلترة لاحقة بالدولة
    │   ├── --filter-port INT    ← فلترة لاحقة بالبورت
    │   ├── --filter-org TEXT    ← فلترة لاحقة بالشركة
    │   ├── --require-org        ← استبعاد بدون شركة
    │   ├── --export-json        ← تصدير JSON
    │   ├── --export-csv         ← تصدير CSV
    │   ├── --output PATH        ← مسار الملف
    │   ├── --show-stats         ← عرض الإحصائيات
    │   ├── --report             ← عرض تقرير تفصيلي
    │   └── --max-display INT    ← حد عرض الجدول
    │
    ├── count                    ← عدد النتائج (مجاني)
    │   ├── --query TEXT
    │   └── --template NAME
    │
    └── templates                ← عرض القوالب الجاهزة
"""

import sys
import logging
import click

from ics_osint import __version__
from ics_osint.config.constants import MAX_PAGES, ICS_QUERY_TEMPLATES
from ics_osint.display import print_banner, print_error, print_blank, console
from ics_osint.cli_helpers import (
    cmd_set_key, cmd_show_config, cmd_delete_key, cmd_verify_key,
    cmd_list_templates, cmd_count,
    build_query, require_api_key, run_search,
)


# ---------------------------------------------------------------
# إعداد Logging
# ---------------------------------------------------------------

def _setup_logging(verbose: bool) -> None:
    """يُعدّ مستوى الـ logging بناءً على خيار --verbose"""
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )


# ---------------------------------------------------------------
# المجموعة الرئيسية
# ---------------------------------------------------------------

@click.group()
@click.version_option(version=__version__, prog_name="ics-osint")
@click.option(
    "--verbose", "-v",
    is_flag=True,
    default=False,
    help="عرض رسائل debug التفصيلية",
)
@click.pass_context
def main(ctx: click.Context, verbose: bool) -> None:
    """
    \b
    ╔══════════════════════════════════════════╗
    ║   ICS/OT OSINT Tool — Powered by Shodan  ║
    ║   للاستخدام الأخلاقي والقانوني فقط       ║
    ╚══════════════════════════════════════════╝

    أداة لجمع معلومات OSINT عن أنظمة ICS/OT المكشوفة على الإنترنت.

    \b
    أمثلة سريعة:
      ics-osint config --set-key YOUR_API_KEY
      ics-osint search --template modbus
      ics-osint search --query "port:502 country:US" --export-json
      ics-osint templates
    """
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    _setup_logging(verbose)


# ---------------------------------------------------------------
# أمر: config
# ---------------------------------------------------------------

@main.command("config")
@click.option(
    "--set-key",
    "api_key",
    metavar="KEY",
    default=None,
    help="حفظ مفتاح Shodan API (يتحقق من صلاحيته أولاً)",
)
@click.option(
    "--delete-key",
    "delete_key",
    is_flag=True,
    default=False,
    help="حذف مفتاح API المحفوظ",
)
@click.option(
    "--show",
    "show",
    is_flag=True,
    default=False,
    help="عرض معلومات الإعدادات الحالية",
)
@click.option(
    "--verify",
    "verify",
    is_flag=True,
    default=False,
    help="التحقق من صلاحية المفتاح المحفوظ وعرض معلومات الحساب",
)
def config_cmd(api_key, delete_key, show, verify):
    """إدارة إعدادات الأداة ومفتاح Shodan API."""

    print_banner()

    # تحديد العملية المطلوبة
    if api_key:
        sys.exit(cmd_set_key(api_key))

    elif delete_key:
        sys.exit(cmd_delete_key())

    elif verify:
        sys.exit(cmd_verify_key())

    else:
        # --show أو بدون خيارات → عرض الإعدادات
        sys.exit(cmd_show_config())


# ---------------------------------------------------------------
# أمر: search
# ---------------------------------------------------------------

@main.command("search")
# ---- مصدر الاستعلام (أحدهما إلزامي) ----
@click.option(
    "--query", "-q",
    "query",
    metavar="TEXT",
    default=None,
    help='استعلام Shodan مخصص. مثال: "port:502 country:US"',
)
@click.option(
    "--template", "-t",
    "template",
    metavar="NAME",
    default=None,
    type=click.Choice(list(ICS_QUERY_TEMPLATES.keys()), case_sensitive=False),
    help="قالب ICS/OT جاهز. شغّل 'ics-osint templates' لرؤية القائمة",
)
# ---- فلاتر مسبقة (تُضاف للاستعلام) ----
@click.option(
    "--country", "-c",
    "country",
    metavar="CC",
    default=None,
    help="فلترة مسبقة بالدولة (رمز بحرفين). مثال: US أو SA",
)
@click.option(
    "--port", "-p",
    "port",
    metavar="INT",
    default=None,
    type=int,
    help="فلترة مسبقة بالبورت. مثال: 502",
)
# ---- إعدادات الجلب ----
@click.option(
    "--pages",
    "max_pages",
    metavar="INT",
    default=1,
    type=click.IntRange(1, MAX_PAGES),
    show_default=True,
    help=f"عدد الصفحات (كل صفحة = 100 نتيجة، الحد الأقصى: {MAX_PAGES})",
)
@click.option(
    "--max-results",
    "max_results",
    metavar="INT",
    default=None,
    type=click.IntRange(1),
    help="الحد الأقصى للنتائج الإجمالية",
)
# ---- فلاتر لاحقة (تُطبَّق بعد الجلب) ----
@click.option(
    "--filter-country",
    "filter_country",
    metavar="CC",
    default=None,
    help="فلترة لاحقة بالدولة بعد الجلب",
)
@click.option(
    "--filter-port",
    "filter_port",
    metavar="INT",
    default=None,
    type=int,
    help="فلترة لاحقة بالبورت بعد الجلب",
)
@click.option(
    "--filter-org",
    "filter_org",
    metavar="TEXT",
    default=None,
    help="فلترة لاحقة باسم الشركة (بحث نصي جزئي)",
)
@click.option(
    "--require-org",
    "require_org",
    is_flag=True,
    default=False,
    help="استبعاد النتائج التي لا تحتوي على اسم شركة",
)
# ---- خيارات التصدير ----
@click.option(
    "--export-json",
    "export_json",
    is_flag=True,
    default=False,
    help="تصدير النتائج إلى ملف JSON",
)
@click.option(
    "--export-csv",
    "export_csv",
    is_flag=True,
    default=False,
    help="تصدير النتائج إلى ملف CSV (متوافق مع Excel)",
)
@click.option(
    "--output", "-o",
    "output_path",
    metavar="PATH",
    default="",
    help="مسار ملف التصدير (بدون امتداد). يُولَّد تلقائياً إذا لم يُحدَّد",
)
# ---- خيارات العرض ----
@click.option(
    "--show-stats",
    "show_stats",
    is_flag=True,
    default=False,
    help="عرض إحصائيات عامة عن النتائج",
)
@click.option(
    "--report",
    "show_report",
    is_flag=True,
    default=False,
    help="عرض تقرير تفصيلي (دول، بورتات، شركات)",
)
@click.option(
    "--max-display",
    "max_display",
    metavar="INT",
    default=50,
    type=click.IntRange(1, 1000),
    show_default=True,
    help="الحد الأقصى للصفوف المعروضة في الجدول",
)
def search_cmd(
    query, template, country, port,
    max_pages, max_results,
    filter_country, filter_port, filter_org, require_org,
    export_json, export_csv, output_path,
    show_stats, show_report, max_display,
):
    """
    البحث عن أجهزة ICS/OT في Shodan.

    \b
    أمثلة:
      # بحث بقالب جاهز
      ics-osint search --template modbus

      # بحث مخصص مع فلترة بالدولة
      ics-osint search --query "port:502" --country US

      # بحث مع تصدير JSON و CSV
      ics-osint search --template dnp3 --pages 3 --export-json --export-csv

      # بحث مع تقرير تفصيلي
      ics-osint search --template scada --report --output results/scada_scan

      # بحث مع فلترة لاحقة
      ics-osint search --template modbus --filter-org siemens --require-org
    """
    print_banner()

    # ---- التحقق من وجود مفتاح API ----
    api_key = require_api_key()
    if not api_key:
        sys.exit(1)

    # ---- بناء الاستعلام ----
    if not query and not template:
        print_error("يجب تحديد --query أو --template")
        print_blank()
        console.print("  مثال: [cyan]ics-osint search --template modbus[/cyan]")
        console.print("  مثال: [cyan]ics-osint search --query \"port:502 country:US\"[/cyan]")
        sys.exit(1)

    final_query = build_query(
        query=query,
        template=template,
        country=country,
        port=port,
    )

    if not final_query:
        sys.exit(1)

    # ---- تحديد صيغ التصدير ----
    export_formats = []
    if export_json:
        export_formats.append("json")
    if export_csv:
        export_formats.append("csv")

    # ---- تنفيذ البحث ----
    exit_code = run_search(
        query=final_query,
        api_key=api_key,
        max_pages=max_pages,
        max_results=max_results,
        filter_country=filter_country,
        filter_port=filter_port,
        filter_org=filter_org,
        require_org=require_org,
        show_stats=show_stats,
        show_report=show_report,
        max_display=max_display,
        export_formats=export_formats,
        output_path=output_path,
    )

    sys.exit(exit_code)


# ---------------------------------------------------------------
# أمر: count
# ---------------------------------------------------------------

@main.command("count")
@click.option(
    "--query", "-q",
    "query",
    metavar="TEXT",
    default=None,
    help="استعلام Shodan للحساب",
)
@click.option(
    "--template", "-t",
    "template",
    metavar="NAME",
    default=None,
    type=click.Choice(list(ICS_QUERY_TEMPLATES.keys()), case_sensitive=False),
    help="قالب ICS/OT جاهز",
)
@click.option(
    "--country", "-c",
    "country",
    metavar="CC",
    default=None,
    help="فلترة بالدولة",
)
@click.option(
    "--port", "-p",
    "port",
    metavar="INT",
    default=None,
    type=int,
    help="فلترة بالبورت",
)
def count_cmd(query, template, country, port):
    """
    عرض عدد النتائج لاستعلام معين (مجاني — لا يستهلك Query Credits).

    \b
    أمثلة:
      ics-osint count --template modbus
      ics-osint count --query "port:502" --country US
    """
    print_banner()

    api_key = require_api_key()
    if not api_key:
        sys.exit(1)

    if not query and not template:
        print_error("يجب تحديد --query أو --template")
        sys.exit(1)

    final_query = build_query(
        query=query,
        template=template,
        country=country,
        port=port,
    )

    if not final_query:
        sys.exit(1)

    sys.exit(cmd_count(final_query, api_key))


# ---------------------------------------------------------------
# أمر: templates
# ---------------------------------------------------------------

@main.command("templates")
def templates_cmd():
    """عرض قائمة قوالب استعلامات ICS/OT الجاهزة."""
    print_banner()
    sys.exit(cmd_list_templates())


# ---------------------------------------------------------------
# نقطة الدخول
# ---------------------------------------------------------------

if __name__ == "__main__":
    main()
