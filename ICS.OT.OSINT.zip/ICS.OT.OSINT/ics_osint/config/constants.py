"""
config/constants.py
===================
جميع الثوابت المستخدمة في المشروع في مكان واحد.
يسهّل التعديل لاحقاً دون البحث في كل الملفات.
"""

# ---------------------------------------------------------------
# إعدادات Shodan API
# ---------------------------------------------------------------

# الحد الأقصى للنتائج في كل صفحة (قيد Shodan الثابت)
SHODAN_PAGE_SIZE = 100

# الحد الأقصى للصفحات التي نطلبها في جلسة واحدة
# (حماية من استنزاف الـ Query Credits)
MAX_PAGES = 10

# وقت الانتظار بين الطلبات المتتالية (بالثواني) لتجنب Rate Limit
REQUEST_DELAY_SECONDS = 1.0

# مهلة الاتصال بـ Shodan (بالثواني)
CONNECTION_TIMEOUT = 15

# عدد محاولات إعادة الاتصال عند الفشل
MAX_RETRIES = 3

# وقت الانتظار بين محاولات إعادة الاتصال (بالثواني)
RETRY_DELAY_SECONDS = 5.0


# ---------------------------------------------------------------
# قوالب استعلامات ICS/OT الجاهزة
# (يختار منها المستخدم بدلاً من كتابتها يدوياً)
# ---------------------------------------------------------------

ICS_QUERY_TEMPLATES = {
    "modbus": {
        "label": "Modbus (TCP/502)",
        "query": "port:502",
        "description": "بروتوكول Modbus المستخدم في PLCs والأنظمة الصناعية",
    },
    "dnp3": {
        "label": "DNP3 (TCP/20000)",
        "query": "port:20000",
        "description": "بروتوكول DNP3 المستخدم في أنظمة SCADA للطاقة والمياه",
    },
    "s7": {
        "label": "Siemens S7 (TCP/102)",
        "query": "port:102",
        "description": "بروتوكول Siemens S7 للتحكم في PLCs الصناعية",
    },
    "bacnet": {
        "label": "BACnet (UDP/47808)",
        "query": "port:47808",
        "description": "بروتوكول BACnet لأنظمة إدارة المباني (HVAC)",
    },
    "iec104": {
        "label": "IEC 60870-5-104 (TCP/2404)",
        "query": "port:2404",
        "description": "بروتوكول IEC 104 لأنظمة التحكم في الطاقة الكهربائية",
    },
    "ethernetip": {
        "label": "EtherNet/IP (TCP/44818)",
        "query": "port:44818",
        "description": "بروتوكول EtherNet/IP لأنظمة Allen-Bradley/Rockwell",
    },
    "scada": {
        "label": "SCADA (عام)",
        "query": 'scada',
        "description": "بحث عام عن أنظمة SCADA",
    },
    "hmi": {
        "label": "HMI Interfaces",
        "query": '"HMI" "SCADA"',
        "description": "واجهات HMI المكشوفة على الإنترنت",
    },
    "profinet": {
        "label": "PROFINET (TCP/34964)",
        "query": "port:34964",
        "description": "بروتوكول PROFINET لأنظمة Siemens الصناعية",
    },
    "fox": {
        "label": "Niagara Fox (TCP/1911)",
        "query": "port:1911",
        "description": "بروتوكول Niagara Fox لأنظمة إدارة المباني",
    },
}


# ---------------------------------------------------------------
# إعدادات التصدير
# ---------------------------------------------------------------

# الحقول التي نستخرجها من كل نتيجة Shodan
EXTRACTED_FIELDS = ["ip", "country_code", "country_name", "city", "org", "ports"]

# رؤوس أعمدة ملف CSV
CSV_HEADERS = ["IP Address", "Country Code", "Country Name", "City", "Organization", "Open Ports"]

# صيغة تاريخ/وقت لتوليد اسم الملف تلقائياً
FILENAME_TIMESTAMP_FORMAT = "%Y%m%d_%H%M%S"


# ---------------------------------------------------------------
# رسائل الأخطاء (مركزية لسهولة الترجمة لاحقاً)
# ---------------------------------------------------------------

ERROR_MESSAGES = {
    "invalid_key":       "مفتاح API غير صالح. تحقق من المفتاح وأعد المحاولة.",
    "rate_limit":        "تجاوزت الحد المسموح به من الطلبات. انتظر قليلاً ثم أعد المحاولة.",
    "no_credits":        "لا يوجد رصيد كافٍ من Query Credits في حسابك.",
    "connection_error":  "تعذّر الاتصال بـ Shodan. تحقق من اتصالك بالإنترنت.",
    "timeout":           "انتهت مهلة الاتصال. الشبكة بطيئة أو Shodan غير متاح حالياً.",
    "no_results":        "لم يتم العثور على نتائج لهذا الاستعلام.",
    "no_key_saved":      "لم يتم حفظ مفتاح API بعد. شغّل: ics-osint config --set-key",
    "export_failed":     "فشل تصدير الملف. تحقق من صلاحيات الكتابة في المجلد.",
    "invalid_query":     "صيغة الاستعلام غير صحيحة.",
}


# ---------------------------------------------------------------
# ألوان العرض (Rich library color names)
# ---------------------------------------------------------------

COLORS = {
    "ip":          "cyan",
    "country":     "green",
    "org":         "yellow",
    "port":        "magenta",
    "error":       "bold red",
    "warning":     "bold yellow",
    "success":     "bold green",
    "info":        "bold blue",
    "header":      "bold white",
    "dim":         "dim white",
}
