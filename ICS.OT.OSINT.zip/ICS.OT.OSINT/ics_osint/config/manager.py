"""
config/manager.py
=================
وحدة إدارة الإعدادات وتخزين مفتاح Shodan API بشكل آمن.

المبدأ الأمني:
- المفتاح يُحفظ في: ~/.ics_osint/config.json
  (داخل مجلد المستخدم الرئيسي في النظام)
- لا يُحفظ أبداً بجانب كود المشروع لتجنب تسريبه عبر Git
- صلاحيات الملف تُضبط على 600 (قراءة/كتابة للمالك فقط) على Linux/Mac
"""

import os
import json
import stat
import platform
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------
# الثوابت: مسارات التخزين
# ---------------------------------------------------------------

# اسم المجلد المخفي داخل home directory
CONFIG_DIR_NAME = ".ics_osint"

# اسم ملف الإعدادات
CONFIG_FILE_NAME = "config.json"

# المفتاح داخل ملف JSON
API_KEY_FIELD = "shodan_api_key"


def get_config_dir() -> Path:
    """
    يُرجع مسار مجلد الإعدادات داخل home directory للمستخدم.

    مثال على Windows : C:\\Users\\Ahmed\\.ics_osint
    مثال على Linux   : /home/ahmed/.ics_osint
    مثال على macOS   : /Users/ahmed/.ics_osint
    """
    home = Path.home()          # يعمل على Windows/Linux/macOS
    return home / CONFIG_DIR_NAME


def get_config_file() -> Path:
    """يُرجع المسار الكامل لملف config.json"""
    return get_config_dir() / CONFIG_FILE_NAME


def _ensure_config_dir() -> None:
    """
    ينشئ مجلد الإعدادات إذا لم يكن موجوداً.
    على Linux/macOS يضبط الصلاحيات على 700 (مالك فقط).
    """
    config_dir = get_config_dir()

    if not config_dir.exists():
        config_dir.mkdir(parents=True, exist_ok=True)

        # ضبط صلاحيات المجلد على أنظمة Unix فقط
        if platform.system() != "Windows":
            os.chmod(config_dir, stat.S_IRWXU)  # 700: rwx------


def _set_file_permissions(file_path: Path) -> None:
    """
    يضبط صلاحيات ملف الإعدادات على 600 (قراءة/كتابة للمالك فقط).
    يعمل فقط على Linux/macOS — Windows يتجاهل هذه الخطوة.
    """
    if platform.system() != "Windows":
        os.chmod(file_path, stat.S_IRUSR | stat.S_IWUSR)  # 600: rw-------


# ---------------------------------------------------------------
# دوال القراءة والكتابة
# ---------------------------------------------------------------

def load_config() -> dict:
    """
    يقرأ ملف الإعدادات ويُرجع محتواه كـ dict.
    إذا لم يكن الملف موجوداً يُرجع dict فارغ.
    """
    config_file = get_config_file()

    if not config_file.exists():
        return {}

    try:
        with open(config_file, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError:
        # الملف موجود لكن محتواه تالف — نُرجع dict فارغ
        return {}
    except OSError:
        # خطأ في القراءة (صلاحيات مثلاً)
        return {}


def save_config(config: dict) -> bool:
    """
    يحفظ dict الإعدادات في ملف JSON.

    Returns:
        True  إذا نجحت العملية
        False إذا فشلت
    """
    _ensure_config_dir()
    config_file = get_config_file()

    try:
        with open(config_file, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2, ensure_ascii=False)

        # ضبط الصلاحيات بعد الكتابة مباشرة
        _set_file_permissions(config_file)
        return True

    except OSError:
        return False


# ---------------------------------------------------------------
# دوال إدارة مفتاح API
# ---------------------------------------------------------------

def get_api_key() -> Optional[str]:
    """
    يقرأ مفتاح Shodan API من ملف الإعدادات.

    Returns:
        المفتاح كـ string إذا كان موجوداً
        None إذا لم يكن محفوظاً بعد
    """
    config = load_config()
    key = config.get(API_KEY_FIELD, "").strip()
    return key if key else None


def save_api_key(api_key: str) -> bool:
    """
    يحفظ مفتاح Shodan API في ملف الإعدادات.

    Args:
        api_key: المفتاح المراد حفظه

    Returns:
        True إذا نجح الحفظ، False إذا فشل
    """
    # تحميل الإعدادات الحالية أولاً للحفاظ على أي بيانات أخرى
    config = load_config()
    config[API_KEY_FIELD] = api_key.strip()
    return save_config(config)


def delete_api_key() -> bool:
    """
    يحذف مفتاح API من ملف الإعدادات (مفيد عند تغيير المفتاح).

    Returns:
        True إذا نجح الحذف أو لم يكن المفتاح موجوداً أصلاً
    """
    config = load_config()

    if API_KEY_FIELD in config:
        del config[API_KEY_FIELD]
        return save_config(config)

    return True  # لم يكن موجوداً أصلاً — لا مشكلة


def is_api_key_saved() -> bool:
    """يتحقق ببساطة هل يوجد مفتاح محفوظ أم لا"""
    return get_api_key() is not None


def get_config_info() -> dict:
    """
    يُرجع معلومات عن ملف الإعدادات (للعرض في Terminal).
    لا يكشف قيمة المفتاح كاملة — يعرض أول 8 أحرف فقط.
    """
    config_file = get_config_file()
    api_key = get_api_key()

    # إخفاء معظم المفتاح — نعرض أول 8 أحرف فقط
    if api_key:
        masked_key = api_key[:8] + "*" * (len(api_key) - 8)
    else:
        masked_key = None

    return {
        "config_file_path": str(config_file),
        "config_file_exists": config_file.exists(),
        "api_key_saved": api_key is not None,
        "api_key_preview": masked_key,
        "platform": platform.system(),
    }
