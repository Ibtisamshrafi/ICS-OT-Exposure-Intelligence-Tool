"""
config package
==============
يُصدّر الدوال والثوابت الأكثر استخداماً مباشرة من مستوى الـ package
حتى يمكن الاستيراد هكذا:
    from ics_osint.config import get_api_key, save_api_key, ICS_QUERY_TEMPLATES
"""

from .manager import (
    get_api_key,
    save_api_key,
    delete_api_key,
    is_api_key_saved,
    get_config_info,
    get_config_file,
    get_config_dir,
)

from .constants import (
    ICS_QUERY_TEMPLATES,
    SHODAN_PAGE_SIZE,
    MAX_PAGES,
    REQUEST_DELAY_SECONDS,
    CONNECTION_TIMEOUT,
    MAX_RETRIES,
    RETRY_DELAY_SECONDS,
    EXTRACTED_FIELDS,
    CSV_HEADERS,
    FILENAME_TIMESTAMP_FORMAT,
    ERROR_MESSAGES,
    COLORS,
)

__all__ = [
    # manager
    "get_api_key",
    "save_api_key",
    "delete_api_key",
    "is_api_key_saved",
    "get_config_info",
    "get_config_file",
    "get_config_dir",
    # constants
    "ICS_QUERY_TEMPLATES",
    "SHODAN_PAGE_SIZE",
    "MAX_PAGES",
    "REQUEST_DELAY_SECONDS",
    "CONNECTION_TIMEOUT",
    "MAX_RETRIES",
    "RETRY_DELAY_SECONDS",
    "EXTRACTED_FIELDS",
    "CSV_HEADERS",
    "FILENAME_TIMESTAMP_FORMAT",
    "ERROR_MESSAGES",
    "COLORS",
]
