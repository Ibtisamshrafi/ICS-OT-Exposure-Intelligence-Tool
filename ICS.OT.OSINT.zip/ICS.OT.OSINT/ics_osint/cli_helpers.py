"""
cli_helpers.py
==============
دوال مساعدة للـ CLI — تحتوي على المنطق الرئيسي (Business Logic)
مفصولاً عن تعريفات Click.

لماذا الفصل؟
- يُسهّل اختبار المنطق بدون استدعاء Click
- يُبقي ملف cli.py نظيفاً ومقروءاً
- يُتيح إعادة استخدام المنطق من أماكن أخرى

كل دالة هنا تُنفّذ خطوة واحدة من التدفق الرئيسي:
    1. التحقق من المفتاح
    2. بناء الاستعلام
    3. تنفيذ البحث
    4. معالجة البيانات
    5. عرض النتائج
    6. التصدير
"""

import sys
import logging
from typing import Optional

from ics_osint.config import (
    get_api_key, save_api_key, delete_api_key,
    get_config_info, is_api_key_saved,
    ICS_QUERY_TEMPLATES, MAX_PAGES, ERROR_MESSAGES,
)
from ics_osint.api import (
    ShodanClient,
    InvalidAPIKeyError, RateLimitError, NoCreditsError,
    NoResultsError, InvalidQueryError,
)
from ics_osint.api import exceptions as api_exc
from ics_osint.processing import (
    extract_devices, apply_filters,
    get_summary_stats, generate_report,
    get_filter_stats,
)
from ics_osint.export import export_results
from ics_osint.display import (
    print_success, print_error, print_warning, print_info, print_dim,
    print_section, print_blank, print_separator,
    print_devices_table, print_stats_table,
    print_countries_table, print_ports_table, print_orgs_table,
    print_account_table, print_templates_table,
    print_search_start, print_search_complete, print_export_result,
    print_api_key_status,
    SearchProgress, simple_spinner, processing_spinner,
    console,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------
# 1. إدارة مفتاح API
# ---------------------------------------------------------------

def cmd_set_key(api_key: str) -> int:
    """
    يحفظ مفتاح API بعد التحقق من صلاحيته.

    Returns:
        0 عند النجاح، 1 عند الفشل
    """
    if not api_key or not api_key.strip():
        print_error("المفتاح لا يمكن أن يكون فارغاً")
        return 1

    print_info("جارٍ التحقق من صلاحية المفتاح...")

    try:
        with simple_spinner("التحقق من Shodan API..."):
            client = ShodanClient(api_key)
            account_info = client.validate_key()

        if save_api_key(api_key):
            print_success("تم حفظ مفتاح API بنجاح")
            print_blank()
            print_account_table(account_info)
            return 0
        else:
            print_error("فشل حفظ المفتاح. تحقق من صلاحيات الكتابة")
            return 1

    except InvalidAPIKeyError as e:
        print_error(str(e))
        return 1
    except (api_exc.ConnectionError, api_exc.TimeoutError) as e:
        print_error(str(e))
        return 1


def cmd_show_config() -> int:
    """يعرض معلومات الإعدادات الحالية"""
    info = get_config_info()

    print_section("إعدادات الأداة")
    console.print(f"  مسار ملف الإعدادات : [dim]{info['config_file_path']}[/dim]")
    console.print(f"  الملف موجود        : {'[success]نعم[/success]' if info['config_file_exists'] else '[error]لا[/error]'}")
    print_blank()
    print_api_key_status(info["api_key_saved"], info.get("api_key_preview", ""))
    return 0


def cmd_delete_key() -> int:
    """يحذف مفتاح API المحفوظ"""
    if not is_api_key_saved():
        print_warning("لا يوجد مفتاح محفوظ أصلاً")
        return 0

    if delete_api_key():
        print_success("تم حذف مفتاح API")
        return 0
    else:
        print_error("فشل حذف المفتاح")
        return 1


def cmd_verify_key() -> int:
    """يتحقق من صلاحية المفتاح المحفوظ ويعرض معلومات الحساب"""
    api_key = get_api_key()
    if not api_key:
        print_error(ERROR_MESSAGES["no_key_saved"])
        return 1

    try:
        with simple_spinner("التحقق من Shodan API..."):
            client = ShodanClient(api_key)
            account_info = client.validate_key()

        print_success("المفتاح صالح")
        print_blank()
        print_account_table(account_info)
        return 0

    except InvalidAPIKeyError as e:
        print_error(str(e))
        print_dim("  شغّل: ics-osint config --set-key لتحديث المفتاح")
        return 1
    except (api_exc.ConnectionError, api_exc.TimeoutError) as e:
        print_error(str(e))
        return 1


# ---------------------------------------------------------------
# 2. بناء الاستعلام
# ---------------------------------------------------------------

def build_query(
    query:        Optional[str],
    template:     Optional[str],
    country:      Optional[str],
    port:         Optional[int],
) -> Optional[str]:
    """
    يبني نص الاستعلام النهائي من المدخلات المختلفة.

    الأولوية:
    1. --query  (استعلام مخصص كامل)
    2. --template (قالب جاهز)
    3. خطأ إذا لم يُعطَ أي منهما

    الفلترة المسبقة (تُضاف للاستعلام):
    - --country → يُضيف "country:XX"
    - --port    → يُضيف "port:XXXX"

    Args:
        query   : استعلام مخصص من المستخدم
        template: مفتاح قالب ICS/OT
        country : رمز الدولة (فلترة مسبقة)
        port    : رقم البورت (فلترة مسبقة)

    Returns:
        نص الاستعلام الكامل، أو None إذا لم يُعطَ استعلام
    """
    base_query = None

    # تحديد الاستعلام الأساسي
    if query and query.strip():
        base_query = query.strip()

    elif template:
        template_key = template.lower().strip()
        if template_key not in ICS_QUERY_TEMPLATES:
            print_error(f"القالب '{template}' غير موجود")
            print_dim(f"  القوالب المتاحة: {', '.join(ICS_QUERY_TEMPLATES.keys())}")
            return None
        base_query = ICS_QUERY_TEMPLATES[template_key]["query"]
        print_info(f"استخدام قالب: {ICS_QUERY_TEMPLATES[template_key]['label']}")

    else:
        return None

    # إضافة الفلاتر المسبقة للاستعلام
    parts = [base_query]

    if country and country.strip():
        parts.append(f"country:{country.strip().upper()}")

    if port is not None:
        parts.append(f"port:{port}")

    return " ".join(parts)


# ---------------------------------------------------------------
# 3. التحقق من المفتاح قبل البحث
# ---------------------------------------------------------------

def require_api_key() -> Optional[str]:
    """
    يتحقق من وجود مفتاح API محفوظ.

    Returns:
        المفتاح إذا كان موجوداً
        None مع طباعة رسالة خطأ إذا لم يكن موجوداً
    """
    api_key = get_api_key()
    if not api_key:
        print_error(ERROR_MESSAGES["no_key_saved"])
        return None
    return api_key


# ---------------------------------------------------------------
# 4. تنفيذ البحث الكامل
# ---------------------------------------------------------------

def run_search(
    query:       str,
    api_key:     str,
    max_pages:   int,
    max_results: Optional[int],
    # فلاتر لاحقة
    filter_country:  Optional[str],
    filter_port:     Optional[int],
    filter_org:      Optional[str],
    require_org:     bool,
    # خيارات العرض
    show_stats:      bool,
    show_report:     bool,
    max_display:     int,
    # خيارات التصدير
    export_formats:  list[str],
    output_path:     str,
) -> int:
    """
    ينفّذ دورة البحث الكاملة:
    جلب → استخراج → فلترة → عرض → تصدير

    Returns:
        0 عند النجاح، 1 عند الفشل
    """
    # ---- إنشاء العميل ----
    try:
        client = ShodanClient(api_key)
    except InvalidAPIKeyError as e:
        print_error(str(e))
        return 1

    # ---- عرض معلومات البحث ----
    print_search_start(query, max_pages)

    # ---- جلب البيانات مع شريط التقدم ----
    raw_results = []
    search_progress = SearchProgress(max_pages=max_pages, query=query)

    try:
        search_progress.start()

        raw_results = client.search(
            query=query,
            max_pages=max_pages,
            max_results=max_results,
            progress_callback=search_progress.callback,
        )

        search_progress.stop(success=True)

    except NoResultsError:
        search_progress.stop(success=False)
        print_warning(ERROR_MESSAGES["no_results"])
        return 0

    except InvalidAPIKeyError as e:
        search_progress.stop(success=False)
        print_error(str(e))
        print_dim("  شغّل: ics-osint config --set-key لتحديث المفتاح")
        return 1

    except RateLimitError as e:
        search_progress.stop(success=False)
        print_error(str(e))
        print_dim(f"  انتظر {e.retry_after} ثانية ثم أعد المحاولة")
        return 1

    except NoCreditsError as e:
        search_progress.stop(success=False)
        print_error(str(e))
        print_dim("  قم بترقية حسابك على shodan.io لمزيد من الاستعلامات")
        return 1

    except (api_exc.ConnectionError, api_exc.TimeoutError) as e:
        search_progress.stop(success=False)
        print_error(str(e))
        return 1

    except Exception as e:
        search_progress.stop(success=False)
        print_error(f"خطأ غير متوقع: {e}")
        logger.exception("Unexpected error during search")
        return 1

    # ---- استخراج البيانات ----
    with processing_spinner("جارٍ استخراج البيانات..."):
        devices = extract_devices(raw_results)

    total_before_filter = len(devices)

    # ---- تطبيق الفلاتر اللاحقة ----
    # ملاحظة: الفلاتر المسبقة (country, port) أُضيفت للاستعلام في build_query
    # الفلاتر اللاحقة هنا للتدقيق الإضافي بعد الجلب
    if any([filter_country, filter_port, filter_org, require_org]):
        with processing_spinner("جارٍ تطبيق الفلاتر..."):
            devices = apply_filters(
                devices,
                country_code=filter_country,
                port=filter_port,
                org_keyword=filter_org,
                require_org=require_org,
                remove_duplicates=True,
            )
    else:
        # إزالة التكرار دائماً حتى بدون فلاتر
        with processing_spinner("جارٍ إزالة التكرار..."):
            devices = apply_filters(devices, remove_duplicates=True)

    total_after_filter = len(devices)

    # ---- عرض ملخص البحث ----
    print_search_complete(total_before_filter, total_after_filter)

    if total_after_filter == 0:
        print_warning("لا توجد نتائج بعد تطبيق الفلاتر")
        return 0

    print_blank()

    # ---- عرض الجدول الرئيسي ----
    print_section("نتائج البحث")
    print_devices_table(
        devices,
        title=f"نتائج: {query}",
        max_rows=max_display,
    )

    # ---- عرض الإحصائيات ----
    if show_stats or show_report:
        print_blank()
        stats = get_summary_stats(devices)
        print_stats_table(stats)

    # ---- عرض التقرير التفصيلي ----
    if show_report:
        print_blank()
        report = generate_report(devices)

        if report["top_countries"]:
            print_blank()
            print_countries_table(report["top_countries"])

        if report["top_ports"]:
            print_blank()
            print_ports_table(report["top_ports"])

        if report["top_orgs"]:
            print_blank()
            print_orgs_table(report["top_orgs"])

    # ---- التصدير ----
    if export_formats:
        print_blank()
        with processing_spinner("جارٍ تصدير الملفات..."):
            export_result = export_results(
                devices=devices,
                formats=export_formats,
                output_path=output_path,
                query=query,
            )

        print_blank()
        print_section("ملفات التصدير")

        for warning in export_result.warnings:
            print_warning(warning)

        for error in export_result.errors:
            print_error(error)

        print_export_result(
            json_path=export_result.json_path,
            csv_path=export_result.csv_path,
        )

    return 0


# ---------------------------------------------------------------
# 5. عرض القوالب
# ---------------------------------------------------------------

def cmd_list_templates() -> int:
    """يعرض جميع قوالب ICS/OT الجاهزة"""
    print_section("قوالب استعلامات ICS/OT")
    print_templates_table(ICS_QUERY_TEMPLATES)
    print_blank()
    print_dim("  الاستخدام: ics-osint search --template modbus")
    return 0


# ---------------------------------------------------------------
# 6. عرض عدد النتائج (بدون استهلاك Credits)
# ---------------------------------------------------------------

def cmd_count(query: str, api_key: str) -> int:
    """
    يعرض عدد النتائج لاستعلام معين بدون جلب البيانات.
    هذا الاستدعاء مجاني (لا يستهلك Query Credits).
    """
    try:
        with simple_spinner(f"جارٍ حساب النتائج لـ: {query}"):
            client = ShodanClient(api_key)
            total = client.count(query)

        print_blank()
        console.print(
            f"  الاستعلام : [cyan]{query}[/cyan]\n"
            f"  النتائج   : [success]{total:,}[/success] جهاز"
        )
        return 0

    except InvalidAPIKeyError as e:
        print_error(str(e))
        return 1
    except (api_exc.ConnectionError, api_exc.TimeoutError) as e:
        print_error(str(e))
        return 1
    except Exception as e:
        print_error(f"خطأ: {e}")
        return 1
