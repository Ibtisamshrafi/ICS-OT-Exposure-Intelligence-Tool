# ICS/OT OSINT Tool - Main Package
__version__ = "1.0.0"
__author__  = "ICS OSINT Tool"
