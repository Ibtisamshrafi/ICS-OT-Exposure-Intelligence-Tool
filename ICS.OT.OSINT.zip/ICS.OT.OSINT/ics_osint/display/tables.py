"""
display/tables.py
=================
عرض البيانات في جداول مُلوّنة ومُنسّقة باستخدام مكتبة Rich.

الجداول المتاحة:
1. جدول الأجهزة الرئيسي   — يعرض قائمة DeviceRecord
2. جدول الإحصائيات        — يعرض ملخص البيانات
3. جدول التوزيع الجغرافي  — أكثر الدول
4. جدول توزيع البورتات    — أكثر البورتات
5. جدول الشركات           — أكثر الشركات
6. جدول معلومات الحساب    — بيانات Shodan account

الاستخدام:
    from ics_osint.display.tables import print_devices_table, print_stats_table

    print_devices_table(devices)
    print_stats_table(stats)
"""

from rich.table import Table
from rich.text import Text
from rich.panel import Panel
from rich import box

from ics_osint.processing.extractor import DeviceRecord
from ics_osint.display.console import console


# ---------------------------------------------------------------
# الجدول الرئيسي: قائمة الأجهزة
# ---------------------------------------------------------------

def print_devices_table(
    devices: list[DeviceRecord],
    title: str = "نتائج البحث",
    max_rows: int = 0,
    show_index: bool = True,
) -> None:
    """
    يطبع قائمة الأجهزة في جدول مُلوّن ومُنسّق.

    الأعمدة:
    #  │  IP Address  │  Country  │  City  │  Organization  │  Open Ports

    Args:
        devices   : قائمة DeviceRecord
        title     : عنوان الجدول
        max_rows  : الحد الأقصى للصفوف المعروضة (0 = كل الصفوف)
        show_index: هل يُعرض رقم الصف؟
    """
    if not devices:
        console.print(Panel(
            "[dim]لا توجد نتائج للعرض[/dim]",
            border_style="dim",
            title=title,
        ))
        return

    # تحديد الصفوف المعروضة
    display_devices = devices[:max_rows] if max_rows > 0 else devices
    hidden_count = len(devices) - len(display_devices)

    # بناء الجدول
    table = Table(
        title=f"[title]{title}[/title]",
        box=box.ROUNDED,
        border_style="blue",
        header_style="bold white on dark_blue",
        show_lines=False,
        padding=(0, 1),
        title_justify="left",
    )

    # تعريف الأعمدة
    if show_index:
        table.add_column("#", style="dim", width=4, justify="right")

    table.add_column("IP Address",    style="bold cyan",   min_width=15, no_wrap=True)
    table.add_column("CC",            style="green",       width=4,  justify="center")
    table.add_column("Country",       style="green",       min_width=14)
    table.add_column("City",          style="dim white",   min_width=12)
    table.add_column("Organization",  style="yellow",      min_width=20, max_width=35)
    table.add_column("Open Ports",    style="magenta",     min_width=16)

    # إضافة الصفوف
    for idx, device in enumerate(display_devices, start=1):
        ports_text = _format_ports(device.ports)

        if show_index:
            table.add_row(
                str(idx),
                device.ip,
                device.country_code,
                device.country_name,
                device.city,
                _truncate(device.org, 33),
                ports_text,
            )
        else:
            table.add_row(
                device.ip,
                device.country_code,
                device.country_name,
                device.city,
                _truncate(device.org, 33),
                ports_text,
            )

    console.print(table)

    # تنبيه إذا كانت هناك صفوف مخفية
    if hidden_count > 0:
        console.print(
            f"  [dim]... و {hidden_count} نتيجة أخرى غير معروضة. "
            f"استخدم --export لحفظ جميع النتائج.[/dim]"
        )


# ---------------------------------------------------------------
# جدول الإحصائيات العامة
# ---------------------------------------------------------------

def print_stats_table(stats: dict, title: str = "إحصائيات البحث") -> None:
    """
    يطبع إحصائيات عامة في جدول مُنسّق.

    Args:
        stats: dict من get_summary_stats()
        title: عنوان الجدول
    """
    table = Table(
        title=f"[title]{title}[/title]",
        box=box.SIMPLE_HEAVY,
        border_style="blue",
        header_style="bold white",
        show_header=False,
        padding=(0, 2),
        title_justify="left",
    )

    table.add_column("المقياس", style="dim white",  min_width=22)
    table.add_column("القيمة",  style="bold white", min_width=10, justify="right")

    rows = [
        ("إجمالي الأجهزة",          str(stats.get("total_devices",     0))),
        ("عناوين IP الفريدة",        str(stats.get("unique_ips",        0))),
        ("عدد الدول",                str(stats.get("unique_countries",  0))),
        ("عدد الشركات",              str(stats.get("unique_orgs",       0))),
        ("عدد البورتات المختلفة",    str(stats.get("unique_ports",      0))),
        ("أجهزة بمعلومات شركة",      str(stats.get("devices_with_org",  0))),
        ("أجهزة بمعلومات مدينة",     str(stats.get("devices_with_city", 0))),
    ]

    for label, value in rows:
        table.add_row(label, f"[success]{value}[/success]")

    console.print(table)


# ---------------------------------------------------------------
# جدول التوزيع الجغرافي
# ---------------------------------------------------------------

def print_countries_table(
    country_data: list[dict],
    title: str = "التوزيع الجغرافي (أكثر الدول)",
) -> None:
    """
    يطبع توزيع الأجهزة حسب الدولة.

    Args:
        country_data: قائمة من group_by_country_detailed()
        title       : عنوان الجدول
    """
    if not country_data:
        return

    table = Table(
        title=f"[title]{title}[/title]",
        box=box.SIMPLE_HEAVY,
        border_style="green",
        header_style="bold white",
        padding=(0, 1),
        title_justify="left",
    )

    table.add_column("الدولة",      style="green",      min_width=20)
    table.add_column("الرمز",       style="bold green",  width=6,  justify="center")
    table.add_column("العدد",       style="bold white",  width=8,  justify="right")
    table.add_column("النسبة",      style="cyan",        width=8,  justify="right")
    table.add_column("شريط",        style="blue",        min_width=20)

    # أقصى عدد لحساب نسبة الشريط
    max_count = country_data[0]["count"] if country_data else 1

    for item in country_data:
        bar = _make_bar(item["count"], max_count, width=18)
        table.add_row(
            item["country_name"],
            item["country_code"],
            str(item["count"]),
            f"{item['percentage']}%",
            bar,
        )

    console.print(table)


# ---------------------------------------------------------------
# جدول توزيع البورتات
# ---------------------------------------------------------------

def print_ports_table(
    port_data: list[tuple[int, int]],
    title: str = "أكثر البورتات شيوعاً",
) -> None:
    """
    يطبع توزيع الأجهزة حسب البورت.

    Args:
        port_data: قائمة من group_by_port() — [(port, count), ...]
        title    : عنوان الجدول
    """
    if not port_data:
        return

    # خريطة البورتات المعروفة لـ ICS/OT
    ICS_PORTS = {
        502:   "Modbus",
        20000: "DNP3",
        102:   "Siemens S7",
        47808: "BACnet",
        2404:  "IEC 60870-5-104",
        44818: "EtherNet/IP",
        34964: "PROFINET",
        1911:  "Niagara Fox",
        4840:  "OPC-UA",
        9600:  "OMRON FINS",
        1962:  "PCWorx",
        20547: "ProConOS",
    }

    table = Table(
        title=f"[title]{title}[/title]",
        box=box.SIMPLE_HEAVY,
        border_style="magenta",
        header_style="bold white",
        padding=(0, 1),
        title_justify="left",
    )

    table.add_column("البورت",    style="bold magenta", width=8,  justify="right")
    table.add_column("البروتوكول", style="yellow",       min_width=18)
    table.add_column("العدد",     style="bold white",   width=8,  justify="right")
    table.add_column("شريط",      style="magenta",      min_width=20)

    max_count = port_data[0][1] if port_data else 1

    for port, count in port_data:
        protocol = ICS_PORTS.get(port, "—")
        bar = _make_bar(count, max_count, width=18)
        table.add_row(
            str(port),
            protocol,
            str(count),
            bar,
        )

    console.print(table)


# ---------------------------------------------------------------
# جدول الشركات
# ---------------------------------------------------------------

def print_orgs_table(
    org_data: list[tuple[str, int]],
    title: str = "أكثر الشركات/المؤسسات",
) -> None:
    """
    يطبع توزيع الأجهزة حسب الشركة.

    Args:
        org_data: قائمة من group_by_org() — [(org, count), ...]
        title   : عنوان الجدول
    """
    if not org_data:
        return

    table = Table(
        title=f"[title]{title}[/title]",
        box=box.SIMPLE_HEAVY,
        border_style="yellow",
        header_style="bold white",
        padding=(0, 1),
        title_justify="left",
    )

    table.add_column("#",          style="dim",          width=4,  justify="right")
    table.add_column("الشركة",     style="yellow",       min_width=30)
    table.add_column("العدد",      style="bold white",   width=8,  justify="right")

    for idx, (org, count) in enumerate(org_data, start=1):
        table.add_row(
            str(idx),
            _truncate(org, 45),
            str(count),
        )

    console.print(table)


# ---------------------------------------------------------------
# جدول معلومات حساب Shodan
# ---------------------------------------------------------------

def print_account_table(account_info: dict) -> None:
    """
    يطبع معلومات حساب Shodan.

    Args:
        account_info: dict من ShodanClient.validate_key()
    """
    table = Table(
        title="[title]معلومات حساب Shodan[/title]",
        box=box.SIMPLE_HEAVY,
        border_style="cyan",
        header_style="bold white",
        show_header=False,
        padding=(0, 2),
        title_justify="left",
    )

    table.add_column("الحقل",  style="dim white",  min_width=20)
    table.add_column("القيمة", style="bold white",  min_width=15)

    plan    = account_info.get("plan", "N/A")
    credits = account_info.get("query_credits", "N/A")
    scans   = account_info.get("scan_credits",  "N/A")

    # تلوين الرصيد حسب قيمته
    if isinstance(credits, int):
        credit_style = "success" if credits > 10 else "warning" if credits > 0 else "error"
        credits_display = f"[{credit_style}]{credits}[/{credit_style}]"
    else:
        credits_display = str(credits)

    table.add_row("الخطة",              plan)
    table.add_row("Query Credits",      credits_display)
    table.add_row("Scan Credits",       str(scans))
    table.add_row("Unlocked",           str(account_info.get("unlocked", False)))

    console.print(table)


# ---------------------------------------------------------------
# جدول قوالب ICS/OT
# ---------------------------------------------------------------

def print_templates_table(templates: dict) -> None:
    """
    يطبع قائمة قوالب ICS/OT الجاهزة.

    Args:
        templates: ICS_QUERY_TEMPLATES من constants.py
    """
    table = Table(
        title="[title]قوالب استعلامات ICS/OT الجاهزة[/title]",
        box=box.ROUNDED,
        border_style="cyan",
        header_style="bold white on dark_blue",
        padding=(0, 1),
        title_justify="left",
    )

    table.add_column("المفتاح",     style="bold cyan",   width=12)
    table.add_column("الاسم",       style="yellow",      min_width=22)
    table.add_column("الاستعلام",   style="magenta",     min_width=16)
    table.add_column("الوصف",       style="dim white",   min_width=30)

    for key, tmpl in templates.items():
        table.add_row(
            key,
            tmpl["label"],
            tmpl["query"],
            tmpl["description"],
        )

    console.print(table)


# ---------------------------------------------------------------
# دوال مساعدة داخلية
# ---------------------------------------------------------------

def _format_ports(ports: list[int], max_ports: int = 6) -> str:
    """
    يُنسّق قائمة البورتات للعرض في الجدول.

    يعرض أول max_ports بورتات ويُضيف "..." إذا كان هناك أكثر.

    Args:
        ports    : قائمة البورتات
        max_ports: الحد الأقصى للبورتات المعروضة

    Returns:
        نص مُنسّق مثل: "80  443  502  ..."
    """
    if not ports:
        return "[dim]—[/dim]"

    sorted_ports = sorted(ports)
    display = sorted_ports[:max_ports]
    rest    = len(sorted_ports) - len(display)

    parts = [f"[port]{p}[/port]" for p in display]
    result = "  ".join(parts)

    if rest > 0:
        result += f"  [dim]+{rest}[/dim]"

    return result


def _make_bar(value: int, max_value: int, width: int = 20, char: str = "█") -> str:
    """
    يُنشئ شريط تقدم نصي بسيط.

    Args:
        value    : القيمة الحالية
        max_value: القيمة القصوى
        width    : عرض الشريط بالأحرف
        char     : الحرف المستخدم لملء الشريط

    Returns:
        نص مثل: "████████░░░░░░░░░░░░"
    """
    if max_value == 0:
        return ""

    filled = int((value / max_value) * width)
    empty  = width - filled
    return char * filled + "░" * empty


def _truncate(text: str, max_len: int, suffix: str = "…") -> str:
    """
    يُقصّر النص إذا تجاوز الحد الأقصى.

    Args:
        text   : النص الأصلي
        max_len: الحد الأقصى للطول
        suffix : اللاحقة عند القطع (افتراضي: "…")

    Returns:
        النص مُقصَّراً إذا لزم الأمر
    """
    if len(text) <= max_len:
        return text
    return text[:max_len - len(suffix)] + suffix
