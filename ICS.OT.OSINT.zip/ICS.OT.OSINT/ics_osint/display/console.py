"""
display/console.py
==================
كائن Console مركزي مشترك بين جميع وحدات العرض.

لماذا كائن مركزي؟
- يضمن أن جميع الوحدات تطبع على نفس الـ console
- يُسهّل اختبار المخرجات عبر تمرير console وهمي
- يُتيح تعطيل الألوان بسهولة (مثلاً عند التوجيه لملف)

الاستخدام:
    from ics_osint.display.console import console, err_console
    console.print("[green]نجح[/green]")
    err_console.print("[red]خطأ[/red]")
"""

from rich.console import Console
from rich.theme import Theme

# ---------------------------------------------------------------
# Theme مخصص يُعرّف الأنماط الدلالية للمشروع
# ---------------------------------------------------------------
_THEME = Theme({
    # بيانات الأجهزة
    "ip":      "bold cyan",
    "country": "green",
    "org":     "yellow",
    "port":    "magenta",
    # رسائل النظام
    "success": "bold green",
    "error":   "bold red",
    "warning": "bold yellow",
    "info":    "bold blue",
    "dim":     "dim white",
    # عناوين الجداول
    "header":  "bold white on dark_blue",
    "title":   "bold white",
})

# Console الرئيسي — للمخرجات العادية (stdout)
console = Console(theme=_THEME, highlight=False)

# Console للأخطاء — يكتب على stderr حتى لا يختلط مع المخرجات
err_console = Console(theme=_THEME, stderr=True, highlight=False)
