"""
display/progress.py
===================
شريط التقدم (Progress Bar) أثناء جلب البيانات من Shodan.

يُظهر للمستخدم:
- عدد الصفحات المُنجزة / الإجمالية
- عدد النتائج المجموعة حتى الآن
- الوقت المنقضي
- سرعة الجلب (نتائج/ثانية)

الاستخدام المباشر:
    from ics_osint.display.progress import SearchProgress

    with SearchProgress(max_pages=3) as progress:
        for page in range(1, 4):
            results = client.search_page(query, page=page)
            progress.update(page, total_results=len(all_results))

الاستخدام مع ShodanClient.search():
    def on_progress(current, total, count):
        progress.update(current, total, count)

    client.search(query, max_pages=3, progress_callback=on_progress)
"""

from contextlib import contextmanager
from typing import Optional, Generator

from rich.progress import (
    Progress,
    TaskID,
    SpinnerColumn,
    BarColumn,
    TextColumn,
    TimeElapsedColumn,
    MofNCompleteColumn,
)
from rich.live import Live
from rich.console import Console

from ics_osint.display.console import console


# ---------------------------------------------------------------
# شريط التقدم الرئيسي
# ---------------------------------------------------------------

class SearchProgress:
    """
    يُدير شريط التقدم أثناء عملية البحث في Shodan.

    الاستخدام كـ context manager:
        with SearchProgress(max_pages=5) as sp:
            for page in range(1, 6):
                # جلب البيانات...
                sp.update(page, total_pages=5, results_count=len(results))

    الاستخدام كـ callback لـ ShodanClient.search():
        sp = SearchProgress(max_pages=5)
        sp.start()
        client.search(query, max_pages=5, progress_callback=sp.callback)
        sp.stop()
    """

    def __init__(self, max_pages: int = 1, query: str = ""):
        """
        Args:
            max_pages: الحد الأقصى للصفحات المتوقعة
            query    : نص الاستعلام (للعرض في الشريط)
        """
        self.max_pages     = max_pages
        self.query         = query
        self._progress     = self._build_progress()
        self._task_id: Optional[TaskID] = None
        self._results_count = 0

    def _build_progress(self) -> Progress:
        """يبني كائن Progress بالأعمدة المطلوبة"""
        return Progress(
            SpinnerColumn(spinner_name="dots", style="cyan"),
            TextColumn("[bold blue]جلب البيانات...[/bold blue]"),
            BarColumn(
                bar_width=30,
                style="blue",
                complete_style="cyan",
                finished_style="green",
            ),
            MofNCompleteColumn(),          # "2/5 صفحات"
            TextColumn("•"),
            TextColumn(
                "[cyan]{task.fields[results]}[/cyan] نتيجة",
            ),
            TextColumn("•"),
            TimeElapsedColumn(),
            console=console,
            transient=False,               # يبقى مرئياً بعد الانتهاء
        )

    def start(self) -> None:
        """يبدأ عرض شريط التقدم"""
        self._progress.start()
        self._task_id = self._progress.add_task(
            description="searching",
            total=self.max_pages,
            results=0,
        )

    def update(
        self,
        current_page: int,
        total_pages: int = 0,
        results_count: int = 0,
    ) -> None:
        """
        يُحدّث شريط التقدم بعد كل صفحة.

        Args:
            current_page : رقم الصفحة الحالية
            total_pages  : إجمالي الصفحات (قد يتغير أثناء الجلب)
            results_count: عدد النتائج المجموعة حتى الآن
        """
        if self._task_id is None:
            return

        self._results_count = results_count

        # تحديث الإجمالي إذا تغيّر
        if total_pages > 0 and total_pages != self.max_pages:
            self.max_pages = total_pages
            self._progress.update(self._task_id, total=total_pages)

        self._progress.update(
            self._task_id,
            completed=current_page,
            results=results_count,
        )

    def stop(self, success: bool = True) -> None:
        """
        يوقف شريط التقدم.

        Args:
            success: هل انتهت العملية بنجاح؟ (يُغيّر لون الشريط)
        """
        if self._task_id is not None and success:
            # نُكمل الشريط إذا لم يكن مكتملاً
            self._progress.update(
                self._task_id,
                completed=self.max_pages,
                results=self._results_count,
            )
        self._progress.stop()

    def callback(
        self,
        current_page: int,
        total_pages: int,
        results_count: int,
    ) -> None:
        """
        دالة callback جاهزة للتمرير لـ ShodanClient.search().

        التوقيع يتطابق مع progress_callback في search().
        """
        self.update(current_page, total_pages, results_count)

    # ---- Context Manager ----

    def __enter__(self) -> "SearchProgress":
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        success = exc_type is None
        self.stop(success=success)
        return False  # لا نبتلع الاستثناءات


# ---------------------------------------------------------------
# شريط تقدم بسيط للعمليات القصيرة
# ---------------------------------------------------------------

@contextmanager
def simple_spinner(message: str = "جارٍ المعالجة...") -> Generator[None, None, None]:
    """
    Context manager يعرض spinner بسيط أثناء عملية قصيرة.

    الاستخدام:
        with simple_spinner("جارٍ التحقق من المفتاح..."):
            result = client.validate_key()

    Args:
        message: الرسالة المعروضة بجانب الـ spinner
    """
    with Progress(
        SpinnerColumn(spinner_name="dots", style="cyan"),
        TextColumn(f"[blue]{message}[/blue]"),
        TimeElapsedColumn(),
        console=console,
        transient=True,   # يختفي بعد الانتهاء
    ) as progress:
        progress.add_task(description="", total=None)
        yield


# ---------------------------------------------------------------
# شريط تقدم لعمليات المعالجة (بعد الجلب)
# ---------------------------------------------------------------

@contextmanager
def processing_spinner(message: str = "جارٍ معالجة البيانات...") -> Generator[None, None, None]:
    """
    Context manager للعمليات الداخلية (استخراج، فلترة، تصدير).

    الاستخدام:
        with processing_spinner("جارٍ تصدير الملفات..."):
            export_results(devices, formats=["json", "csv"])
    """
    with Progress(
        SpinnerColumn(spinner_name="line", style="yellow"),
        TextColumn(f"[yellow]{message}[/yellow]"),
        console=console,
        transient=True,
    ) as progress:
        progress.add_task(description="", total=None)
        yield
