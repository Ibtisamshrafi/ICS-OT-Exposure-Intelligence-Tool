"""
display/messages.py
===================
دوال طباعة الرسائل المُلوّنة في Terminal.

تُغطّي جميع أنواع الرسائل:
- نجاح ✓  (أخضر)
- خطأ   ✗  (أحمر)
- تحذير ⚠  (أصفر)
- معلومة ℹ (أزرق)
- عنوان    (أبيض عريض)
- نص خافت  (رمادي)

الاستخدام:
    from ics_osint.display.messages import print_success, print_error

    print_success("تم حفظ المفتاح بنجاح")
    print_error("مفتاح API غير صالح")
"""

from rich.rule import Rule
from rich.panel import Panel
from rich.text import Text
from ics_osint.display.console import console, err_console


# ---------------------------------------------------------------
# رسائل الحالة
# ---------------------------------------------------------------

def print_success(message: str) -> None:
    """يطبع رسالة نجاح باللون الأخضر مع علامة ✓"""
    console.print(f"[success]✓ {message}[/success]")


def print_error(message: str, to_stderr: bool = True) -> None:
    """
    يطبع رسالة خطأ باللون الأحمر مع علامة ✗.

    Args:
        message  : نص الرسالة
        to_stderr: هل تُكتب على stderr؟ (افتراضي: True)
    """
    target = err_console if to_stderr else console
    target.print(f"[error]✗ {message}[/error]")


def print_warning(message: str) -> None:
    """يطبع تحذيراً باللون الأصفر مع علامة ⚠"""
    console.print(f"[warning]⚠  {message}[/warning]")


def print_info(message: str) -> None:
    """يطبع معلومة باللون الأزرق مع علامة ℹ"""
    console.print(f"[info]ℹ  {message}[/info]")


def print_dim(message: str) -> None:
    """يطبع نصاً خافتاً (رمادي) للمعلومات الثانوية"""
    console.print(f"[dim]{message}[/dim]")


# ---------------------------------------------------------------
# عناوين وفواصل
# ---------------------------------------------------------------

def print_title(title: str, subtitle: str = "") -> None:
    """
    يطبع عنوان رئيسي داخل Panel مُزخرف.

    مثال:
    ╭─────────────────────────────────╮
    │   ICS/OT OSINT Tool v1.0.0      │
    │   أداة استخبارات أنظمة ICS/OT  │
    ╰─────────────────────────────────╯
    """
    content = Text(title, style="bold white", justify="center")
    if subtitle:
        content.append(f"\n{subtitle}", style="dim white")

    console.print(Panel(
        content,
        border_style="blue",
        padding=(0, 2),
    ))


def print_section(title: str) -> None:
    """
    يطبع عنوان قسم مع خط فاصل.

    مثال:
    ──────────── نتائج البحث ────────────
    """
    console.print(Rule(f"[title]{title}[/title]", style="blue"))


def print_separator() -> None:
    """يطبع خطاً فاصلاً بسيطاً"""
    console.print(Rule(style="dim"))


def print_blank() -> None:
    """يطبع سطراً فارغاً"""
    console.print()


# ---------------------------------------------------------------
# رسائل خاصة بالأداة
# ---------------------------------------------------------------

def print_banner() -> None:
    """
    يطبع شعار الأداة عند بدء التشغيل.

    ╔══════════════════════════════════════════╗
    ║   ICS/OT OSINT Tool  v1.0.0              ║
    ║   Powered by Shodan API                  ║
    ╚══════════════════════════════════════════╝
    """
    from ics_osint import __version__

    banner = Text(justify="center")
    banner.append("ICS/OT OSINT Tool", style="bold cyan")
    banner.append(f"  v{__version__}", style="dim cyan")
    banner.append("\nPowered by Shodan API", style="dim white")
    banner.append(" · ", style="dim")
    banner.append("للاستخدام الأخلاقي والقانوني فقط", style="dim yellow")

    console.print(Panel(
        banner,
        border_style="cyan",
        padding=(1, 4),
    ))


def print_api_key_status(is_saved: bool, key_preview: str = "") -> None:
    """
    يطبع حالة مفتاح API.

    Args:
        is_saved   : هل المفتاح محفوظ؟
        key_preview: أول 8 أحرف من المفتاح (للعرض الآمن)
    """
    if is_saved:
        print_success(f"مفتاح API محفوظ: [dim]{key_preview}[/dim]")
    else:
        print_warning("لم يتم حفظ مفتاح API بعد")
        print_dim("  شغّل: ics-osint config --set-key")


def print_search_start(query: str, max_pages: int) -> None:
    """يطبع رسالة بدء البحث"""
    print_section("بدء البحث")
    console.print(f"  الاستعلام : [ip]{query}[/ip]")
    console.print(f"  الصفحات   : [info]{max_pages}[/info] صفحة كحد أقصى")
    print_blank()


def print_search_complete(total_found: int, after_filter: int) -> None:
    """يطبع ملخص نتيجة البحث"""
    print_blank()
    console.print(f"  النتائج الكلية  : [success]{total_found}[/success] جهاز")
    if after_filter != total_found:
        console.print(f"  بعد الفلترة     : [warning]{after_filter}[/warning] جهاز")


def print_export_result(json_path=None, csv_path=None) -> None:
    """يطبع مسارات الملفات المُصدَّرة"""
    print_section("ملفات التصدير")
    if json_path:
        print_success(f"JSON : {json_path}")
    if csv_path:
        print_success(f"CSV  : {csv_path}")
    if not json_path and not csv_path:
        print_dim("  لم يتم تصدير أي ملف")
