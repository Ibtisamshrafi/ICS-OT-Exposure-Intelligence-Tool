"""
display package
===============
يُصدّر جميع دوال العرض من مستوى الـ package.

الاستخدام:
    from ics_osint.display import (
        print_devices_table,
        print_stats_table,
        print_error,
        print_success,
        SearchProgress,
        simple_spinner,
    )
"""

from .console import console, err_console

from .messages import (
    print_success,
    print_error,
    print_warning,
    print_info,
    print_dim,
    print_title,
    print_section,
    print_separator,
    print_blank,
    print_banner,
    print_api_key_status,
    print_search_start,
    print_search_complete,
    print_export_result,
)

from .tables import (
    print_devices_table,
    print_stats_table,
    print_countries_table,
    print_ports_table,
    print_orgs_table,
    print_account_table,
    print_templates_table,
)

from .progress import (
    SearchProgress,
    simple_spinner,
    processing_spinner,
)

__all__ = [
    # console
    "console",
    "err_console",
    # messages
    "print_success",
    "print_error",
    "print_warning",
    "print_info",
    "print_dim",
    "print_title",
    "print_section",
    "print_separator",
    "print_blank",
    "print_banner",
    "print_api_key_status",
    "print_search_start",
    "print_search_complete",
    "print_export_result",
    # tables
    "print_devices_table",
    "print_stats_table",
    "print_countries_table",
    "print_ports_table",
    "print_orgs_table",
    "print_account_table",
    "print_templates_table",
    # progress
    "SearchProgress",
    "simple_spinner",
    "processing_spinner",
]
