"""
processing package
==================
يُصدّر الكلاسات والدوال الأكثر استخداماً مباشرة.

الاستخدام:
    from ics_osint.processing import DeviceRecord, extract_devices, apply_filters
"""

from .extractor import (
    DeviceRecord,
    extract_device,
    extract_devices,
)

from .filters import (
    deduplicate,
    filter_by_country,
    filter_by_countries,
    filter_by_port,
    filter_by_ports,
    filter_by_org,
    filter_has_org,
    filter_has_city,
    apply_filters,
    get_filter_stats,
)

from .aggregator import (
    get_summary_stats,
    group_by_country,
    group_by_country_detailed,
    group_by_port,
    group_by_org,
    group_by_city,
    generate_report,
)

__all__ = [
    # extractor
    "DeviceRecord",
    "extract_device",
    "extract_devices",
    # filters
    "deduplicate",
    "filter_by_country",
    "filter_by_countries",
    "filter_by_port",
    "filter_by_ports",
    "filter_by_org",
    "filter_has_org",
    "filter_has_city",
    "apply_filters",
    "get_filter_stats",
    # aggregator
    "get_summary_stats",
    "group_by_country",
    "group_by_country_detailed",
    "group_by_port",
    "group_by_org",
    "group_by_city",
    "generate_report",
]
