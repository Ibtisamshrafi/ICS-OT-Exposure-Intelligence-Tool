"""
processing/filters.py
=====================
وحدة الفلترة اللاحقة (Post-fetch Filtering).

نوعان من الفلترة في هذا المشروع:

1. فلترة مسبقة (Pre-fetch):
   تُضاف للاستعلام قبل إرساله لـ Shodan.
   مثال: إضافة "country:US" للاستعلام → "port:502 country:US"
   هذه تتم في وحدة CLI وليس هنا.

2. فلترة لاحقة (Post-fetch) ← هذا الملف:
   تتم على البيانات بعد استلامها من Shodan.
   مثال: إزالة IPs المكررة، استبعاد نتائج بدون اسم شركة.

لماذا الفلترة اللاحقة؟
- Shodan أحياناً يُرجع نفس الـ IP في صفحات مختلفة
- بعض النتائج تكون ناقصة (بدون org أو city)
- المستخدم قد يريد تضييق النتائج بعد الجلب
"""

from typing import Optional
from ics_osint.processing.extractor import DeviceRecord


# ---------------------------------------------------------------
# الفلتر الأساسي: إزالة التكرار
# ---------------------------------------------------------------

def deduplicate(devices: list[DeviceRecord]) -> list[DeviceRecord]:
    """
    يُزيل السجلات المكررة بناءً على عنوان IP.

    إذا ظهر نفس الـ IP مرتين (من صفحتين مختلفتين مثلاً)،
    نحتفظ بالأول فقط.

    Args:
        devices: قائمة DeviceRecord قد تحتوي تكراراً

    Returns:
        قائمة DeviceRecord بدون تكرار، بنفس الترتيب الأصلي
    """
    seen_ips: set[str] = set()
    unique: list[DeviceRecord] = []

    for device in devices:
        if device.ip not in seen_ips:
            seen_ips.add(device.ip)
            unique.append(device)

    return unique


# ---------------------------------------------------------------
# فلترة حسب الدولة
# ---------------------------------------------------------------

def filter_by_country(
    devices: list[DeviceRecord],
    country_code: str,
) -> list[DeviceRecord]:
    """
    يُرجع فقط الأجهزة التي تنتمي لدولة معينة.

    Args:
        devices     : قائمة DeviceRecord
        country_code: رمز الدولة بحرفين (مثل: "US", "DE", "SA")
                      غير حساس لحالة الأحرف

    Returns:
        قائمة DeviceRecord المُصفّاة

    مثال:
        us_devices = filter_by_country(devices, "US")
    """
    if not country_code:
        return devices

    target = country_code.strip().upper()
    return [d for d in devices if d.country_code.upper() == target]


def filter_by_countries(
    devices: list[DeviceRecord],
    country_codes: list[str],
) -> list[DeviceRecord]:
    """
    يُرجع الأجهزة التي تنتمي لأي دولة من قائمة دول.

    Args:
        devices      : قائمة DeviceRecord
        country_codes: قائمة رموز الدول (مثل: ["US", "DE", "SA"])

    Returns:
        قائمة DeviceRecord المُصفّاة
    """
    if not country_codes:
        return devices

    targets = {c.strip().upper() for c in country_codes if c.strip()}
    return [d for d in devices if d.country_code.upper() in targets]


# ---------------------------------------------------------------
# فلترة حسب البورت
# ---------------------------------------------------------------

def filter_by_port(
    devices: list[DeviceRecord],
    port: int,
) -> list[DeviceRecord]:
    """
    يُرجع فقط الأجهزة التي لديها بورت معين مفتوح.

    Args:
        devices: قائمة DeviceRecord
        port   : رقم البورت (مثل: 502 لـ Modbus)

    Returns:
        قائمة DeviceRecord المُصفّاة

    مثال:
        modbus_devices = filter_by_port(devices, 502)
    """
    if port is None:
        return devices

    return [d for d in devices if port in d.ports]


def filter_by_ports(
    devices: list[DeviceRecord],
    ports: list[int],
) -> list[DeviceRecord]:
    """
    يُرجع الأجهزة التي لديها أي بورت من قائمة البورتات مفتوح.

    Args:
        devices: قائمة DeviceRecord
        ports  : قائمة أرقام البورتات

    Returns:
        قائمة DeviceRecord المُصفّاة
    """
    if not ports:
        return devices

    target_ports = set(ports)
    return [d for d in devices if target_ports.intersection(d.ports)]


# ---------------------------------------------------------------
# فلترة حسب وجود بيانات
# ---------------------------------------------------------------

def filter_has_org(devices: list[DeviceRecord]) -> list[DeviceRecord]:
    """
    يُرجع فقط الأجهزة التي لديها اسم شركة/مؤسسة معروف.
    يستبعد السجلات التي قيمة org فيها "N/A" أو فارغة.

    مفيد عندما يريد المستخدم نتائج ذات قيمة استخباراتية أعلى.
    """
    return [
        d for d in devices
        if d.org and d.org.strip() and d.org.strip().upper() != "N/A"
    ]


def filter_has_city(devices: list[DeviceRecord]) -> list[DeviceRecord]:
    """
    يُرجع فقط الأجهزة التي لديها مدينة معروفة.
    يستبعد السجلات التي قيمة city فيها "N/A" أو فارغة.
    """
    return [
        d for d in devices
        if d.city and d.city.strip() and d.city.strip().upper() != "N/A"
    ]


# ---------------------------------------------------------------
# فلترة حسب الشركة (بحث نصي)
# ---------------------------------------------------------------

def filter_by_org(
    devices: list[DeviceRecord],
    org_keyword: str,
    case_sensitive: bool = False,
) -> list[DeviceRecord]:
    """
    يُرجع الأجهزة التي يحتوي اسم شركتها على كلمة مفتاحية.

    Args:
        devices       : قائمة DeviceRecord
        org_keyword   : الكلمة المفتاحية للبحث في اسم الشركة
        case_sensitive: هل البحث حساس لحالة الأحرف؟ (افتراضي: لا)

    Returns:
        قائمة DeviceRecord المُصفّاة

    مثال:
        siemens = filter_by_org(devices, "siemens")
    """
    if not org_keyword:
        return devices

    keyword = org_keyword.strip()

    if case_sensitive:
        return [d for d in devices if keyword in d.org]
    else:
        keyword_lower = keyword.lower()
        return [d for d in devices if keyword_lower in d.org.lower()]


# ---------------------------------------------------------------
# تطبيق مجموعة فلاتر دفعة واحدة (Pipeline)
# ---------------------------------------------------------------

def apply_filters(
    devices: list[DeviceRecord],
    country_code:  Optional[str]       = None,
    country_codes: Optional[list[str]] = None,
    port:          Optional[int]       = None,
    ports:         Optional[list[int]] = None,
    org_keyword:   Optional[str]       = None,
    require_org:   bool                = False,
    require_city:  bool                = False,
    remove_duplicates: bool            = True,
) -> list[DeviceRecord]:
    """
    يُطبّق جميع الفلاتر المطلوبة على قائمة الأجهزة بالتسلسل.

    هذه الدالة هي "نقطة الدخول الموحّدة" للفلترة —
    بدلاً من استدعاء كل فلتر على حدة، تستدعي هذه الدالة فقط.

    ترتيب تطبيق الفلاتر:
    1. إزالة التكرار (الأسرع — تُقلّل حجم البيانات مبكراً)
    2. فلترة الدولة
    3. فلترة البورت
    4. فلترة الشركة (نصي)
    5. اشتراط وجود org
    6. اشتراط وجود city

    Args:
        devices          : قائمة DeviceRecord الأصلية
        country_code     : فلترة بدولة واحدة (رمز بحرفين)
        country_codes    : فلترة بقائمة دول
        port             : فلترة ببورت واحد
        ports            : فلترة بقائمة بورتات
        org_keyword      : فلترة باسم شركة (بحث نصي)
        require_org      : استبعاد النتائج بدون اسم شركة
        require_city     : استبعاد النتائج بدون مدينة
        remove_duplicates: إزالة IPs المكررة (افتراضي: True)

    Returns:
        قائمة DeviceRecord بعد تطبيق جميع الفلاتر

    مثال:
        filtered = apply_filters(
            devices,
            country_code="US",
            port=502,
            require_org=True,
        )
    """
    result = devices

    # 1. إزالة التكرار أولاً
    if remove_duplicates:
        result = deduplicate(result)

    # 2. فلترة الدولة
    if country_codes:
        result = filter_by_countries(result, country_codes)
    elif country_code:
        result = filter_by_country(result, country_code)

    # 3. فلترة البورت
    if ports:
        result = filter_by_ports(result, ports)
    elif port is not None:
        result = filter_by_port(result, port)

    # 4. فلترة الشركة
    if org_keyword:
        result = filter_by_org(result, org_keyword)

    # 5. اشتراط وجود org
    if require_org:
        result = filter_has_org(result)

    # 6. اشتراط وجود city
    if require_city:
        result = filter_has_city(result)

    return result


# ---------------------------------------------------------------
# إحصائيات الفلترة
# ---------------------------------------------------------------

def get_filter_stats(
    original: list[DeviceRecord],
    filtered: list[DeviceRecord],
) -> dict:
    """
    يُرجع إحصائيات عن نتيجة الفلترة.

    مفيد لعرض رسالة للمستخدم مثل:
    "تم الاحتفاظ بـ 45 من أصل 100 نتيجة بعد الفلترة"

    Args:
        original: القائمة قبل الفلترة
        filtered: القائمة بعد الفلترة

    Returns:
        dict يحتوي على إحصائيات الفلترة
    """
    original_count = len(original)
    filtered_count = len(filtered)
    removed_count  = original_count - filtered_count

    return {
        "original_count": original_count,
        "filtered_count": filtered_count,
        "removed_count":  removed_count,
        "retention_pct":  round(
            (filtered_count / original_count * 100) if original_count > 0 else 0,
            1
        ),
    }
