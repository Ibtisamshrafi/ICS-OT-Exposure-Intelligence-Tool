"""
processing/aggregator.py
========================
تجميع وتحليل البيانات المُستخرجة.

يُوفّر دوال لـ:
- إحصائيات عامة (عدد الأجهزة، عدد الدول، إلخ)
- تجميع حسب الدولة (كم جهاز في كل دولة)
- تجميع حسب البورت (كم جهاز يستخدم كل بورت)
- تجميع حسب الشركة (أكثر الشركات ظهوراً)

مفيد لعرض ملخص تحليلي للمستخدم قبل التصدير.
"""

from typing import Optional
from collections import Counter
from ics_osint.processing.extractor import DeviceRecord


# ---------------------------------------------------------------
# إحصائيات عامة
# ---------------------------------------------------------------

def get_summary_stats(devices: list[DeviceRecord]) -> dict:
    """
    يُرجع إحصائيات عامة عن قائمة الأجهزة.

    Returns:
        dict يحتوي على:
        - total_devices  : عدد الأجهزة
        - unique_ips     : عدد IPs الفريدة (يجب أن يساوي total_devices بعد deduplicate)
        - unique_countries: عدد الدول المختلفة
        - unique_orgs    : عدد الشركات المختلفة
        - unique_ports   : عدد البورتات المختلفة
        - devices_with_org : عدد الأجهزة التي لديها اسم شركة
        - devices_with_city: عدد الأجهزة التي لديها مدينة
    """
    if not devices:
        return {
            "total_devices":     0,
            "unique_ips":        0,
            "unique_countries":  0,
            "unique_orgs":       0,
            "unique_ports":      0,
            "devices_with_org":  0,
            "devices_with_city": 0,
        }

    unique_ips       = {d.ip for d in devices}
    unique_countries = {d.country_code for d in devices if d.country_code.upper() != "N/A"}
    unique_orgs      = {d.org for d in devices if d.org.upper() != "N/A"}

    # جمع جميع البورتات من كل الأجهزة
    all_ports = set()
    for d in devices:
        all_ports.update(d.ports)

    devices_with_org  = sum(1 for d in devices if d.org.upper() != "N/A")
    devices_with_city = sum(1 for d in devices if d.city.upper() != "N/A")

    return {
        "total_devices":     len(devices),
        "unique_ips":        len(unique_ips),
        "unique_countries":  len(unique_countries),
        "unique_orgs":       len(unique_orgs),
        "unique_ports":      len(all_ports),
        "devices_with_org":  devices_with_org,
        "devices_with_city": devices_with_city,
    }


# ---------------------------------------------------------------
# تجميع حسب الدولة
# ---------------------------------------------------------------

def group_by_country(
    devices: list[DeviceRecord],
    top_n: Optional[int] = None,
) -> list[tuple[str, int]]:
    """
    يُجمّع الأجهزة حسب الدولة ويُرجع قائمة مُرتّبة تنازلياً.

    Args:
        devices: قائمة DeviceRecord
        top_n  : الحد الأقصى للنتائج (اختياري — افتراضي: كل الدول)

    Returns:
        قائمة من tuples: [(country_code, count), ...]
        مُرتّبة من الأكثر إلى الأقل

    مثال:
        [("US", 45), ("DE", 23), ("CN", 12), ...]
    """
    counter = Counter(d.country_code for d in devices if d.country_code.upper() != "N/A")
    most_common = counter.most_common(top_n)
    return most_common


def group_by_country_detailed(
    devices: list[DeviceRecord],
    top_n: Optional[int] = None,
) -> list[dict]:
    """
    نسخة أكثر تفصيلاً من group_by_country — تُرجع dict لكل دولة.

    Returns:
        قائمة من dicts:
        [
            {
                "country_code": "US",
                "country_name": "United States",
                "count": 45,
                "percentage": 45.0
            },
            ...
        ]
    """
    if not devices:
        return []

    total = len(devices)
    counter = Counter(d.country_code for d in devices if d.country_code.upper() != "N/A")

    # نحتاج اسم الدولة الكامل — نأخذه من أول جهاز من كل دولة
    country_names = {}
    for d in devices:
        if d.country_code not in country_names:
            country_names[d.country_code] = d.country_name

    result = []
    for code, count in counter.most_common(top_n):
        result.append({
            "country_code": code,
            "country_name": country_names.get(code, code),
            "count":        count,
            "percentage":   round(count / total * 100, 1),
        })

    return result


# ---------------------------------------------------------------
# تجميع حسب البورت
# ---------------------------------------------------------------

def group_by_port(
    devices: list[DeviceRecord],
    top_n: Optional[int] = None,
) -> list[tuple[int, int]]:
    """
    يُجمّع الأجهزة حسب البورت ويُرجع قائمة مُرتّبة تنازلياً.

    ملاحظة: الجهاز الواحد قد يظهر في عدة بورتات.

    Args:
        devices: قائمة DeviceRecord
        top_n  : الحد الأقصى للنتائج

    Returns:
        قائمة من tuples: [(port, count), ...]

    مثال:
        [(502, 67), (80, 45), (443, 34), ...]
    """
    all_ports = []
    for d in devices:
        all_ports.extend(d.ports)

    counter = Counter(all_ports)
    return counter.most_common(top_n)


# ---------------------------------------------------------------
# تجميع حسب الشركة
# ---------------------------------------------------------------

def group_by_org(
    devices: list[DeviceRecord],
    top_n: Optional[int] = None,
) -> list[tuple[str, int]]:
    """
    يُجمّع الأجهزة حسب الشركة ويُرجع قائمة مُرتّبة تنازلياً.

    Args:
        devices: قائمة DeviceRecord
        top_n  : الحد الأقصى للنتائج

    Returns:
        قائمة من tuples: [(org_name, count), ...]

    مثال:
        [("Example Corp", 12), ("Siemens AG", 8), ...]
    """
    counter = Counter(d.org for d in devices if d.org.upper() != "N/A")
    return counter.most_common(top_n)


# ---------------------------------------------------------------
# تجميع حسب المدينة
# ---------------------------------------------------------------

def group_by_city(
    devices: list[DeviceRecord],
    top_n: Optional[int] = None,
) -> list[tuple[str, int]]:
    """
    يُجمّع الأجهزة حسب المدينة ويُرجع قائمة مُرتّبة تنازلياً.

    Args:
        devices: قائمة DeviceRecord
        top_n  : الحد الأقصى للنتائج

    Returns:
        قائمة من tuples: [(city, count), ...]
    """
    counter = Counter(d.city for d in devices if d.city.upper() != "N/A")
    return counter.most_common(top_n)


# ---------------------------------------------------------------
# تقرير شامل
# ---------------------------------------------------------------

def generate_report(devices: list[DeviceRecord]) -> dict:
    """
    يُولّد تقريراً شاملاً عن البيانات المُجمّعة.

    يحتوي على:
    - إحصائيات عامة
    - أكثر 10 دول
    - أكثر 10 بورتات
    - أكثر 10 شركات

    Returns:
        dict يحتوي على التقرير الكامل
    """
    return {
        "summary":        get_summary_stats(devices),
        "top_countries":  group_by_country_detailed(devices, top_n=10),
        "top_ports":      group_by_port(devices, top_n=10),
        "top_orgs":       group_by_org(devices, top_n=10),
        "top_cities":     group_by_city(devices, top_n=10),
    }
