"""
processing/extractor.py
=======================
استخراج الحقول المطلوبة فقط من البيانات الخام القادمة من Shodan.

البيانات الخام من Shodan تحتوي على عشرات الحقول غير المطلوبة
(banner, vulns, ssl, http, ...). هذه الوحدة تستخرج فقط:
    ip, country_code, country_name, city, org, ports

مثال على بيانات Shodan الخام:
{
    "ip_str": "1.2.3.4",
    "port": 502,
    "transport": "tcp",
    "data": "Modbus/TCP...",
    "location": {
        "country_code": "US",
        "country_name": "United States",
        "city": "New York",
        "latitude": 40.7128,
        "longitude": -74.0060,
        ...
    },
    "org": "Example Corp",
    "isp": "Example ISP",
    "hostnames": ["host.example.com"],
    "domains": ["example.com"],
    "ports": [80, 443, 502],
    "vulns": {...},
    "ssl": {...},
    ...
}

المخرج المطلوب (DeviceRecord):
{
    "ip":           "1.2.3.4",
    "country_code": "US",
    "country_name": "United States",
    "city":         "New York",
    "org":          "Example Corp",
    "ports":        [80, 443, 502]
}
"""

from typing import Optional
from dataclasses import dataclass, field, asdict


# ---------------------------------------------------------------
# DeviceRecord: هيكل بيانات جهاز ICS/OT واحد
# ---------------------------------------------------------------

@dataclass
class DeviceRecord:
    """
    يمثّل جهاز ICS/OT واحد بعد استخراج بياناته من Shodan.

    استخدام dataclass يُعطينا:
    - تحقق تلقائي من الأنواع
    - طباعة جميلة بـ __repr__
    - مقارنة سهلة بـ __eq__
    - تحويل لـ dict بـ asdict()
    """
    ip:           str
    country_code: str
    country_name: str
    city:         str
    org:          str
    ports:        list[int] = field(default_factory=list)

    def to_dict(self) -> dict:
        """يُحوّل السجل لـ dict جاهز للتصدير"""
        return asdict(self)

    def ports_as_string(self, separator: str = ", ") -> str:
        """يُرجع البورتات كنص مفصول بـ separator (مفيد لـ CSV)"""
        return separator.join(str(p) for p in sorted(self.ports))

    def __hash__(self):
        """يجعل DeviceRecord قابلاً للاستخدام في set() للكشف عن التكرار"""
        return hash(self.ip)

    def __eq__(self, other):
        if isinstance(other, DeviceRecord):
            return self.ip == other.ip
        return False


# ---------------------------------------------------------------
# دوال الاستخراج
# ---------------------------------------------------------------

# قيمة افتراضية عند غياب أي حقل
_UNKNOWN = "N/A"


def extract_device(raw: dict) -> Optional[DeviceRecord]:
    """
    يستخرج حقول DeviceRecord من نتيجة Shodan خام واحدة.

    يتعامل بأمان مع:
    - غياب أي حقل (يضع "N/A" بدلاً منه)
    - location = None أو dict فارغ
    - ports = None أو قائمة فارغة
    - ip_str مفقود (يُرجع None لتجاهل هذه النتيجة)

    Args:
        raw: dict واحد من قائمة matches في استجابة Shodan

    Returns:
        DeviceRecord إذا كانت البيانات صالحة
        None إذا كانت البيانات تالفة أو مفقودة ip
    """
    if not isinstance(raw, dict):
        return None

    # ---- IP (حقل إلزامي — بدونه نتجاهل النتيجة) ----
    ip = raw.get("ip_str", "").strip()
    if not ip:
        return None

    # ---- Location (قد يكون None أو مفقوداً) ----
    location = raw.get("location") or {}

    country_code = str(location.get("country_code") or _UNKNOWN).strip()
    country_name = str(location.get("country_name") or _UNKNOWN).strip()
    city         = str(location.get("city")         or _UNKNOWN).strip()

    # ---- Organization ----
    # Shodan يضع الشركة في "org" أو "isp" — نأخذ الأول المتاح
    org = str(raw.get("org") or raw.get("isp") or _UNKNOWN).strip()

    # ---- Ports ----
    # Shodan يُرجع "ports" كقائمة في نتائج البحث العام
    # لكن في بعض الأحيان يكون "port" (مفرد) فقط
    ports_raw = raw.get("ports")

    if isinstance(ports_raw, list):
        # نُصفّي القيم غير الصحيحة ونحوّل لـ int
        ports = _parse_ports(ports_raw)
    elif isinstance(raw.get("port"), int):
        # نتيجة من host lookup — بورت واحد فقط
        ports = [raw["port"]]
    else:
        ports = []

    return DeviceRecord(
        ip=ip,
        country_code=country_code,
        country_name=country_name,
        city=city,
        org=org,
        ports=ports,
    )


def extract_devices(raw_results: list[dict]) -> list[DeviceRecord]:
    """
    يستخرج DeviceRecord من قائمة نتائج Shodan الخام.

    يتجاهل تلقائياً أي نتيجة تالفة أو مفقودة الـ IP.

    Args:
        raw_results: قائمة matches من استجابة Shodan

    Returns:
        قائمة DeviceRecord — قد تكون أقصر من raw_results
        إذا كانت بعض النتائج تالفة
    """
    if not raw_results:
        return []

    devices = []
    skipped = 0

    for raw in raw_results:
        record = extract_device(raw)
        if record is not None:
            devices.append(record)
        else:
            skipped += 1

    if skipped > 0:
        import logging
        logging.getLogger(__name__).debug(
            f"extract_devices: skipped {skipped} invalid records"
        )

    return devices


def _parse_ports(ports_raw: list) -> list[int]:
    """
    يُحوّل قائمة البورتات الخام لقائمة int نظيفة.

    يتجاهل القيم غير الصحيحة (None, strings غير رقمية, أرقام سالبة).

    Args:
        ports_raw: قائمة من Shodan (قد تحتوي أنواعاً مختلطة)

    Returns:
        قائمة int مُرتّبة تصاعدياً
    """
    valid_ports = []

    for p in ports_raw:
        try:
            port_int = int(p)
            # البورتات الصحيحة: 1 - 65535
            if 1 <= port_int <= 65535:
                valid_ports.append(port_int)
        except (ValueError, TypeError):
            continue

    return sorted(set(valid_ports))  # إزالة التكرار والترتيب
