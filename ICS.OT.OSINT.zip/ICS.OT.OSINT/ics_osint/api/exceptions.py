"""
api/exceptions.py
=================
استثناءات مخصصة لوحدة Shodan API.

لماذا استثناءات مخصصة؟
- تُعطي رسائل خطأ واضحة بالعربية للمستخدم
- تُميّز بين أنواع الأخطاء المختلفة (مفتاح خاطئ / شبكة / rate limit)
- تُسهّل التعامل معها في الكود العلوي (CLI) بـ except محدد
"""


class ShodanAPIError(Exception):
    """
    الاستثناء الأساسي — كل استثناءات هذه الوحدة ترث منه.
    يمكن استخدامه لالتقاط أي خطأ من الوحدة بـ:
        except ShodanAPIError as e: ...
    """
    def __init__(self, message: str, original_error: Exception = None):
        super().__init__(message)
        self.message = message
        # نحتفظ بالخطأ الأصلي للـ debugging
        self.original_error = original_error

    def __str__(self):
        return self.message


class InvalidAPIKeyError(ShodanAPIError):
    """
    مفتاح API غير صالح أو منتهي الصلاحية.
    يُرفع عند استجابة HTTP 401 أو 403 من Shodan.
    """
    pass


class RateLimitError(ShodanAPIError):
    """
    تجاوز الحد المسموح به من الطلبات (Rate Limit).
    يُرفع عند استجابة HTTP 429 أو رسالة rate limit من Shodan.

    Attributes:
        retry_after: عدد الثواني المقترح للانتظار قبل إعادة المحاولة
    """
    def __init__(self, message: str, retry_after: int = 60, original_error: Exception = None):
        super().__init__(message, original_error)
        self.retry_after = retry_after


class NoCreditsError(ShodanAPIError):
    """
    لا يوجد رصيد كافٍ من Query Credits.
    حساب Shodan المجاني يملك عدداً محدوداً من الاستعلامات شهرياً.
    """
    pass


class ConnectionError(ShodanAPIError):
    """
    فشل الاتصال بـ Shodan (انقطاع الإنترنت، DNS، إلخ).
    يُرفع عند requests.ConnectionError أو socket errors.
    """
    pass


class TimeoutError(ShodanAPIError):
    """
    انتهت مهلة الاتصال بـ Shodan.
    يُرفع عند requests.Timeout.
    """
    pass


class InvalidQueryError(ShodanAPIError):
    """
    صيغة الاستعلام غير صحيحة أو مرفوضة من Shodan.
    """
    pass


class NoResultsError(ShodanAPIError):
    """
    الاستعلام صحيح لكن لم يُرجع أي نتائج.
    ليس خطأً حقيقياً — لكنه يُعامَل كاستثناء لتبسيط التدفق.
    """
    pass
