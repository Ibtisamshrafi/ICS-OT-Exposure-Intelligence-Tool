"""
api/client.py
=============
وحدة التواصل المباشر مع Shodan API.

المسؤوليات:
1. التحقق من صلاحية مفتاح API
2. إرسال استعلامات البحث مع دعم Pagination
3. التقاط جميع أنواع الأخطاء وتحويلها لاستثناءات مفهومة
4. احترام Rate Limit بالانتظار التلقائي بين الطلبات
5. مراقبة استهلاك Query Credits

الاستخدام:
    from ics_osint.api.client import ShodanClient

    client = ShodanClient(api_key="your_key")
    client.validate_key()                          # التحقق من المفتاح
    results = client.search("port:502", pages=2)   # البحث مع pagination
"""

import time
import socket
import logging
from typing import Optional, Generator

import shodan
import requests

from ics_osint.api.exceptions import (
    ShodanAPIError,
    InvalidAPIKeyError,
    RateLimitError,
    NoCreditsError,
    NoResultsError,
    InvalidQueryError,
)
# نستورد ConnectionError و TimeoutError من exceptions بأسماء مستعارة
# لتجنب التعارض مع الأسماء المدمجة في Python
from ics_osint.api import exceptions as api_exc

from ics_osint.config.constants import (
    SHODAN_PAGE_SIZE,
    MAX_PAGES,
    REQUEST_DELAY_SECONDS,
    CONNECTION_TIMEOUT,
    MAX_RETRIES,
    RETRY_DELAY_SECONDS,
    ERROR_MESSAGES,
)

# إعداد logger خاص بهذه الوحدة
logger = logging.getLogger(__name__)


class ShodanClient:
    """
    عميل Shodan API مع معالجة شاملة للأخطاء و Pagination.

    Attributes:
        api_key  : مفتاح Shodan API
        api      : كائن shodan.Shodan الرسمي
        _credits : رصيد Query Credits المتبقي (يُحدَّث بعد كل طلب)
    """

    def __init__(self, api_key: str):
        """
        Args:
            api_key: مفتاح Shodan API المراد استخدامه
        """
        if not api_key or not api_key.strip():
            raise InvalidAPIKeyError(ERROR_MESSAGES["invalid_key"])

        self.api_key = api_key.strip()
        self._credits: Optional[int] = None

        # إنشاء كائن Shodan الرسمي
        # timeout يُمرَّر عبر requests session داخل المكتبة
        self.api = shodan.Shodan(self.api_key)

    # ------------------------------------------------------------------
    # التحقق من صلاحية المفتاح
    # ------------------------------------------------------------------

    def validate_key(self) -> dict:
        """
        يتحقق من صلاحية مفتاح API عبر استدعاء /api-info.

        Returns:
            dict يحتوي على معلومات الحساب:
            {
                "plan": "dev",
                "query_credits": 100,
                "scan_credits": 100,
                "unlocked": True,
                ...
            }

        Raises:
            InvalidAPIKeyError : المفتاح غير صالح (401/403)
            api_exc.ConnectionError : فشل الاتصال
            api_exc.TimeoutError    : انتهت المهلة
            ShodanAPIError          : أي خطأ آخر
        """
        try:
            info = self.api.info()
            # نحفظ رصيد الـ credits للمراقبة
            self._credits = info.get("query_credits", None)
            logger.debug(f"API key valid. Plan: {info.get('plan')}, Credits: {self._credits}")
            return info

        except shodan.APIError as e:
            raise self._map_shodan_error(e)

        except requests.exceptions.ConnectionError as e:
            raise api_exc.ConnectionError(ERROR_MESSAGES["connection_error"], original_error=e)

        except requests.exceptions.Timeout as e:
            raise api_exc.TimeoutError(ERROR_MESSAGES["timeout"], original_error=e)

        except socket.error as e:
            raise api_exc.ConnectionError(ERROR_MESSAGES["connection_error"], original_error=e)

    # ------------------------------------------------------------------
    # البحث الأساسي (صفحة واحدة)
    # ------------------------------------------------------------------

    def search_page(self, query: str, page: int = 1) -> dict:
        """
        يُرسل استعلام بحث لـ Shodan ويُرجع نتائج صفحة واحدة.

        Args:
            query : نص الاستعلام (مثل: "port:502 country:US")
            page  : رقم الصفحة (يبدأ من 1)

        Returns:
            dict خام من Shodan يحتوي على:
            {
                "total": 12345,
                "matches": [ {...}, {...}, ... ]  # حتى 100 نتيجة
            }

        Raises:
            InvalidAPIKeyError  : مفتاح غير صالح
            RateLimitError      : تجاوز Rate Limit
            NoCreditsError      : لا يوجد رصيد
            NoResultsError      : لا توجد نتائج
            InvalidQueryError   : استعلام خاطئ
            api_exc.ConnectionError : فشل الاتصال
            api_exc.TimeoutError    : انتهت المهلة
        """
        if not query or not query.strip():
            raise InvalidQueryError(ERROR_MESSAGES["invalid_query"])

        logger.debug(f"Searching Shodan: query='{query}', page={page}")

        try:
            results = self.api.search(query.strip(), page=page)

            # تحديث رصيد الـ credits إذا كان متاحاً في الاستجابة
            # (Shodan لا يُرجعه دائماً في search، لكن نتحقق)
            if isinstance(results, dict) and "query_credits" in results:
                self._credits = results["query_credits"]

            total = results.get("total", 0)
            matches = results.get("matches", [])

            logger.debug(f"Page {page}: got {len(matches)} results (total: {total})")

            if total == 0 and page == 1:
                raise NoResultsError(ERROR_MESSAGES["no_results"])

            return results

        except shodan.APIError as e:
            raise self._map_shodan_error(e)

        except requests.exceptions.ConnectionError as e:
            raise api_exc.ConnectionError(ERROR_MESSAGES["connection_error"], original_error=e)

        except requests.exceptions.Timeout as e:
            raise api_exc.TimeoutError(ERROR_MESSAGES["timeout"], original_error=e)

        except socket.error as e:
            raise api_exc.ConnectionError(ERROR_MESSAGES["connection_error"], original_error=e)

        except (NoResultsError, InvalidQueryError):
            # نُعيد رفع استثناءاتنا المخصصة دون تغيير
            raise

    # ------------------------------------------------------------------
    # البحث مع Pagination (الدالة الرئيسية)
    # ------------------------------------------------------------------

    def search(
        self,
        query: str,
        max_pages: int = 1,
        max_results: Optional[int] = None,
        progress_callback=None,
    ) -> list[dict]:
        """
        يُرسل استعلام بحث ويجمع النتائج من صفحات متعددة تلقائياً.

        منطق Pagination:
        - كل صفحة تحتوي على 100 نتيجة كحد أقصى (SHODAN_PAGE_SIZE)
        - نتوقف عند: وصول max_pages، أو max_results، أو نفاد النتائج
        - نضيف تأخيراً بين الصفحات لتجنب Rate Limit

        Args:
            query           : نص الاستعلام
            max_pages       : الحد الأقصى للصفحات (افتراضي: 1)
            max_results     : الحد الأقصى للنتائج الإجمالية (اختياري)
            progress_callback: دالة تُستدعى بعد كل صفحة لتحديث شريط التقدم
                               التوقيع: callback(current_page, total_pages, results_so_far)

        Returns:
            قائمة من dicts — كل dict هو نتيجة خام من Shodan

        Raises:
            نفس استثناءات search_page
        """
        # التحقق من الحدود
        max_pages = min(max_pages, MAX_PAGES)

        all_results: list[dict] = []
        total_available = None

        for page_num in range(1, max_pages + 1):

            # التحقق من الحد الأقصى للنتائج قبل طلب صفحة جديدة
            if max_results and len(all_results) >= max_results:
                logger.debug(f"Reached max_results={max_results}, stopping pagination")
                break

            try:
                page_data = self.search_page(query, page=page_num)

            except NoResultsError:
                # الصفحة الأولى فارغة — لا نتائج أصلاً
                if page_num == 1:
                    raise
                # صفحة لاحقة فارغة — وصلنا لنهاية النتائج
                logger.debug(f"Page {page_num} returned no results, stopping")
                break

            matches = page_data.get("matches", [])
            total_available = page_data.get("total", 0)

            # نحسب الحد الفعلي للصفحات بناءً على إجمالي النتائج المتاحة
            actual_max_pages = min(
                max_pages,
                MAX_PAGES,
                -(-total_available // SHODAN_PAGE_SIZE),  # ceiling division
            )

            all_results.extend(matches)

            logger.debug(
                f"Page {page_num}/{actual_max_pages} fetched. "
                f"Got {len(matches)}, total so far: {len(all_results)}"
            )

            # استدعاء callback لتحديث شريط التقدم
            if progress_callback:
                progress_callback(page_num, actual_max_pages, len(all_results))

            # إذا وصلنا لآخر صفحة متاحة — نتوقف
            if len(matches) < SHODAN_PAGE_SIZE:
                logger.debug("Last page reached (fewer results than page size)")
                break

            if page_num >= actual_max_pages:
                break

            # انتظار بين الصفحات لتجنب Rate Limit
            if page_num < max_pages:
                logger.debug(f"Waiting {REQUEST_DELAY_SECONDS}s before next page...")
                time.sleep(REQUEST_DELAY_SECONDS)

        # قطع النتائج إذا تجاوزت max_results
        if max_results and len(all_results) > max_results:
            all_results = all_results[:max_results]

        return all_results

    # ------------------------------------------------------------------
    # معلومات الحساب
    # ------------------------------------------------------------------

    def get_account_info(self) -> dict:
        """
        يُرجع معلومات حساب Shodan (الخطة، الرصيد، إلخ).
        يستخدم validate_key داخلياً.
        """
        return self.validate_key()

    def get_remaining_credits(self) -> Optional[int]:
        """
        يُرجع رصيد Query Credits المتبقي.
        يُرجع None إذا لم يتم الاستعلام بعد.
        """
        return self._credits

    # ------------------------------------------------------------------
    # عدد النتائج فقط (بدون جلب البيانات — لا يستهلك credits)
    # ------------------------------------------------------------------

    def count(self, query: str) -> int:
        """
        يُرجع العدد الإجمالي للنتائج لاستعلام معين.
        هذا الاستدعاء لا يستهلك Query Credits (مجاني).

        Args:
            query: نص الاستعلام

        Returns:
            العدد الإجمالي للنتائج

        Raises:
            نفس استثناءات search_page
        """
        if not query or not query.strip():
            raise InvalidQueryError(ERROR_MESSAGES["invalid_query"])

        try:
            result = self.api.count(query.strip())
            return result.get("total", 0)

        except shodan.APIError as e:
            raise self._map_shodan_error(e)

        except requests.exceptions.ConnectionError as e:
            raise api_exc.ConnectionError(ERROR_MESSAGES["connection_error"], original_error=e)

        except requests.exceptions.Timeout as e:
            raise api_exc.TimeoutError(ERROR_MESSAGES["timeout"], original_error=e)

    # ------------------------------------------------------------------
    # تحويل أخطاء Shodan لاستثناءاتنا المخصصة
    # ------------------------------------------------------------------

    def _map_shodan_error(self, error: shodan.APIError) -> ShodanAPIError:
        """
        يُحوّل shodan.APIError إلى استثناء مخصص مناسب.

        Shodan يُرجع رسائل نصية في الخطأ — نفحصها لتحديد النوع.

        Args:
            error: الخطأ الأصلي من مكتبة Shodan

        Returns:
            استثناء مخصص من api/exceptions.py
        """
        error_msg = str(error).lower()

        logger.debug(f"Shodan API error: {error_msg}")

        # مفتاح غير صالح
        if any(kw in error_msg for kw in ["invalid api key", "unauthorized", "forbidden",
                                           "access denied", "401", "403"]):
            return InvalidAPIKeyError(ERROR_MESSAGES["invalid_key"], original_error=error)

        # تجاوز Rate Limit
        if any(kw in error_msg for kw in ["rate limit", "too many requests", "429"]):
            return RateLimitError(ERROR_MESSAGES["rate_limit"], retry_after=60, original_error=error)

        # لا يوجد رصيد
        if any(kw in error_msg for kw in ["query credits", "no credits", "upgrade",
                                           "exceeded", "quota"]):
            return NoCreditsError(ERROR_MESSAGES["no_credits"], original_error=error)

        # لا توجد نتائج
        if any(kw in error_msg for kw in ["no information available", "no results"]):
            return NoResultsError(ERROR_MESSAGES["no_results"], original_error=error)

        # استعلام خاطئ
        if any(kw in error_msg for kw in ["invalid query", "syntax error", "bad request", "400"]):
            return InvalidQueryError(ERROR_MESSAGES["invalid_query"], original_error=error)

        # خطأ عام غير محدد
        return ShodanAPIError(f"خطأ من Shodan API: {str(error)}", original_error=error)
