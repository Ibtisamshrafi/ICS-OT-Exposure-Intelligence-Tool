"""
api/retry.py
============
منطق إعادة المحاولة (Retry Logic) عند فشل الاتصال.

يُغلّف أي دالة تتواصل مع Shodan بآلية retry تلقائية:
- يُعيد المحاولة عند أخطاء الشبكة (ConnectionError, TimeoutError)
- يُعيد المحاولة عند RateLimitError مع انتظار أطول
- لا يُعيد المحاولة عند InvalidAPIKeyError أو NoCreditsError
  (لأن إعادة المحاولة لن تُغيّر شيئاً)

الاستخدام:
    from ics_osint.api.retry import with_retry

    @with_retry(max_retries=3, delay=5.0)
    def my_api_call():
        ...
"""

import time
import logging
import functools
from typing import Callable, TypeVar, Any

from ics_osint.api.exceptions import (
    ShodanAPIError,
    InvalidAPIKeyError,
    NoCreditsError,
    InvalidQueryError,
    NoResultsError,
    RateLimitError,
)
from ics_osint.api import exceptions as api_exc
from ics_osint.config.constants import MAX_RETRIES, RETRY_DELAY_SECONDS

logger = logging.getLogger(__name__)

# Type variable للـ decorator
F = TypeVar("F", bound=Callable[..., Any])


# الاستثناءات التي لا فائدة من إعادة المحاولة عندها
NON_RETRYABLE_ERRORS = (
    InvalidAPIKeyError,   # المفتاح خاطئ — إعادة المحاولة لن تُصلحه
    NoCreditsError,       # لا رصيد — إعادة المحاولة لن تُضيف رصيداً
    InvalidQueryError,    # الاستعلام خاطئ — إعادة المحاولة لن تُصلحه
    NoResultsError,       # لا نتائج — إعادة المحاولة لن تُغيّر شيئاً
)


def with_retry(
    max_retries: int = MAX_RETRIES,
    delay: float = RETRY_DELAY_SECONDS,
    backoff_factor: float = 2.0,
) -> Callable[[F], F]:
    """
    Decorator يُضيف منطق إعادة المحاولة لأي دالة.

    Args:
        max_retries    : عدد المحاولات الإضافية (غير المحاولة الأولى)
        delay          : وقت الانتظار الأولي بين المحاولات (بالثواني)
        backoff_factor : معامل التضاعف — كل محاولة تنتظر أطول
                         مثال: delay=5, factor=2 → 5s, 10s, 20s

    مثال:
        @with_retry(max_retries=3, delay=5.0)
        def call_api():
            return client.search("port:502")
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            current_delay = delay

            # المحاولة الأولى + max_retries محاولات إضافية
            for attempt in range(max_retries + 1):

                try:
                    return func(*args, **kwargs)

                except NON_RETRYABLE_ERRORS as e:
                    # هذه الأخطاء لا فائدة من إعادة المحاولة — نُرجعها فوراً
                    logger.debug(f"Non-retryable error: {type(e).__name__}: {e}")
                    raise

                except RateLimitError as e:
                    # Rate Limit — ننتظر وقتاً أطول (retry_after من الخطأ)
                    last_exception = e
                    wait_time = e.retry_after if e.retry_after else current_delay * 2

                    if attempt < max_retries:
                        logger.warning(
                            f"Rate limit hit. Waiting {wait_time}s before retry "
                            f"(attempt {attempt + 1}/{max_retries + 1})"
                        )
                        time.sleep(wait_time)
                    else:
                        raise

                except (api_exc.ConnectionError, api_exc.TimeoutError) as e:
                    # أخطاء الشبكة — نُعيد المحاولة مع backoff
                    last_exception = e

                    if attempt < max_retries:
                        logger.warning(
                            f"{type(e).__name__}. Retrying in {current_delay}s "
                            f"(attempt {attempt + 1}/{max_retries + 1})"
                        )
                        time.sleep(current_delay)
                        current_delay *= backoff_factor  # تضاعف وقت الانتظار
                    else:
                        raise

                except ShodanAPIError as e:
                    # أي خطأ Shodan آخر — نُعيد المحاولة مرة واحدة فقط
                    last_exception = e

                    if attempt < min(max_retries, 1):
                        logger.warning(
                            f"Shodan API error: {e}. Retrying in {current_delay}s"
                        )
                        time.sleep(current_delay)
                    else:
                        raise

            # لن نصل هنا عادةً، لكن للأمان
            if last_exception:
                raise last_exception

        return wrapper  # type: ignore
    return decorator


def retry_on_network_error(func: F) -> F:
    """
    Decorator مبسّط يستخدم الإعدادات الافتراضية من constants.py.
    للاستخدام السريع بدون تخصيص.

    مثال:
        @retry_on_network_error
        def call_api():
            ...
    """
    return with_retry()(func)
