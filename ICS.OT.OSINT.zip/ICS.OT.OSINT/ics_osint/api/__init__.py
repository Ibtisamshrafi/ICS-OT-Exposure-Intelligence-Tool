"""
api package
===========
يُصدّر الكلاسات والدوال الأكثر استخداماً مباشرة من مستوى الـ package.

الاستخدام:
    from ics_osint.api import ShodanClient
    from ics_osint.api import InvalidAPIKeyError, RateLimitError
"""

from .client import ShodanClient

from .exceptions import (
    ShodanAPIError,
    InvalidAPIKeyError,
    RateLimitError,
    NoCreditsError,
    NoResultsError,
    InvalidQueryError,
    ConnectionError,
    TimeoutError,
)

from .retry import with_retry, retry_on_network_error

__all__ = [
    # client
    "ShodanClient",
    # exceptions
    "ShodanAPIError",
    "InvalidAPIKeyError",
    "RateLimitError",
    "NoCreditsError",
    "NoResultsError",
    "InvalidQueryError",
    "ConnectionError",
    "TimeoutError",
    # retry
    "with_retry",
    "retry_on_network_error",
]
